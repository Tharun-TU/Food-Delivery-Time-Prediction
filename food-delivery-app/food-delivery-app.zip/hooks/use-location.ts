"use client"

import { useState, useEffect } from "react"

interface Location {
  latitude: number
  longitude: number
  address?: string
}

export function useLocation() {
  const [location, setLocation] = useState<Location | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const getCurrentLocation = () => {
    setLoading(true)
    setError(null)

    if (!navigator.geolocation) {
      setError("Geolocation is not supported by this browser")
      setLoading(false)
      return
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords

        try {
          // Reverse geocoding to get address (you can use Google Maps API or similar)
          const address = await reverseGeocode(latitude, longitude)
          setLocation({ latitude, longitude, address })

          // Log the actual location for debugging
          console.log("📍 Real Customer Location:", { latitude, longitude, address })
        } catch (err) {
          setLocation({ latitude, longitude, address: "Unknown location" })
        }

        setLoading(false)
      },
      (error) => {
        setError(error.message)
        setLoading(false)
      },
      {
        enableHighAccuracy: true,
        timeout: 5000,
        maximumAge: 0,
      },
    )
  }

  const reverseGeocode = async (lat: number, lng: number): Promise<string> => {
    // Mock reverse geocoding - replace with actual service
    return `${lat.toFixed(4)}, ${lng.toFixed(4)}`
  }

  // Set different default locations for testing
  const setTestLocation = (locationName: string) => {
    const testLocations = {
      nearby: {
        latitude: 12.975, // 0.5 km away
        longitude: 77.598,
        address: "Nearby Location (0.5km from restaurant)",
      },
      medium: {
        latitude: 12.99, // ~2 km away
        longitude: 77.61,
        address: "Medium Distance (2km from restaurant)",
      },
      far: {
        latitude: 13.02, // ~5 km away
        longitude: 77.65,
        address: "Far Location (5km from restaurant)",
      },
      very_far: {
        latitude: 13.1, // ~15 km away
        longitude: 77.7,
        address: "Very Far Location (15km from restaurant)",
      },
    }

    const selectedLocation = testLocations[locationName as keyof typeof testLocations]
    if (selectedLocation) {
      setLocation(selectedLocation)
      console.log(`📍 Test Location Set: ${locationName}`, selectedLocation)
    }
  }

  useEffect(() => {
    // For demo purposes, let's set a location that's actually different from restaurant
    // You can change this to test different distances
    if (!location) {
      setTestLocation("medium") // This will show ~2km distance impact
    }

    // Uncomment below to use the same location as restaurant (0 distance)
    // setLocation({
    //   latitude: 12.9716,
    //   longitude: 77.5946,
    //   address: "Same as Restaurant (0km distance)",
    // })
  }, []) // Empty dependency array to run only once

  return { location, loading, error, getCurrentLocation, setTestLocation }
}
