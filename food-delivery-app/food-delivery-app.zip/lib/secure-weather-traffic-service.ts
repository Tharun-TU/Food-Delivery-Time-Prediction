// Client-side service that calls secure server endpoints
export interface WeatherData {
  condition: string
  temperature: number
  humidity: number
  windSpeed: number
  visibility: number
}

export interface TrafficData {
  density: string
  delayFactor: number
  estimatedDelay: number
}

export class SecureWeatherTrafficService {
  private readonly API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || ""

  // Get weather data via secure server endpoint
  async getWeatherData(lat: number, lng: number): Promise<WeatherData> {
    try {
      console.log(`🌤️ Requesting weather data for ${lat}, ${lng}`)

      const response = await fetch("/api/weather-traffic", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "weather",
          lat,
          lng,
        }),
        signal: AbortSignal.timeout(10000),
      })

      if (!response.ok) {
        throw new Error(`Weather request failed: ${response.status}`)
      }

      const weatherData = await response.json()
      console.log("✅ Weather data received:", weatherData)
      return weatherData
    } catch (error) {
      console.error("❌ Weather request error:", error)
      return this.getFallbackWeatherData(lat, lng)
    }
  }

  // Get traffic data via secure server endpoint
  async getTrafficData(originLat: number, originLng: number, destLat: number, destLng: number): Promise<TrafficData> {
    try {
      console.log(`🚦 Requesting traffic data from ${originLat},${originLng} to ${destLat},${destLng}`)

      const response = await fetch("/api/weather-traffic", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "traffic",
          originLat,
          originLng,
          destLat,
          destLng,
        }),
        signal: AbortSignal.timeout(12000),
      })

      if (!response.ok) {
        throw new Error(`Traffic request failed: ${response.status}`)
      }

      const trafficData = await response.json()
      console.log("✅ Traffic data received:", trafficData)
      return trafficData
    } catch (error) {
      console.error("❌ Traffic request error:", error)
      return this.getFallbackTrafficData()
    }
  }

  // Get comprehensive delivery factors via secure server endpoint
  async getComprehensiveDeliveryFactors(
    restaurantLat: number,
    restaurantLng: number,
    customerLat: number,
    customerLng: number,
  ): Promise<{
    weather_conditions: string
    road_traffic_density: string
    festival: string
    weather_details: WeatherData
    traffic_details: TrafficData
    data_source: "real_api" | "enhanced_simulation"
  }> {
    try {
      console.log("🔄 Requesting comprehensive delivery factors...")

      const response = await fetch("/api/weather-traffic", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          type: "comprehensive",
          restaurantLat,
          restaurantLng,
          customerLat,
          customerLng,
        }),
        signal: AbortSignal.timeout(15000),
      })

      if (!response.ok) {
        throw new Error(`Comprehensive data request failed: ${response.status}`)
      }

      const comprehensiveData = await response.json()
      console.log("✅ Comprehensive delivery factors received:", comprehensiveData)
      return comprehensiveData
    } catch (error) {
      console.error("❌ Comprehensive data request error:", error)
      return this.getFallbackComprehensiveData()
    }
  }

  // Fallback methods for when server requests fail
  private getFallbackWeatherData(lat: number, lng: number): WeatherData {
    console.log("🔄 Using fallback weather data")
    const month = new Date().getMonth() + 1
    const hour = new Date().getHours()

    let condition = "Sunny"
    let temperature = 25
    let humidity = 60
    let windSpeed = 5
    let visibility = 10

    // Bangalore weather patterns
    if (lat >= 12.8 && lat <= 13.1 && lng >= 77.4 && lng <= 77.8) {
      if (month >= 6 && month <= 9) {
        // Monsoon
        const conditions = ["Stormy", "Cloudy", "Fog"]
        condition = conditions[Math.floor(Math.random() * conditions.length)]
        temperature = 22 + Math.random() * 6
        humidity = 80 + Math.random() * 15
        windSpeed = 8 + Math.random() * 7
        visibility = condition === "Fog" ? 2 + Math.random() * 3 : 8 + Math.random() * 2
      } else if (month >= 12 || month <= 2) {
        // Winter
        const conditions = ["Sunny", "Cloudy", "Fog"]
        condition = conditions[Math.floor(Math.random() * conditions.length)]
        temperature = 15 + Math.random() * 10
        humidity = 50 + Math.random() * 20
        windSpeed = 3 + Math.random() * 5
        visibility = condition === "Fog" ? 1 + Math.random() * 2 : 9 + Math.random() * 1
      } else {
        // Summer
        const conditions = ["Sunny", "Windy", "Cloudy"]
        condition = conditions[Math.floor(Math.random() * conditions.length)]
        temperature = 25 + Math.random() * 10
        humidity = 40 + Math.random() * 20
        windSpeed = condition === "Windy" ? 12 + Math.random() * 8 : 5 + Math.random() * 5
        visibility = 8 + Math.random() * 2
      }
    }

    // Night adjustments
    if (hour >= 18 || hour <= 6) {
      temperature -= 3 + Math.random() * 4
      humidity += 10 + Math.random() * 10
      if (hour >= 22 || (hour <= 6 && Math.random() > 0.7)) {
        condition = "Fog"
        visibility = 1 + Math.random() * 3
      }
    }

    return {
      condition,
      temperature: Math.round(temperature * 10) / 10,
      humidity: Math.round(humidity),
      windSpeed: Math.round(windSpeed * 10) / 10,
      visibility: Math.round(visibility * 10) / 10,
    }
  }

  private getFallbackTrafficData(): TrafficData {
    console.log("🔄 Using fallback traffic data")
    const hour = new Date().getHours()
    const dayOfWeek = new Date().getDay()

    let density = "Low"
    let delayFactor = 5
    let estimatedDelay = 2

    if (dayOfWeek === 0 || dayOfWeek === 6) {
      // Weekend
      if (hour >= 11 && hour <= 14) {
        density = Math.random() > 0.5 ? "Medium" : "Low"
        delayFactor = 15 + Math.random() * 15
        estimatedDelay = 3 + Math.random() * 4
      } else if (hour >= 19 && hour <= 22) {
        density = Math.random() > 0.4 ? "Medium" : "High"
        delayFactor = 20 + Math.random() * 20
        estimatedDelay = 4 + Math.random() * 6
      }
    } else {
      // Weekday
      if (hour >= 7 && hour <= 10) {
        density = Math.random() > 0.2 ? "High" : "Jam"
        delayFactor = 40 + Math.random() * 30
        estimatedDelay = 8 + Math.random() * 10
      } else if (hour >= 12 && hour <= 14) {
        density = Math.random() > 0.3 ? "Medium" : "High"
        delayFactor = 25 + Math.random() * 20
        estimatedDelay = 5 + Math.random() * 6
      } else if (hour >= 17 && hour <= 21) {
        density = Math.random() > 0.1 ? "High" : "Jam"
        delayFactor = 50 + Math.random() * 40
        estimatedDelay = 10 + Math.random() * 15
      } else if (hour >= 22 || hour <= 6) {
        density = "Low"
        delayFactor = 0 + Math.random() * 10
        estimatedDelay = 0 + Math.random() * 2
      } else {
        density = Math.random() > 0.6 ? "Medium" : "Low"
        delayFactor = 10 + Math.random() * 15
        estimatedDelay = 2 + Math.random() * 4
      }
    }

    return {
      density,
      delayFactor: Math.round(delayFactor * 10) / 10,
      estimatedDelay: Math.round(estimatedDelay * 10) / 10,
    }
  }

  private getFallbackComprehensiveData() {
    console.log("🔄 Using fallback comprehensive data")
    return {
      weather_conditions: "Cloudy",
      road_traffic_density: "Medium",
      festival: "No",
      weather_details: {
        condition: "Cloudy",
        temperature: 25,
        humidity: 60,
        windSpeed: 5,
        visibility: 8,
      },
      traffic_details: {
        density: "Medium",
        delayFactor: 20,
        estimatedDelay: 5,
      },
      data_source: "enhanced_simulation" as const,
    }
  }
}

export const secureWeatherTrafficService = new SecureWeatherTrafficService()
