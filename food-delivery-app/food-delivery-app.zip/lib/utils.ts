import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Safe JSON parsing with error handling
export function safeJsonParse(str: string, fallback: any = null) {
  try {
    return JSON.parse(str)
  } catch (error) {
    console.warn("JSON parse error:", error)
    return fallback
  }
}

// Safe localStorage operations
export const storage = {
  get: (key: string, fallback: any = null) => {
    try {
      if (typeof window === "undefined") return fallback
      const item = localStorage.getItem(key)
      return item ? safeJsonParse(item, fallback) : fallback
    } catch (error) {
      console.warn("Storage get error:", error)
      return fallback
    }
  },

  set: (key: string, value: any) => {
    try {
      if (typeof window === "undefined") return
      localStorage.setItem(key, JSON.stringify(value))
    } catch (error) {
      console.warn("Storage set error:", error)
    }
  },

  remove: (key: string) => {
    try {
      if (typeof window === "undefined") return
      localStorage.removeItem(key)
    } catch (error) {
      console.warn("Storage remove error:", error)
    }
  },

  clear: () => {
    try {
      if (typeof window === "undefined") return
      localStorage.clear()
    } catch (error) {
      console.warn("Storage clear error:", error)
    }
  },
}

// Debounce function for performance
export function debounce<T extends (...args: any[]) => any>(func: T, wait: number): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout
  return (...args: Parameters<T>) => {
    clearTimeout(timeout)
    timeout = setTimeout(() => func(...args), wait)
  }
}

// Format currency
export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
  }).format(amount)
}

// Format time
export function formatTime(minutes: number): string {
  if (minutes < 60) {
    return `${minutes} min`
  }
  const hours = Math.floor(minutes / 60)
  const remainingMinutes = minutes % 60
  return `${hours}h ${remainingMinutes}m`
}

// Generate unique ID
export function generateId(): string {
  return Math.random().toString(36).substr(2, 9)
}
