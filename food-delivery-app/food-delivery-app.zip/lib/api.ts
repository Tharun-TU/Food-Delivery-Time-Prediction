// Updated API with dataset-based ML model
import { datasetDeliveryPredictor, type DeliveryPredictionInput } from "./dataset-ml-model"
import { secureWeatherTrafficService } from "./secure-weather-traffic-service"

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:3001/api"

export interface FoodItem {
  id: string
  name: string
  description: string
  price: number
  image: string
  restaurant: string
  rating: number
  deliveryTime: string
  category: string
  isVeg: boolean
  restaurantId: string
  restaurantLocation: {
    latitude: number
    longitude: number
  }
}

export interface OrderData {
  items: Array<{
    id: string
    name: string
    price: number
    quantity: number
    restaurant: string
  }>
  total: number
  customerLocation: {
    latitude: number
    longitude: number
    address: string
  }
  restaurantLocation: {
    latitude: number
    longitude: number
  }
  predictionData: DeliveryPredictionInput
}

// Check if we're in development/preview mode
const isDevelopment = process.env.NODE_ENV !== "production" || !process.env.NEXT_PUBLIC_API_URL

export const api = {
  // Fetch food items
  async getFoodItems(category?: string): Promise<FoodItem[]> {
    if (isDevelopment) {
      console.log("Using mock food items data (development mode)")
      return getMockFoodItems()
    }

    try {
      const url = category ? `${API_BASE_URL}/food-items?category=${category}` : `${API_BASE_URL}/food-items`
      const response = await fetch(url, { signal: AbortSignal.timeout(5000) })
      if (!response.ok) throw new Error("Failed to fetch food items")
      return await response.json()
    } catch (error) {
      console.error("Error fetching food items:", error)
      return getMockFoodItems()
    }
  },

  // Place order with dataset-based ML prediction
  async placeOrder(orderData: OrderData): Promise<{
    order_id: string
    predicted_delivery_time: number
    confidence: number
    factors: any[]
    weather_details?: any
    traffic_details?: any
    data_source?: string
    dataset_stats?: any
  }> {
    try {
      console.log("🧠 Using Dataset-Based ML Model for Prediction")

      // Use our dataset-trained ML model for prediction
      const predictedTime = datasetDeliveryPredictor.predictDeliveryTime(orderData.predictionData)
      const confidence = datasetDeliveryPredictor.getPredictionConfidence(orderData.predictionData)
      const factors = datasetDeliveryPredictor.getDeliveryFactors(orderData.predictionData)
      const datasetStats = datasetDeliveryPredictor.getDatasetStats()

      // Get comprehensive delivery factors via secure server endpoint
      const comprehensiveFactors = await secureWeatherTrafficService.getComprehensiveDeliveryFactors(
        orderData.restaurantLocation.latitude,
        orderData.restaurantLocation.longitude,
        orderData.customerLocation.latitude,
        orderData.customerLocation.longitude,
      )

      console.log("🎯 Dataset-Based ML Results:")
      console.log(`Predicted Time: ${predictedTime} minutes`)
      console.log(`Confidence: ${(confidence * 100).toFixed(1)}%`)
      console.log("Contributing Factors:", factors)
      console.log(`Data Source: ${comprehensiveFactors.data_source}`)
      console.log("Dataset Stats:", datasetStats.sample_patterns)

      if (!isDevelopment) {
        // Try to send to backend if available
        const response = await fetch(`${API_BASE_URL}/orders`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            ...orderData,
            ml_prediction: {
              predicted_time: predictedTime,
              confidence: confidence,
              factors: factors,
              model_type: "dataset_based",
              dataset_stats: datasetStats,
            },
            real_time_data: comprehensiveFactors,
          }),
          signal: AbortSignal.timeout(5000),
        })

        if (response.ok) {
          const result = await response.json()
          return {
            order_id: result.order_id,
            predicted_delivery_time: predictedTime,
            confidence: confidence,
            factors: factors,
            weather_details: comprehensiveFactors.weather_details,
            traffic_details: comprehensiveFactors.traffic_details,
            data_source: comprehensiveFactors.data_source,
            dataset_stats: datasetStats,
          }
        }
      }

      // Return dataset-based ML prediction result with real-time data
      return {
        order_id: `ORD${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
        predicted_delivery_time: predictedTime,
        confidence: confidence,
        factors: factors,
        weather_details: comprehensiveFactors.weather_details,
        traffic_details: comprehensiveFactors.traffic_details,
        data_source: comprehensiveFactors.data_source,
        dataset_stats: datasetStats,
      }
    } catch (error) {
      console.error("Error placing order:", error)
      return mockPlaceOrder()
    }
  },

  // Get order status
  async getOrderStatus(orderId: string) {
    if (isDevelopment) {
      console.log("Using mock order status (development mode)")
      return mockOrderStatus(orderId)
    }

    try {
      const response = await fetch(`${API_BASE_URL}/orders/${orderId}`, {
        signal: AbortSignal.timeout(5000),
      })
      if (!response.ok) throw new Error("Failed to fetch order status")
      return await response.json()
    } catch (error) {
      console.error("Error fetching order status:", error)
      return mockOrderStatus(orderId)
    }
  },

  // Predict delivery time using our dataset-based ML model
  async predictDeliveryTime(predictionData: DeliveryPredictionInput): Promise<{
    predicted_delivery_time: number
    confidence: number
    factors: any[]
    dataset_stats: any
  }> {
    try {
      console.log("🔮 Making Dataset-Based ML prediction with data:", predictionData)

      const predictedTime = datasetDeliveryPredictor.predictDeliveryTime(predictionData)
      const confidence = datasetDeliveryPredictor.getPredictionConfidence(predictionData)
      const factors = datasetDeliveryPredictor.getDeliveryFactors(predictionData)
      const datasetStats = datasetDeliveryPredictor.getDatasetStats()

      return {
        predicted_delivery_time: predictedTime,
        confidence: confidence,
        factors: factors,
        dataset_stats: datasetStats,
      }
    } catch (error) {
      console.error("Error predicting delivery time:", error)
      return {
        predicted_delivery_time: Math.floor(Math.random() * 30) + 20,
        confidence: 0.7,
        factors: [],
        dataset_stats: {},
      }
    }
  },

  // Get secure delivery factors via server endpoint
  async getDeliveryFactors(location: { latitude: number; longitude: number }): Promise<{
    weather_conditions: string
    road_traffic_density: string
    festival: string
    weather_details?: any
    traffic_details?: any
    data_source?: string
  }> {
    try {
      // Use restaurant location as origin (default Bangalore coordinates)
      const restaurantLat = 12.9716
      const restaurantLng = 77.5946

      const comprehensiveFactors = await secureWeatherTrafficService.getComprehensiveDeliveryFactors(
        restaurantLat,
        restaurantLng,
        location.latitude,
        location.longitude,
      )

      console.log("🌤️🚦 Secure Delivery Factors:")
      console.log(
        `Weather: ${comprehensiveFactors.weather_conditions} (${comprehensiveFactors.weather_details.temperature}°C)`,
      )
      console.log(
        `Traffic: ${comprehensiveFactors.road_traffic_density} (${comprehensiveFactors.traffic_details.delayFactor}% delay)`,
      )
      console.log(`Festival: ${comprehensiveFactors.festival}`)
      console.log(`Data Source: ${comprehensiveFactors.data_source}`)

      return {
        weather_conditions: comprehensiveFactors.weather_conditions,
        road_traffic_density: comprehensiveFactors.road_traffic_density,
        festival: comprehensiveFactors.festival,
        weather_details: comprehensiveFactors.weather_details,
        traffic_details: comprehensiveFactors.traffic_details,
        data_source: comprehensiveFactors.data_source,
      }
    } catch (error) {
      console.error("Error getting delivery factors:", error)
      // Fallback to simple random
      const weatherConditions = ["Sunny", "Cloudy", "Windy", "Fog", "conditions Cloudy"]
      const trafficDensities = ["Low", "Medium", "High"]

      return {
        weather_conditions: weatherConditions[Math.floor(Math.random() * weatherConditions.length)],
        road_traffic_density: trafficDensities[Math.floor(Math.random() * trafficDensities.length)],
        festival: Math.random() > 0.9 ? "Yes" : "No",
      }
    }
  },
}

// Mock data functions (unchanged)
function getMockFoodItems(): FoodItem[] {
  return [
    {
      id: "1",
      name: "Margherita Pizza",
      description: "Fresh tomatoes, mozzarella, basil, and olive oil",
      price: 299,
      image: "/placeholder.svg?height=200&width=300",
      restaurant: "Pizza Palace",
      rating: 4.5,
      deliveryTime: "25-30 min",
      category: "Italian",
      isVeg: true,
      restaurantId: "rest_1",
      restaurantLocation: { latitude: 12.9716, longitude: 77.5946 },
    },
    {
      id: "2",
      name: "Chicken Biryani",
      description: "Aromatic basmati rice with tender chicken and spices",
      price: 349,
      image: "/placeholder.svg?height=200&width=300",
      restaurant: "Biryani House",
      rating: 4.7,
      deliveryTime: "35-40 min",
      category: "Indian",
      isVeg: false,
      restaurantId: "rest_2",
      restaurantLocation: { latitude: 12.9716, longitude: 77.5946 },
    },
    {
      id: "3",
      name: "Veg Burger",
      description: "Crispy veggie patty with fresh lettuce and tomatoes",
      price: 199,
      image: "/placeholder.svg?height=200&width=300",
      restaurant: "Burger Junction",
      rating: 4.2,
      deliveryTime: "20-25 min",
      category: "Fast Food",
      isVeg: true,
      restaurantId: "rest_3",
      restaurantLocation: { latitude: 12.9716, longitude: 77.5946 },
    },
    {
      id: "4",
      name: "Pad Thai",
      description: "Stir-fried rice noodles with vegetables and peanuts",
      price: 279,
      image: "/placeholder.svg?height=200&width=300",
      restaurant: "Thai Garden",
      rating: 4.6,
      deliveryTime: "30-35 min",
      category: "Thai",
      isVeg: true,
      restaurantId: "rest_4",
      restaurantLocation: { latitude: 12.9716, longitude: 77.5946 },
    },
    {
      id: "5",
      name: "Chicken Shawarma",
      description: "Grilled chicken wrapped in pita with garlic sauce",
      price: 229,
      image: "/placeholder.svg?height=200&width=300",
      restaurant: "Mediterranean Delights",
      rating: 4.4,
      deliveryTime: "25-30 min",
      category: "Mediterranean",
      isVeg: false,
      restaurantId: "rest_5",
      restaurantLocation: { latitude: 12.9716, longitude: 77.5946 },
    },
    {
      id: "6",
      name: "Chocolate Brownie",
      description: "Rich chocolate brownie with vanilla ice cream",
      price: 149,
      image: "/placeholder.svg?height=200&width=300",
      restaurant: "Sweet Treats",
      rating: 4.8,
      deliveryTime: "15-20 min",
      category: "Dessert",
      isVeg: true,
      restaurantId: "rest_6",
      restaurantLocation: { latitude: 12.9716, longitude: 77.5946 },
    },
  ]
}

function mockPlaceOrder(): {
  order_id: string
  predicted_delivery_time: number
  confidence: number
  factors: any[]
  weather_details?: any
  traffic_details?: any
  data_source?: string
  dataset_stats?: any
} {
  return {
    order_id: `ORD${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
    predicted_delivery_time: Math.floor(Math.random() * 30) + 20,
    confidence: 0.8,
    factors: [],
    data_source: "fallback",
    dataset_stats: {},
  }
}

function mockOrderStatus(orderId: string) {
  const statuses = ["confirmed", "preparing", "picked_up", "on_the_way", "delivered"]
  const randomStatus = statuses[Math.floor(Math.random() * 3)]

  return {
    order_id: orderId,
    status: randomStatus,
    estimated_delivery_time: Math.floor(Math.random() * 20) + 20,
    current_location: {
      latitude: 12.9716 + (Math.random() - 0.5) * 0.01,
      longitude: 77.5946 + (Math.random() - 0.5) * 0.01,
    },
    delivery_person: {
      name: "Raj Kumar",
      phone: "+91 98765 43210",
      rating: 4.8,
    },
  }
}
