// Real-world weather and traffic service integration
export class WeatherTrafficService {
  private readonly WEATHER_API_KEY = process.env.WEATHER_API_KEY
  private readonly TRAFFIC_API_KEY = process.env.TRAFFIC_API_KEY

  // Get real weather data from OpenWeatherMap API
  async getRealWeatherData(lat: number, lng: number): Promise<string> {
    try {
      const response = await fetch(
        `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lng}&appid=${this.WEATHER_API_KEY}`,
      )
      const data = await response.json()

      // Map OpenWeatherMap conditions to our system
      const weatherConditionMap: { [key: string]: string } = {
        "clear sky": "Sunny",
        "few clouds": "Cloudy",
        "scattered clouds": "Cloudy",
        "broken clouds": "Cloudy",
        "overcast clouds": "Cloudy",
        "light rain": "Stormy",
        "moderate rain": "Stormy",
        "heavy rain": "Stormy",
        mist: "Fog",
        fog: "Fog",
        "light snow": "Stormy",
        "heavy snow": "Stormy",
      }

      const condition = data.weather[0].description.toLowerCase()
      return weatherConditionMap[condition] || "Cloudy"
    } catch (error) {
      console.error("Weather API error:", error)
      return this.getSimulatedWeather()
    }
  }

  // Get real traffic data from Google Maps Traffic API
  async getRealTrafficData(originLat: number, originLng: number, destLat: number, destLng: number): Promise<string> {
    try {
      const response = await fetch(
        `https://maps.googleapis.com/maps/api/directions/json?` +
          `origin=${originLat},${originLng}&` +
          `destination=${destLat},${destLng}&` +
          `departure_time=now&` +
          `traffic_model=best_guess&` +
          `key=${this.TRAFFIC_API_KEY}`,
      )
      const data = await response.json()

      if (data.routes && data.routes[0]) {
        const route = data.routes[0].legs[0]
        const normalDuration = route.duration.value // seconds
        const trafficDuration = route.duration_in_traffic.value // seconds

        // Calculate traffic delay percentage
        const delayPercentage = ((trafficDuration - normalDuration) / normalDuration) * 100

        // Map delay to traffic density
        if (delayPercentage < 10) return "Low"
        if (delayPercentage < 30) return "Medium"
        if (delayPercentage < 60) return "High"
        return "Jam"
      }

      return this.getSimulatedTraffic()
    } catch (error) {
      console.error("Traffic API error:", error)
      return this.getSimulatedTraffic()
    }
  }

  // Time-based traffic simulation (more realistic than random)
  getTimeBasedTraffic(): string {
    const hour = new Date().getHours()

    // Morning rush hour (7-10 AM)
    if (hour >= 7 && hour <= 10) {
      return Math.random() > 0.3 ? "High" : "Medium"
    }

    // Lunch time (12-2 PM)
    if (hour >= 12 && hour <= 14) {
      return Math.random() > 0.4 ? "Medium" : "High"
    }

    // Evening rush hour (5-9 PM)
    if (hour >= 17 && hour <= 21) {
      return Math.random() > 0.2 ? "High" : "Jam"
    }

    // Late night (10 PM - 6 AM)
    if (hour >= 22 || hour <= 6) {
      return "Low"
    }

    // Normal hours
    return Math.random() > 0.6 ? "Medium" : "Low"
  }

  // Weather simulation based on season and location
  getSeasonBasedWeather(lat: number, lng: number): string {
    const month = new Date().getMonth() + 1 // 1-12

    // Bangalore weather patterns
    if (lat >= 12.8 && lat <= 13.1 && lng >= 77.4 && lng <= 77.8) {
      // Monsoon season (June-September)
      if (month >= 6 && month <= 9) {
        const conditions = ["Stormy", "Cloudy", "Fog"]
        return conditions[Math.floor(Math.random() * conditions.length)]
      }

      // Winter (December-February)
      if (month >= 12 || month <= 2) {
        const conditions = ["Sunny", "Cloudy", "Fog"]
        return conditions[Math.floor(Math.random() * conditions.length)]
      }

      // Summer (March-May)
      if (month >= 3 && month <= 5) {
        const conditions = ["Sunny", "Windy", "Cloudy"]
        return conditions[Math.floor(Math.random() * conditions.length)]
      }
    }

    // Default conditions
    return this.getSimulatedWeather()
  }

  private getSimulatedWeather(): string {
    const conditions = ["Sunny", "Cloudy", "Windy", "Fog", "conditions Cloudy"]
    return conditions[Math.floor(Math.random() * conditions.length)]
  }

  private getSimulatedTraffic(): string {
    const densities = ["Low", "Medium", "High"]
    return densities[Math.floor(Math.random() * densities.length)]
  }
}

export const weatherTrafficService = new WeatherTrafficService()
