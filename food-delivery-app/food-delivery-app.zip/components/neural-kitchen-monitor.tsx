"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { ChefHat, Thermometer, Timer, Users, TrendingUp, Zap } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

interface NeuralKitchenMonitorProps {
  restaurantId: string
  onKitchenUpdate: (data: any) => void
}

export function NeuralKitchenMonitor({ restaurantId, onKitchenUpdate }: NeuralKitchenMonitorProps) {
  const [kitchenMetrics, setKitchenMetrics] = useState({
    efficiency: 87,
    temperature: 24.5,
    crowdLevel: 3,
    chefPerformance: 92,
    equipmentStatus: 96,
    orderQueue: 7,
  })

  const [realTimeEvents, setRealTimeEvents] = useState<any[]>([])
  const [aiInsights, setAiInsights] = useState<any[]>([])

  useEffect(() => {
    simulateKitchenMonitoring()
    generateAIInsights()
  }, [restaurantId])

  const simulateKitchenMonitoring = () => {
    // Simulate real-time kitchen data updates
    const events = [
      {
        time: "12:30:22",
        event: "Chef efficiency spike detected",
        impact: "Preparation time reduced by 15%",
        type: "positive",
        confidence: 94,
      },
      {
        time: "12:30:45",
        event: "Optimal kitchen temperature reached",
        impact: "Cooking speed increased",
        type: "positive",
        confidence: 89,
      },
      {
        time: "12:31:10",
        event: "New order added to queue",
        impact: "Queue position: 3rd",
        type: "neutral",
        confidence: 100,
      },
      {
        time: "12:31:35",
        event: "Equipment performance optimized",
        impact: "Oven efficiency at 98%",
        type: "positive",
        confidence: 96,
      },
    ]

    events.forEach((event, index) => {
      setTimeout(() => {
        setRealTimeEvents((prev) => [...prev, event])

        // Update metrics based on events
        if (event.type === "positive") {
          setKitchenMetrics((prev) => ({
            ...prev,
            efficiency: Math.min(100, prev.efficiency + Math.random() * 5),
            chefPerformance: Math.min(100, prev.chefPerformance + Math.random() * 3),
          }))
        }
      }, index * 1500)
    })
  }

  const generateAIInsights = () => {
    const insights = [
      {
        title: "Peak Performance Window",
        description: "Kitchen operates 23% faster between 12:30-1:00 PM",
        impact: "Your order timing is optimal",
        confidence: 91,
        icon: TrendingUp,
        color: "text-green-600",
      },
      {
        title: "Chef Behavioral Pattern",
        description: "Head chef shows 15% speed increase after coffee break",
        impact: "Recent break detected - faster preparation expected",
        confidence: 87,
        icon: ChefHat,
        color: "text-blue-600",
      },
      {
        title: "Equipment Learning",
        description: "Oven preheating pattern optimized for current order type",
        impact: "2-3 minutes saved on cooking time",
        confidence: 94,
        icon: Zap,
        color: "text-purple-600",
      },
    ]

    setAiInsights(insights)
  }

  const getEfficiencyColor = (value: number) => {
    if (value >= 90) return "text-green-600"
    if (value >= 75) return "text-yellow-600"
    return "text-red-600"
  }

  const getCrowdLevelText = (level: number) => {
    if (level <= 2) return { text: "Low", color: "bg-green-500" }
    if (level <= 4) return { text: "Moderate", color: "bg-yellow-500" }
    return { text: "High", color: "bg-red-500" }
  }

  return (
    <div className="space-y-6">
      {/* Kitchen Overview */}
      <Card className="bg-gradient-to-br from-orange-50 to-red-50 border-orange-200">
        <CardHeader>
          <CardTitle className="flex items-center text-orange-800">
            <ChefHat className="mr-2 h-5 w-5" />
            Neural Kitchen Intelligence
            <Badge className="ml-auto bg-orange-500 text-white">Live Monitoring</Badge>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <div className="text-center p-3 bg-white/60 rounded-lg">
              <div className={`text-2xl font-bold ${getEfficiencyColor(kitchenMetrics.efficiency)}`}>
                {kitchenMetrics.efficiency}%
              </div>
              <div className="text-sm text-gray-600">Kitchen Efficiency</div>
              <Progress value={kitchenMetrics.efficiency} className="mt-2 h-2" />
            </div>

            <div className="text-center p-3 bg-white/60 rounded-lg">
              <div className="text-2xl font-bold text-blue-600 flex items-center justify-center">
                <Thermometer className="h-5 w-5 mr-1" />
                {kitchenMetrics.temperature}°C
              </div>
              <div className="text-sm text-gray-600">Temperature</div>
            </div>

            <div className="text-center p-3 bg-white/60 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">{kitchenMetrics.orderQueue}</div>
              <div className="text-sm text-gray-600">Orders in Queue</div>
            </div>

            <div className="text-center p-3 bg-white/60 rounded-lg">
              <div className="text-2xl font-bold text-green-600">{kitchenMetrics.chefPerformance}%</div>
              <div className="text-sm text-gray-600">Chef Performance</div>
            </div>

            <div className="text-center p-3 bg-white/60 rounded-lg">
              <div className="flex items-center justify-center">
                <Users className="h-5 w-5 mr-1" />
                <Badge className={getCrowdLevelText(kitchenMetrics.crowdLevel).color}>
                  {getCrowdLevelText(kitchenMetrics.crowdLevel).text}
                </Badge>
              </div>
              <div className="text-sm text-gray-600">Crowd Level</div>
            </div>

            <div className="text-center p-3 bg-white/60 rounded-lg">
              <div className="text-2xl font-bold text-indigo-600">{kitchenMetrics.equipmentStatus}%</div>
              <div className="text-sm text-gray-600">Equipment Status</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* AI Kitchen Insights */}
      <Card className="bg-gradient-to-br from-purple-50 to-indigo-50 border-purple-200">
        <CardHeader>
          <CardTitle className="flex items-center text-purple-800">
            <Zap className="mr-2 h-5 w-5" />
            AI Kitchen Insights
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {aiInsights.map((insight, index) => {
            const Icon = insight.icon
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.2 }}
                className="p-4 bg-white/80 rounded-lg border border-purple-100"
              >
                <div className="flex items-start space-x-3">
                  <div className="p-2 bg-purple-100 rounded-lg">
                    <Icon className={`h-4 w-4 ${insight.color}`} />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-800">{insight.title}</h4>
                    <p className="text-sm text-gray-600 mb-2">{insight.description}</p>
                    <div className="bg-gradient-to-r from-purple-100 to-indigo-100 p-2 rounded">
                      <p className="text-sm font-medium text-purple-700">Impact: {insight.impact}</p>
                    </div>
                  </div>
                  <Badge className="bg-purple-100 text-purple-700">{insight.confidence}% sure</Badge>
                </div>
              </motion.div>
            )
          })}
        </CardContent>
      </Card>

      {/* Real-Time Kitchen Events */}
      <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
        <CardHeader>
          <CardTitle className="flex items-center text-green-800">
            <Timer className="mr-2 h-5 w-5" />
            Live Kitchen Events
            <motion.div
              className="ml-2 w-2 h-2 bg-green-500 rounded-full"
              animate={{ scale: [1, 1.5, 1], opacity: [1, 0.5, 1] }}
              transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY }}
            />
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {realTimeEvents.map((event, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className={`flex items-center justify-between p-3 rounded-lg border ${
                event.type === "positive"
                  ? "bg-green-100 border-green-200"
                  : event.type === "negative"
                    ? "bg-red-100 border-red-200"
                    : "bg-blue-100 border-blue-200"
              }`}
            >
              <div className="flex items-center space-x-3">
                <div
                  className={`w-2 h-2 rounded-full ${
                    event.type === "positive"
                      ? "bg-green-500"
                      : event.type === "negative"
                        ? "bg-red-500"
                        : "bg-blue-500"
                  }`}
                />
                <div>
                  <div className="text-sm font-medium text-gray-800">{event.event}</div>
                  <div className="text-xs text-gray-600">{event.impact}</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs text-gray-500">{event.time}</div>
                <Badge className="text-xs bg-gray-100 text-gray-700">{event.confidence}% confidence</Badge>
              </div>
            </motion.div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}
