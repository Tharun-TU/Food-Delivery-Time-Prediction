"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  RadarChart,
  PolarGrid,
  PolarAngleAxis,
  PolarRadiusAxis,
  Radar,
} from "recharts"
import { TrendingUp, Brain, Target, Activity, BarChart3, PieChartIcon, Zap, Clock, CheckCircle } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { ChartContainer, ChartTooltipContent } from "@/components/ui/chart"

interface MLAnalyticsDashboardProps {
  isVisible: boolean
  onClose: () => void
}

export function MLAnalyticsDashboard({ isVisible, onClose }: MLAnalyticsDashboardProps) {
  const [activeTab, setActiveTab] = useState("accuracy")
  const [realTimeData, setRealTimeData] = useState<any[]>([])

  // Simulate real-time data updates
  useEffect(() => {
    const interval = setInterval(() => {
      const newDataPoint = {
        time: new Date().toLocaleTimeString(),
        accuracy: 85 + Math.random() * 10,
        predictions: Math.floor(Math.random() * 50) + 100,
        confidence: 80 + Math.random() * 15,
      }
      setRealTimeData((prev) => [...prev.slice(-19), newDataPoint])
    }, 2000)

    return () => clearInterval(interval)
  }, [])

  // Sample data for different charts
  const accuracyData = [
    { model: "Dataset ML", accuracy: 92.5, predictions: 15420, avgTime: "45ms" },
    { model: "Rule-based", accuracy: 87.3, predictions: 12890, avgTime: "23ms" },
    { model: "Quantum Sim", accuracy: 94.1, predictions: 8760, avgTime: "120ms" },
    { model: "Neural Kitchen", accuracy: 89.7, predictions: 11230, avgTime: "67ms" },
    { model: "AI Assistant", accuracy: 96.2, predictions: 9870, avgTime: "89ms" },
  ]

  const performanceOverTime = [
    { date: "Jan", accuracy: 85.2, latency: 45, throughput: 1200 },
    { date: "Feb", accuracy: 87.1, latency: 42, throughput: 1350 },
    { date: "Mar", accuracy: 89.3, latency: 38, throughput: 1480 },
    { date: "Apr", accuracy: 91.2, latency: 35, throughput: 1620 },
    { date: "May", accuracy: 92.8, latency: 32, throughput: 1780 },
    { date: "Jun", accuracy: 94.1, latency: 29, throughput: 1920 },
  ]

  const factorImpact = [
    { factor: "Distance", impact: 35, color: "#8884d8" },
    { factor: "Traffic", impact: 28, color: "#82ca9d" },
    { factor: "Weather", impact: 18, color: "#ffc658" },
    { factor: "Vehicle", impact: 12, color: "#ff7300" },
    { factor: "Time", impact: 7, color: "#00ff88" },
  ]

  const predictionDistribution = [
    { range: "15-20 min", count: 2340, percentage: 23.4 },
    { range: "20-25 min", count: 3210, percentage: 32.1 },
    { range: "25-30 min", count: 2890, percentage: 28.9 },
    { range: "30-35 min", count: 1120, percentage: 11.2 },
    { range: "35+ min", count: 440, percentage: 4.4 },
  ]

  const modelComparison = [
    { metric: "Accuracy", datasetML: 92, ruleBased: 87, quantum: 94, neural: 90, aiAssistant: 96 },
    { metric: "Speed", datasetML: 85, ruleBased: 95, quantum: 70, neural: 80, aiAssistant: 75 },
    { metric: "Reliability", datasetML: 90, ruleBased: 85, quantum: 88, neural: 87, aiAssistant: 93 },
    { metric: "Scalability", datasetML: 88, ruleBased: 92, quantum: 75, neural: 85, aiAssistant: 82 },
    { metric: "Interpretability", datasetML: 85, ruleBased: 95, quantum: 60, neural: 70, aiAssistant: 90 },
  ]

  const errorAnalysis = [
    { error: "< 2 min", count: 7890, color: "#00C49F" },
    { error: "2-5 min", count: 1560, color: "#FFBB28" },
    { error: "5-10 min", count: 340, color: "#FF8042" },
    { error: "> 10 min", count: 80, color: "#FF0000" },
  ]

  if (!isVisible) return null

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
    >
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-7xl h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-600 to-blue-600 text-white p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Brain className="h-8 w-8" />
              <div>
                <h2 className="text-2xl font-bold">ML Analytics Dashboard</h2>
                <p className="text-purple-100">Real-time model performance and insights</p>
              </div>
            </div>
            <Button onClick={onClose} variant="outline" className="text-white border-white hover:bg-white/10">
              Close
            </Button>
          </div>

          {/* Tab Navigation */}
          <div className="flex space-x-4 mt-6">
            {[
              { id: "accuracy", label: "Accuracy", icon: Target },
              { id: "performance", label: "Performance", icon: TrendingUp },
              { id: "insights", label: "Insights", icon: Brain },
              { id: "realtime", label: "Real-time", icon: Activity },
            ].map((tab) => {
              const Icon = tab.icon
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all ${
                    activeTab === tab.id ? "bg-white text-purple-600 shadow-lg" : "text-purple-100 hover:bg-white/10"
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{tab.label}</span>
                </button>
              )
            })}
          </div>
        </div>

        {/* Content */}
        <div className="p-6 h-full overflow-y-auto">
          {activeTab === "accuracy" && (
            <div className="space-y-6">
              {/* Model Accuracy Overview */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {accuracyData.map((model, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card className="bg-gradient-to-br from-blue-50 to-purple-50 border-blue-200">
                      <CardHeader className="pb-3">
                        <CardTitle className="text-lg flex items-center justify-between">
                          {model.model}
                          <Badge className="bg-blue-500 text-white">{model.accuracy}%</Badge>
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-600">Predictions</span>
                            <span className="font-semibold">{model.predictions.toLocaleString()}</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span className="text-gray-600">Avg Response</span>
                            <span className="font-semibold">{model.avgTime}</span>
                          </div>
                          <Progress value={model.accuracy} className="h-2" />
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>

              {/* Accuracy Comparison Chart */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <BarChart3 className="mr-2 h-5 w-5" />
                    Model Accuracy Comparison
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ChartContainer
                    config={{
                      accuracy: { label: "Accuracy (%)", color: "hsl(var(--chart-1))" },
                    }}
                    className="h-[300px]"
                  >
                    <BarChart data={accuracyData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="model" />
                      <YAxis />
                      <Tooltip content={<ChartTooltipContent />} />
                      <Bar dataKey="accuracy" fill="var(--color-accuracy)" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ChartContainer>
                </CardContent>
              </Card>

              {/* Error Distribution */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <PieChartIcon className="mr-2 h-5 w-5" />
                    Prediction Error Distribution
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ChartContainer
                    config={{
                      error: { label: "Error Range", color: "hsl(var(--chart-2))" },
                    }}
                    className="h-[300px]"
                  >
                    <PieChart>
                      <Pie
                        data={errorAnalysis}
                        cx="50%"
                        cy="50%"
                        outerRadius={100}
                        fill="#8884d8"
                        dataKey="count"
                        label={({ error, count }) => `${error}: ${count}`}
                      >
                        {errorAnalysis.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ChartContainer>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === "performance" && (
            <div className="space-y-6">
              {/* Performance Over Time */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <TrendingUp className="mr-2 h-5 w-5" />
                    Performance Trends Over Time
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ChartContainer
                    config={{
                      accuracy: { label: "Accuracy (%)", color: "hsl(var(--chart-1))" },
                      latency: { label: "Latency (ms)", color: "hsl(var(--chart-2))" },
                      throughput: { label: "Throughput", color: "hsl(var(--chart-3))" },
                    }}
                    className="h-[400px]"
                  >
                    <LineChart data={performanceOverTime}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="date" />
                      <YAxis />
                      <Tooltip content={<ChartTooltipContent />} />
                      <Legend />
                      <Line
                        type="monotone"
                        dataKey="accuracy"
                        stroke="var(--color-accuracy)"
                        strokeWidth={3}
                        dot={{ r: 6 }}
                      />
                      <Line
                        type="monotone"
                        dataKey="latency"
                        stroke="var(--color-latency)"
                        strokeWidth={3}
                        dot={{ r: 6 }}
                      />
                    </LineChart>
                  </ChartContainer>
                </CardContent>
              </Card>

              {/* Model Comparison Radar */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Target className="mr-2 h-5 w-5" />
                    Multi-dimensional Model Comparison
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ChartContainer
                    config={{
                      datasetML: { label: "Dataset ML", color: "hsl(var(--chart-1))" },
                      quantum: { label: "Quantum", color: "hsl(var(--chart-2))" },
                      aiAssistant: { label: "AI Assistant", color: "hsl(var(--chart-3))" },
                    }}
                    className="h-[400px]"
                  >
                    <RadarChart data={modelComparison}>
                      <PolarGrid />
                      <PolarAngleAxis dataKey="metric" />
                      <PolarRadiusAxis angle={90} domain={[0, 100]} />
                      <Radar
                        name="Dataset ML"
                        dataKey="datasetML"
                        stroke="var(--color-datasetML)"
                        fill="var(--color-datasetML)"
                        fillOpacity={0.1}
                        strokeWidth={2}
                      />
                      <Radar
                        name="Quantum"
                        dataKey="quantum"
                        stroke="var(--color-quantum)"
                        fill="var(--color-quantum)"
                        fillOpacity={0.1}
                        strokeWidth={2}
                      />
                      <Radar
                        name="AI Assistant"
                        dataKey="aiAssistant"
                        stroke="var(--color-aiAssistant)"
                        fill="var(--color-aiAssistant)"
                        fillOpacity={0.1}
                        strokeWidth={2}
                      />
                      <Legend />
                    </RadarChart>
                  </ChartContainer>
                </CardContent>
              </Card>
            </div>
          )}

          {activeTab === "insights" && (
            <div className="space-y-6">
              {/* Factor Impact Analysis */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Brain className="mr-2 h-5 w-5" />
                    Delivery Time Factor Impact Analysis
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ChartContainer
                    config={{
                      impact: { label: "Impact (%)", color: "hsl(var(--chart-1))" },
                    }}
                    className="h-[300px]"
                  >
                    <BarChart data={factorImpact} layout="horizontal">
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis type="number" />
                      <YAxis dataKey="factor" type="category" />
                      <Tooltip content={<ChartTooltipContent />} />
                      <Bar dataKey="impact" fill="var(--color-impact)" radius={[0, 4, 4, 0]} />
                    </BarChart>
                  </ChartContainer>
                </CardContent>
              </Card>

              {/* Prediction Distribution */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Clock className="mr-2 h-5 w-5" />
                    Delivery Time Prediction Distribution
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ChartContainer
                    config={{
                      count: { label: "Orders", color: "hsl(var(--chart-2))" },
                    }}
                    className="h-[300px]"
                  >
                    <AreaChart data={predictionDistribution}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="range" />
                      <YAxis />
                      <Tooltip content={<ChartTooltipContent />} />
                      <Area
                        type="monotone"
                        dataKey="count"
                        stroke="var(--color-count)"
                        fill="var(--color-count)"
                        fillOpacity={0.3}
                      />
                    </AreaChart>
                  </ChartContainer>
                </CardContent>
              </Card>

              {/* Key Insights */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <CheckCircle className="h-8 w-8 text-green-600" />
                      <div>
                        <div className="text-2xl font-bold text-green-700">94.1%</div>
                        <div className="text-sm text-green-600">Overall Accuracy</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-blue-50 to-cyan-50 border-blue-200">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <Zap className="h-8 w-8 text-blue-600" />
                      <div>
                        <div className="text-2xl font-bold text-blue-700">47ms</div>
                        <div className="text-sm text-blue-600">Avg Response Time</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <Activity className="h-8 w-8 text-purple-600" />
                      <div>
                        <div className="text-2xl font-bold text-purple-700">58K+</div>
                        <div className="text-sm text-purple-600">Daily Predictions</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {activeTab === "realtime" && (
            <div className="space-y-6">
              {/* Real-time Performance */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Activity className="mr-2 h-5 w-5" />
                    Real-time Model Performance
                    <Badge className="ml-auto bg-green-500 text-white animate-pulse">LIVE</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ChartContainer
                    config={{
                      accuracy: { label: "Accuracy (%)", color: "hsl(var(--chart-1))" },
                      confidence: { label: "Confidence (%)", color: "hsl(var(--chart-2))" },
                    }}
                    className="h-[300px]"
                  >
                    <LineChart data={realTimeData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="time" />
                      <YAxis />
                      <Tooltip content={<ChartTooltipContent />} />
                      <Line
                        type="monotone"
                        dataKey="accuracy"
                        stroke="var(--color-accuracy)"
                        strokeWidth={2}
                        dot={false}
                      />
                      <Line
                        type="monotone"
                        dataKey="confidence"
                        stroke="var(--color-confidence)"
                        strokeWidth={2}
                        dot={false}
                      />
                    </LineChart>
                  </ChartContainer>
                </CardContent>
              </Card>

              {/* Live Stats */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {[
                  { label: "Current Accuracy", value: "92.8%", trend: "+0.3%", color: "green" },
                  { label: "Active Predictions", value: "1,247", trend: "+12", color: "blue" },
                  { label: "Avg Confidence", value: "89.2%", trend: "+1.1%", color: "purple" },
                  { label: "Response Time", value: "43ms", trend: "-2ms", color: "orange" },
                ].map((stat, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card className="text-center">
                      <CardContent className="p-4">
                        <div className="text-2xl font-bold">{stat.value}</div>
                        <div className="text-sm text-gray-600">{stat.label}</div>
                        <div className={`text-xs text-${stat.color}-600 mt-1`}>{stat.trend}</div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </div>

              {/* System Health */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <CheckCircle className="mr-2 h-5 w-5 text-green-600" />
                    System Health Status
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {[
                      { component: "Dataset ML Model", status: "Healthy", uptime: "99.9%", color: "green" },
                      { component: "AI Assistant", status: "Healthy", uptime: "99.7%", color: "green" },
                      { component: "Quantum Simulator", status: "Warning", uptime: "98.2%", color: "yellow" },
                      { component: "Neural Kitchen", status: "Healthy", uptime: "99.5%", color: "green" },
                    ].map((item, index) => (
                      <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex items-center space-x-3">
                          <div
                            className={`w-3 h-3 rounded-full ${
                              item.color === "green"
                                ? "bg-green-500"
                                : item.color === "yellow"
                                  ? "bg-yellow-500"
                                  : "bg-red-500"
                            }`}
                          />
                          <span className="font-medium">{item.component}</span>
                        </div>
                        <div className="text-right">
                          <div className="text-sm font-semibold">{item.status}</div>
                          <div className="text-xs text-gray-600">{item.uptime} uptime</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  )
}
