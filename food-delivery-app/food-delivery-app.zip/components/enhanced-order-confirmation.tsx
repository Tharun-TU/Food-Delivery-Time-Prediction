"use client"

import { CheckCircle, Clock, MapPin, Phone, Navigation, Sparkles, Gift } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { WeatherTrafficDisplay } from "@/components/weather-traffic-display"
import { useState, useEffect } from "react"

interface EnhancedOrderConfirmationProps {
  deliveryTime: number | null
  orderTotal: number
  orderId: string | null
  onNewOrder: () => void
  onTrackOrder?: () => void
  weatherDetails?: any
  trafficDetails?: any
  dataSource?: "real_api" | "enhanced_simulation"
}

export function EnhancedOrderConfirmation({
  deliveryTime,
  orderTotal,
  orderId,
  onNewOrder,
  onTrackOrder,
  weatherDetails,
  trafficDetails,
  dataSource,
}: EnhancedOrderConfirmationProps) {
  const [showConfetti, setShowConfetti] = useState(true)
  const [timeLeft, setTimeLeft] = useState(deliveryTime || 30)

  useEffect(() => {
    const timer = setTimeout(() => setShowConfetti(false), 3000)
    return () => clearTimeout(timer)
  }, [])

  useEffect(() => {
    if (timeLeft > 0) {
      const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 60000) // Update every minute
      return () => clearTimeout(timer)
    }
  }, [timeLeft])

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 flex items-center justify-center p-4 relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(15)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-4 h-4 bg-green-300 rounded-full opacity-20"
            animate={{
              x: [0, 100, 0],
              y: [0, -100, 0],
              scale: [1, 1.5, 1],
              rotate: [0, 180, 360],
            }}
            transition={{
              duration: 6 + Math.random() * 4,
              repeat: Number.POSITIVE_INFINITY,
              delay: Math.random() * 3,
            }}
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
          />
        ))}
      </div>

      {/* Confetti effect */}
      <AnimatePresence>
        {showConfetti && (
          <div className="absolute inset-0 pointer-events-none">
            {[...Array(50)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-2 h-2 bg-yellow-400 rounded-full"
                initial={{
                  x: "50%",
                  y: "50%",
                  scale: 0,
                }}
                animate={{
                  x: Math.random() * window.innerWidth,
                  y: Math.random() * window.innerHeight,
                  scale: [0, 1, 0],
                  rotate: [0, 360],
                }}
                transition={{
                  duration: 2,
                  delay: Math.random() * 1,
                }}
              />
            ))}
          </div>
        )}
      </AnimatePresence>

      <div className="w-full max-w-2xl space-y-6 relative z-10">
        <motion.div
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ type: "spring", damping: 15, stiffness: 200 }}
        >
          <Card className="bg-white/90 backdrop-blur-sm shadow-2xl border-green-200 overflow-hidden">
            <CardHeader className="text-center bg-gradient-to-br from-green-500 to-emerald-500 text-white rounded-t-lg relative">
              <motion.div
                className="mx-auto mb-4 bg-white/20 rounded-full p-4"
                animate={{ scale: [1, 1.1, 1] }}
                transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
              >
                <CheckCircle className="h-16 w-16 text-white" />
              </motion.div>
              <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.3 }}>
                <CardTitle className="text-2xl">Order Confirmed!</CardTitle>
                <p className="text-green-100">Your delicious food is on its way</p>
              </motion.div>

              {/* Floating sparkles */}
              {[...Array(8)].map((_, i) => (
                <motion.div
                  key={i}
                  className="absolute"
                  animate={{
                    y: [0, -20, 0],
                    opacity: [0, 1, 0],
                    scale: [0, 1, 0],
                  }}
                  transition={{
                    duration: 2,
                    repeat: Number.POSITIVE_INFINITY,
                    delay: i * 0.3,
                  }}
                  style={{
                    left: `${20 + i * 10}%`,
                    top: `${20 + (i % 2) * 40}%`,
                  }}
                >
                  <Sparkles className="h-4 w-4 text-yellow-300" />
                </motion.div>
              ))}
            </CardHeader>

            <CardContent className="space-y-6 p-6">
              <motion.div
                className="text-center"
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.4 }}
              >
                <Badge variant="outline" className="text-lg px-4 py-2 bg-green-50 border-green-200 text-green-700">
                  Order ID: {orderId || "Loading..."}
                </Badge>
              </motion.div>

              <motion.div
                className="bg-gradient-to-br from-blue-50 to-indigo-50 p-6 rounded-lg border border-blue-200 relative overflow-hidden"
                initial={{ scale: 0.9, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                transition={{ delay: 0.5 }}
              >
                <div className="flex items-center justify-center space-x-2 text-blue-700 mb-3">
                  <Clock className="h-5 w-5" />
                  <span className="font-semibold">Estimated Delivery Time</span>
                </div>
                <div className="text-center">
                  <motion.span
                    className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent"
                    animate={{ scale: [1, 1.05, 1] }}
                    transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
                  >
                    {timeLeft} minutes
                  </motion.span>
                </div>
                <p className="text-center text-sm text-blue-600 mt-2">
                  Based on real-time traffic and weather conditions
                </p>

                {/* Countdown animation */}
                <motion.div
                  className="absolute bottom-0 left-0 h-1 bg-gradient-to-r from-blue-500 to-indigo-500"
                  initial={{ width: "100%" }}
                  animate={{ width: "0%" }}
                  transition={{ duration: (timeLeft || 30) * 60, ease: "linear" }}
                />
              </motion.div>

              <motion.div
                className="space-y-3 bg-gradient-to-br from-gray-50 to-orange-50/30 p-4 rounded-lg border border-gray-200"
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.6 }}
              >
                <div className="flex items-center justify-between">
                  <span className="text-gray-600">Order Total</span>
                  <motion.span
                    className="font-semibold text-green-600"
                    animate={{ scale: [1, 1.05, 1] }}
                    transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY }}
                  >
                    ₹{orderTotal + 29 + Math.round(orderTotal * 0.05)}
                  </motion.span>
                </div>

                <div className="flex items-center space-x-2 text-gray-600">
                  <MapPin className="h-4 w-4 text-orange-500" />
                  <span className="text-sm">Delivering to: Home</span>
                </div>

                <div className="flex items-center space-x-2 text-gray-600">
                  <Phone className="h-4 w-4 text-blue-500" />
                  <span className="text-sm">Contact: +91 98765 43210</span>
                </div>
              </motion.div>

              <motion.div
                className="bg-gradient-to-r from-yellow-50 to-orange-50 p-4 rounded-lg border border-yellow-200"
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.7 }}
              >
                <div className="flex items-start space-x-2">
                  <Gift className="h-5 w-5 text-yellow-600 mt-0.5" />
                  <div>
                    <p className="text-sm text-yellow-800 font-medium">Track your order:</p>
                    <p className="text-sm text-yellow-700">
                      You'll receive SMS updates about your order status. Our delivery partner will call you before
                      arriving.
                    </p>
                  </div>
                </div>
              </motion.div>

              <motion.div
                className="space-y-3"
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ delay: 0.8 }}
              >
                <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                  <Button
                    variant="outline"
                    className="w-full border-blue-200 text-blue-700 hover:bg-blue-50"
                    onClick={onTrackOrder}
                  >
                    <Navigation className="mr-2 h-4 w-4" />
                    Track Order
                  </Button>
                </motion.div>
                <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                  <Button
                    onClick={onNewOrder}
                    className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white border-none shadow-lg"
                  >
                    Order Again
                  </Button>
                </motion.div>
              </motion.div>
            </CardContent>
          </Card>
        </motion.div>

        {/* Weather and Traffic Details */}
        <motion.div initial={{ y: 30, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 1 }}>
          <WeatherTrafficDisplay
            weatherDetails={weatherDetails}
            trafficDetails={trafficDetails}
            dataSource={dataSource}
          />
        </motion.div>
      </div>
    </div>
  )
}
