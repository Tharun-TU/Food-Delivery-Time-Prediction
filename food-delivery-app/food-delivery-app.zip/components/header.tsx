"use client"

import { Button } from "@/components/ui/button"
import { ShoppingCart, MapPin, User, Bot, LogOut } from "lucide-react"

interface HeaderProps {
  user: any
  cartItemCount: number
  onCartClick: () => void
  onLogout: () => void
  onShowAI: () => void
}

export function Header({ user, cartItemCount, onCartClick, onLogout, onShowAI }: HeaderProps) {
  return (
    <header className="bg-white shadow-sm border-b sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex items-center">
            <h1 className="text-2xl font-bold bg-gradient-to-r from-orange-500 to-red-500 bg-clip-text text-transparent">
              FoodieAI
            </h1>
          </div>

          {/* User Info */}
          {user && (
            <div className="hidden md:flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <MapPin className="h-4 w-4" />
                <span>{user.location || "Location not set"}</span>
              </div>
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <User className="h-4 w-4" />
                <span>Hello, {user.name}</span>
              </div>
            </div>
          )}

          {/* Actions */}
          <div className="flex items-center space-x-2">
            {/* AI Assistant Button */}
            <Button variant="outline" size="sm" onClick={onShowAI} className="hidden sm:flex items-center space-x-1">
              <Bot className="h-4 w-4" />
              <span>AI Assistant</span>
            </Button>

            {/* Cart Button */}
            <Button variant="outline" size="sm" onClick={onCartClick} className="relative">
              <ShoppingCart className="h-4 w-4" />
              {cartItemCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                  {cartItemCount}
                </span>
              )}
            </Button>

            {/* Logout Button */}
            {user && (
              <Button
                variant="ghost"
                size="sm"
                onClick={onLogout}
                className="text-red-600 hover:text-red-700 hover:bg-red-50"
              >
                <LogOut className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
      </div>
    </header>
  )
}
