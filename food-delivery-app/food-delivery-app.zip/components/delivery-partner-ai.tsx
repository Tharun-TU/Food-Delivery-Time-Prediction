"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { User, MapPin, Zap, Brain, Navigation, Star, Activity } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"

interface DeliveryPartnerAIProps {
  orderId: string
  onPartnerUpdate: (data: any) => void
}

export function DeliveryPartnerAI({ orderId, onPartnerUpdate }: DeliveryPartnerAIProps) {
  const [partnerProfile, setPartnerProfile] = useState({
    name: "Rajesh Kumar",
    rating: 4.8,
    experience: "3.2 years",
    todayDeliveries: 12,
    efficiency: 94,
    routeOptimization: 89,
    customerSatisfaction: 96,
  })

  const [behaviorAnalysis, setBehaviorAnalysis] = useState<any[]>([])
  const [routePrediction, setRoutePrediction] = useState<any>({})
  const [realTimeTracking, setRealTimeTracking] = useState<any[]>([])

  useEffect(() => {
    analyzeBehaviorPatterns()
    predictOptimalRoute()
    startRealTimeTracking()
  }, [orderId])

  const analyzeBehaviorPatterns = () => {
    const patterns = [
      {
        pattern: "Speed Optimization",
        description: "Consistently chooses fastest routes over shortest",
        impact: "3-5 minutes faster delivery",
        confidence: 92,
        trend: "improving",
        icon: Zap,
        color: "text-yellow-600",
      },
      {
        pattern: "Traffic Avoidance",
        description: "Excellent at predicting and avoiding traffic jams",
        impact: "15% better than average partner",
        confidence: 89,
        trend: "stable",
        icon: Navigation,
        color: "text-blue-600",
      },
      {
        pattern: "Customer Communication",
        description: "Proactively calls customers for complex deliveries",
        impact: "98% successful first attempts",
        confidence: 96,
        trend: "improving",
        icon: User,
        color: "text-green-600",
      },
      {
        pattern: "Time Management",
        description: "Arrives within predicted window 94% of time",
        impact: "Highly reliable timing",
        confidence: 94,
        trend: "stable",
        icon: Activity,
        color: "text-purple-600",
      },
    ]

    setBehaviorAnalysis(patterns)
  }

  const predictOptimalRoute = () => {
    const prediction = {
      primaryRoute: {
        name: "AI-Optimized Route A",
        distance: "3.2 km",
        estimatedTime: "12 minutes",
        trafficScore: 85,
        probability: 78,
      },
      alternativeRoute: {
        name: "Backup Route B",
        distance: "3.8 km",
        estimatedTime: "14 minutes",
        trafficScore: 92,
        probability: 22,
      },
      dynamicFactors: [
        "Current traffic: Light",
        "Weather: Clear",
        "Partner preference: Speed over distance",
        "Historical success rate: 94%",
      ],
    }

    setRoutePrediction(prediction)
  }

  const startRealTimeTracking = () => {
    const trackingEvents = [
      {
        time: "12:32:15",
        event: "Partner assigned and notified",
        location: "Restaurant vicinity",
        status: "heading_to_restaurant",
        confidence: 100,
      },
      {
        time: "12:33:45",
        event: "Optimal route calculated",
        location: "En route to restaurant",
        status: "route_optimized",
        confidence: 89,
      },
      {
        time: "12:35:20",
        event: "Traffic pattern analyzed",
        location: "Main road junction",
        status: "traffic_analysis",
        confidence: 94,
      },
      {
        time: "12:36:10",
        event: "ETA updated based on partner speed",
        location: "Restaurant approach",
        status: "eta_refined",
        confidence: 96,
      },
    ]

    trackingEvents.forEach((event, index) => {
      setTimeout(() => {
        setRealTimeTracking((prev) => [...prev, event])
      }, index * 2000)
    })
  }

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "improving":
        return "📈"
      case "declining":
        return "📉"
      default:
        return "➡️"
    }
  }

  return (
    <div className="space-y-6">
      {/* Partner Profile */}
      <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
        <CardHeader>
          <CardTitle className="flex items-center text-blue-800">
            <User className="mr-2 h-5 w-5" />
            AI-Selected Delivery Partner
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center space-x-4 mb-4">
            <Avatar className="h-16 w-16">
              <AvatarFallback className="bg-blue-500 text-white text-lg">RK</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-gray-800">{partnerProfile.name}</h3>
              <div className="flex items-center space-x-2 text-sm text-gray-600">
                <Star className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                <span>{partnerProfile.rating} rating</span>
                <span>•</span>
                <span>{partnerProfile.experience} experience</span>
              </div>
              <Badge className="bg-green-500 text-white mt-1">{partnerProfile.todayDeliveries} deliveries today</Badge>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="text-center p-3 bg-white/60 rounded-lg">
              <div className="text-xl font-bold text-blue-600">{partnerProfile.efficiency}%</div>
              <div className="text-xs text-gray-600">Efficiency</div>
              <Progress value={partnerProfile.efficiency} className="mt-1 h-2" />
            </div>
            <div className="text-center p-3 bg-white/60 rounded-lg">
              <div className="text-xl font-bold text-green-600">{partnerProfile.routeOptimization}%</div>
              <div className="text-xs text-gray-600">Route Optimization</div>
              <Progress value={partnerProfile.routeOptimization} className="mt-1 h-2" />
            </div>
            <div className="text-center p-3 bg-white/60 rounded-lg">
              <div className="text-xl font-bold text-purple-600">{partnerProfile.customerSatisfaction}%</div>
              <div className="text-xs text-gray-600">Customer Satisfaction</div>
              <Progress value={partnerProfile.customerSatisfaction} className="mt-1 h-2" />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Behavior Analysis */}
      <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
        <CardHeader>
          <CardTitle className="flex items-center text-purple-800">
            <Brain className="mr-2 h-5 w-5" />
            Partner Behavior Analysis
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {behaviorAnalysis.map((analysis, index) => {
            const Icon = analysis.icon
            return (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                className="p-4 bg-white/80 rounded-lg border border-purple-100"
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center space-x-3">
                    <div className="p-2 bg-purple-100 rounded-lg">
                      <Icon className={`h-4 w-4 ${analysis.color}`} />
                    </div>
                    <div>
                      <h4 className="font-semibold text-gray-800">{analysis.pattern}</h4>
                      <p className="text-sm text-gray-600">{analysis.description}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge className="bg-purple-100 text-purple-700">{analysis.confidence}%</Badge>
                    <div className="text-xs text-gray-500 mt-1">
                      {getTrendIcon(analysis.trend)} {analysis.trend}
                    </div>
                  </div>
                </div>
                <div className="bg-gradient-to-r from-purple-100 to-pink-100 p-2 rounded">
                  <p className="text-sm font-medium text-purple-700">Impact: {analysis.impact}</p>
                </div>
              </motion.div>
            )
          })}
        </CardContent>
      </Card>

      {/* Route Prediction */}
      <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
        <CardHeader>
          <CardTitle className="flex items-center text-green-800">
            <Navigation className="mr-2 h-5 w-5" />
            AI Route Prediction
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 bg-white/80 rounded-lg border border-green-100">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-semibold text-green-800">Primary Route</h4>
                <Badge className="bg-green-500 text-white">{routePrediction.primaryRoute?.probability}% likely</Badge>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Distance:</span>
                  <span className="font-medium">{routePrediction.primaryRoute?.distance}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Time:</span>
                  <span className="font-medium">{routePrediction.primaryRoute?.estimatedTime}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Traffic Score:</span>
                  <span className="font-medium">{routePrediction.primaryRoute?.trafficScore}/100</span>
                </div>
              </div>
            </div>

            <div className="p-4 bg-white/60 rounded-lg border border-green-100">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-semibold text-gray-700">Backup Route</h4>
                <Badge className="bg-gray-400 text-white">
                  {routePrediction.alternativeRoute?.probability}% likely
                </Badge>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Distance:</span>
                  <span className="font-medium">{routePrediction.alternativeRoute?.distance}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Time:</span>
                  <span className="font-medium">{routePrediction.alternativeRoute?.estimatedTime}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Traffic Score:</span>
                  <span className="font-medium">{routePrediction.alternativeRoute?.trafficScore}/100</span>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white/80 rounded-lg p-3 border border-green-100">
            <h5 className="font-medium text-green-800 mb-2">Dynamic Factors Considered:</h5>
            <ul className="text-sm text-gray-600 space-y-1">
              {routePrediction.dynamicFactors?.map((factor: string, index: number) => (
                <li key={index} className="flex items-center">
                  <div className="w-1 h-1 bg-green-500 rounded-full mr-2" />
                  {factor}
                </li>
              ))}
            </ul>
          </div>
        </CardContent>
      </Card>

      {/* Real-Time Tracking */}
      <Card className="bg-gradient-to-br from-orange-50 to-red-50 border-orange-200">
        <CardHeader>
          <CardTitle className="flex items-center text-orange-800">
            <MapPin className="mr-2 h-5 w-5" />
            Real-Time Partner Tracking
            <motion.div
              className="ml-2 w-2 h-2 bg-orange-500 rounded-full"
              animate={{ scale: [1, 1.5, 1], opacity: [1, 0.5, 1] }}
              transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY }}
            />
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {realTimeTracking.map((event, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center justify-between p-3 bg-white/80 rounded-lg border border-orange-100"
            >
              <div className="flex items-center space-x-3">
                <div className="w-2 h-2 bg-orange-500 rounded-full" />
                <div>
                  <div className="text-sm font-medium text-gray-800">{event.event}</div>
                  <div className="text-xs text-gray-600">{event.location}</div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs text-gray-500">{event.time}</div>
                <Badge className="text-xs bg-orange-100 text-orange-700">{event.confidence}% confidence</Badge>
              </div>
            </motion.div>
          ))}
        </CardContent>
      </Card>
    </div>
  )
}
