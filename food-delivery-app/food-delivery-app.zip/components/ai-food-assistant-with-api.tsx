"use client"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import {
  MessageCircle,
  Send,
  Bot,
  User,
  Sparkles,
  TrendingUp,
  Heart,
  Zap,
  Sun,
  Moon,
  Coffee,
  Utensils,
  Brain,
  X,
  Settings,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar } from "@/components/ui/avatar"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

interface Message {
  id: string
  type: "user" | "assistant"
  content: string
  timestamp: Date
  suggestions?: FoodSuggestion[]
  analytics?: any
}

interface FoodSuggestion {
  name: string
  restaurant: string
  price: number
  rating: number
  healthScore: number
  calories: number
  deliveryTime: string
  nutritionHighlights: string[]
  healthTags: string[]
  description: string
  image: string
}

type AIProvider = "openai" | "gemini" | "claude" | "local"

export function AIFoodAssistantWithAPI() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([])
  const [inputValue, setInputValue] = useState("")
  const [isListening, setIsListening] = useState(false)
  const [isTyping, setIsTyping] = useState(false)
  const [showSettings, setShowSettings] = useState(false)
  const [aiProvider, setAIProvider] = useState<AIProvider>("openai")
  const [apiKey, setApiKey] = useState("")
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  // AI API Integration Functions
  const callOpenAI = async (message: string): Promise<string> => {
    try {
      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({
          model: "gpt-4",
          messages: [
            {
              role: "system",
              content: `You are a professional nutritionist and food expert AI assistant for a food delivery app. 
              Your expertise includes:
              - Nutritional science and dietary recommendations
              - Food pairing and meal planning
              - Health-conscious food choices
              - Restaurant and cuisine knowledge
              - Dietary restrictions and allergies
              
              Always provide helpful, accurate, and personalized food recommendations. 
              Include specific nutritional benefits and explain your reasoning.
              Keep responses conversational but informative.
              If suggesting foods, mention calories, health benefits, and why it's good for the user's specific needs.`,
            },
            {
              role: "user",
              content: message,
            },
          ],
          max_tokens: 500,
          temperature: 0.7,
        }),
      })

      const data = await response.json()
      return data.choices[0]?.message?.content || "I'm having trouble processing that request right now."
    } catch (error) {
      console.error("OpenAI API Error:", error)
      return "I'm experiencing some technical difficulties. Please try again later."
    }
  }

  const callGemini = async (message: string): Promise<string> => {
    try {
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${apiKey}`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            contents: [
              {
                parts: [
                  {
                    text: `You are a professional nutritionist and food expert AI assistant. 
                    User question: ${message}
                    
                    Please provide helpful food and nutrition advice, including specific recommendations with health benefits.`,
                  },
                ],
              },
            ],
            generationConfig: {
              temperature: 0.7,
              maxOutputTokens: 500,
            },
          }),
        },
      )

      const data = await response.json()
      return data.candidates[0]?.content?.parts[0]?.text || "I'm having trouble processing that request right now."
    } catch (error) {
      console.error("Gemini API Error:", error)
      return "I'm experiencing some technical difficulties. Please try again later."
    }
  }

  const callClaude = async (message: string): Promise<string> => {
    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": apiKey,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: "claude-3-sonnet-20240229",
          max_tokens: 500,
          messages: [
            {
              role: "user",
              content: `You are a professional nutritionist and food expert AI assistant for a food delivery app. 
              Please help with this food/nutrition question: ${message}
              
              Provide specific, helpful recommendations with nutritional benefits and reasoning.`,
            },
          ],
        }),
      })

      const data = await response.json()
      return data.content[0]?.text || "I'm having trouble processing that request right now."
    } catch (error) {
      console.error("Claude API Error:", error)
      return "I'm experiencing some technical difficulties. Please try again later."
    }
  }

  // Local fallback (existing logic)
  const getLocalAIResponse = (userMessage: string): string => {
    const message = userMessage.toLowerCase()
    const currentHour = new Date().getHours()

    if (message.includes("stressed") || message.includes("anxiety")) {
      return "I understand you're feeling stressed. Foods rich in magnesium like dark chocolate, nuts, and leafy greens can help reduce cortisol levels. Omega-3 fatty acids from salmon also support brain health and stress reduction. Would you like specific meal recommendations?"
    }

    if (message.includes("energy") || message.includes("tired")) {
      return "For sustained energy, I recommend complex carbohydrates paired with protein. Try quinoa bowls with lean protein, or oatmeal with nuts and berries. These provide steady glucose release without energy crashes. B-vitamins in whole grains also support energy metabolism!"
    }

    if (message.includes("weight loss") || message.includes("diet")) {
      return "For healthy weight management, focus on high-fiber, protein-rich foods that keep you satisfied. Lean proteins boost metabolism by 30%, while fiber helps with satiety. I'd suggest grilled chicken salads, lentil soups, or vegetable-packed stir-fries. What's your preferred cuisine?"
    }

    return "I'm here to help with all your nutrition and food questions! I can provide personalized recommendations based on your health goals, dietary preferences, mood, or any specific needs you have. What would you like to know about?"
  }

  // Generate food suggestions based on AI response
  const generateFoodSuggestions = (aiResponse: string, userMessage: string): FoodSuggestion[] => {
    const message = userMessage.toLowerCase()

    if (message.includes("stressed")) {
      return [
        {
          name: "Salmon Quinoa Bowl",
          restaurant: "Healthy Harbor",
          price: 16.99,
          rating: 4.8,
          healthScore: 95,
          calories: 420,
          deliveryTime: "25-30 min",
          nutritionHighlights: ["Omega-3", "Magnesium", "Complete Protein"],
          healthTags: ["Stress Relief", "Brain Health", "Anti-inflammatory"],
          description: "Wild salmon with quinoa, avocado, and stress-busting leafy greens",
          image: "/placeholder.svg?height=120&width=120",
        },
      ]
    }

    if (message.includes("energy")) {
      return [
        {
          name: "Power Smoothie Bowl",
          restaurant: "Energy Boost Cafe",
          price: 12.99,
          rating: 4.7,
          healthScore: 92,
          calories: 380,
          deliveryTime: "15-20 min",
          nutritionHighlights: ["B-Vitamins", "Natural Caffeine", "Antioxidants"],
          healthTags: ["Energy Boost", "Pre-Workout", "Metabolism"],
          description: "Acai, matcha, banana, and energy-boosting superfoods",
          image: "/placeholder.svg?height=120&width=120",
        },
      ]
    }

    return []
  }

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      type: "user",
      content: inputValue,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    const currentInput = inputValue
    setInputValue("")
    setIsTyping(true)

    try {
      let aiResponse: string

      // Call appropriate AI API based on selected provider
      switch (aiProvider) {
        case "openai":
          aiResponse = apiKey ? await callOpenAI(currentInput) : getLocalAIResponse(currentInput)
          break
        case "gemini":
          aiResponse = apiKey ? await callGemini(currentInput) : getLocalAIResponse(currentInput)
          break
        case "claude":
          aiResponse = apiKey ? await callClaude(currentInput) : getLocalAIResponse(currentInput)
          break
        default:
          aiResponse = getLocalAIResponse(currentInput)
      }

      const suggestions = generateFoodSuggestions(aiResponse, currentInput)

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: "assistant",
        content: aiResponse,
        timestamp: new Date(),
        suggestions: suggestions,
        analytics: {
          provider: aiProvider,
          confidence: apiKey ? 95 : 85,
          responseTime: "1.2s",
        },
      }

      setMessages((prev) => [...prev, assistantMessage])
    } catch (error) {
      console.error("AI API Error:", error)
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: "assistant",
        content:
          "I apologize, but I'm experiencing technical difficulties. Let me help you with my built-in knowledge instead!",
        timestamp: new Date(),
      }
      setMessages((prev) => [...prev, errorMessage])
    } finally {
      setIsTyping(false)
    }
  }

  const quickActions = [
    { icon: Heart, label: "I'm feeling stressed", color: "bg-red-100 text-red-600" },
    { icon: Zap, label: "Need energy boost", color: "bg-yellow-100 text-yellow-600" },
    { icon: TrendingUp, label: "Weight loss help", color: "bg-green-100 text-green-600" },
    { icon: Sun, label: "Hot weather foods", color: "bg-orange-100 text-orange-600" },
    { icon: Moon, label: "Late night snack", color: "bg-purple-100 text-purple-600" },
    { icon: Coffee, label: "Morning nutrition", color: "bg-brown-100 text-brown-600" },
    { icon: Utensils, label: "Comfort food", color: "bg-blue-100 text-blue-600" },
    { icon: Brain, label: "Brain food", color: "bg-indigo-100 text-indigo-600" },
  ]

  if (!isOpen) {
    return (
      <motion.div
        className="fixed bottom-6 right-6 z-50"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <Button
          onClick={() => setIsOpen(true)}
          className="h-16 w-16 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 shadow-2xl"
        >
          <MessageCircle className="h-8 w-8 text-white" />
        </Button>
      </motion.div>
    )
  }

  return (
    <>
      <motion.div
        className="fixed bottom-6 right-6 w-96 h-[600px] bg-white rounded-2xl shadow-2xl z-50 flex flex-col overflow-hidden border border-purple-200"
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0, opacity: 0 }}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-500 to-pink-500 text-white p-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Avatar className="h-10 w-10 bg-white/20">
                <Bot className="h-6 w-6 text-white" />
              </Avatar>
              <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-400 rounded-full border-2 border-white"></div>
            </div>
            <div>
              <h3 className="font-semibold">AI Nutrition Expert</h3>
              <p className="text-xs text-purple-100">
                Powered by{" "}
                {aiProvider === "openai"
                  ? "GPT-4"
                  : aiProvider === "gemini"
                    ? "Gemini Pro"
                    : aiProvider === "claude"
                      ? "Claude 3"
                      : "Local AI"}
              </p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              onClick={() => setShowSettings(!showSettings)}
              variant="ghost"
              size="sm"
              className="text-white hover:bg-white/10 p-2"
            >
              <Settings className="h-4 w-4" />
            </Button>
            <Button
              onClick={() => setIsOpen(false)}
              variant="ghost"
              size="sm"
              className="text-white hover:bg-white/20 rounded-full h-8 w-8 p-0 transition-all hover:scale-110"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Settings Panel */}
        {showSettings && (
          <div className="bg-gray-50 p-4 border-b">
            <div className="space-y-3">
              <div>
                <label className="text-sm font-medium text-gray-700">AI Provider</label>
                <Select value={aiProvider} onValueChange={(value: AIProvider) => setAIProvider(value)}>
                  <SelectTrigger className="w-full mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="openai">OpenAI GPT-4</SelectItem>
                    <SelectItem value="gemini">Google Gemini Pro</SelectItem>
                    <SelectItem value="claude">Anthropic Claude 3</SelectItem>
                    <SelectItem value="local">Local AI (Free)</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {aiProvider !== "local" && (
                <div>
                  <label className="text-sm font-medium text-gray-700">API Key</label>
                  <Input
                    type="password"
                    value={apiKey}
                    onChange={(e) => setApiKey(e.target.value)}
                    placeholder="Enter your API key"
                    className="mt-1"
                  />
                  <p className="text-xs text-gray-500 mt-1">
                    {aiProvider === "openai" && "Get your key from platform.openai.com"}
                    {aiProvider === "gemini" && "Get your key from makersuite.google.com"}
                    {aiProvider === "claude" && "Get your key from console.anthropic.com"}
                  </p>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-purple-50/30 to-pink-50/30">
          {messages.length === 0 && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center py-8">
              <Sparkles className="h-12 w-12 text-purple-400 mx-auto mb-4" />
              <h4 className="font-semibold text-gray-800 mb-2">Welcome to AI Nutrition Expert!</h4>
              <p className="text-sm text-gray-600 mb-6">
                I'm powered by advanced AI models and can provide personalized nutrition advice, meal recommendations,
                and dietary guidance!
              </p>

              {/* Quick Actions */}
              <div className="grid grid-cols-2 gap-2">
                {quickActions.map((action, index) => {
                  const Icon = action.icon
                  return (
                    <motion.button
                      key={index}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: index * 0.1 }}
                      onClick={() => {
                        setInputValue(action.label)
                        handleSendMessage()
                      }}
                      className={`p-3 rounded-lg ${action.color} hover:scale-105 transition-all text-xs font-medium flex items-center space-x-2`}
                    >
                      <Icon className="h-4 w-4" />
                      <span>{action.label}</span>
                    </motion.button>
                  )
                })}
              </div>
            </motion.div>
          )}

          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${message.type === "user" ? "justify-end" : "justify-start"}`}
            >
              <div className={`flex items-start space-x-2 max-w-[85%]`}>
                {message.type === "assistant" && (
                  <Avatar className="h-8 w-8 bg-gradient-to-r from-purple-400 to-pink-400">
                    <Bot className="h-4 w-4 text-white" />
                  </Avatar>
                )}

                <div>
                  <div
                    className={`p-3 rounded-2xl ${
                      message.type === "user"
                        ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white"
                        : "bg-white shadow-md border border-purple-100"
                    }`}
                  >
                    <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                    {message.analytics && (
                      <div className="mt-2 flex items-center space-x-2 text-xs opacity-75">
                        <Badge className="bg-purple-100 text-purple-700 text-xs">
                          {message.analytics.provider} • {message.analytics.confidence}% confident
                        </Badge>
                      </div>
                    )}
                  </div>

                  {/* Food Suggestions */}
                  {message.suggestions && message.suggestions.length > 0 && (
                    <div className="mt-3 space-y-3">
                      {message.suggestions.map((suggestion, index) => (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: index * 0.1 }}
                          className="bg-white rounded-xl p-4 shadow-lg border border-purple-100 hover:shadow-xl transition-all cursor-pointer"
                        >
                          <div className="flex items-start space-x-3">
                            <img
                              src={suggestion.image || "/placeholder.svg"}
                              alt={suggestion.name}
                              className="w-16 h-16 rounded-lg object-cover"
                            />
                            <div className="flex-1">
                              <div className="flex items-start justify-between">
                                <div>
                                  <h4 className="font-semibold text-gray-800 text-sm">{suggestion.name}</h4>
                                  <p className="text-xs text-gray-600">{suggestion.restaurant}</p>
                                </div>
                                <div className="text-right">
                                  <div className="font-bold text-purple-600">${suggestion.price}</div>
                                  <div className="text-xs text-gray-500">⭐ {suggestion.rating}</div>
                                </div>
                              </div>

                              <p className="text-xs text-gray-600 mt-1 mb-2">{suggestion.description}</p>

                              <div className="flex items-center justify-between text-xs mb-2">
                                <span className="text-gray-600">{suggestion.calories} cal</span>
                                <Badge className="bg-green-100 text-green-700">
                                  Health: {suggestion.healthScore}/100
                                </Badge>
                                <span className="text-purple-600">{suggestion.deliveryTime}</span>
                              </div>

                              <div className="flex flex-wrap gap-1 mb-2">
                                {suggestion.healthTags.slice(0, 2).map((tag, tagIndex) => (
                                  <Badge key={tagIndex} className="bg-purple-100 text-purple-700 text-xs px-2 py-1">
                                    {tag}
                                  </Badge>
                                ))}
                              </div>

                              <div className="text-xs text-gray-500">
                                <strong>Benefits:</strong> {suggestion.nutritionHighlights.join(", ")}
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  )}

                  <div className="text-xs text-gray-400 mt-1">
                    {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </div>
                </div>

                {message.type === "user" && (
                  <Avatar className="h-8 w-8 bg-gradient-to-r from-blue-400 to-cyan-400">
                    <User className="h-4 w-4 text-white" />
                  </Avatar>
                )}
              </div>
            </motion.div>
          ))}

          {isTyping && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-start space-x-2">
              <Avatar className="h-8 w-8 bg-gradient-to-r from-purple-400 to-pink-400">
                <Bot className="h-4 w-4 text-white" />
              </Avatar>
              <div className="bg-white p-3 rounded-2xl shadow-md border border-purple-100">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce"></div>
                  <div
                    className="w-2 h-2 bg-purple-400 rounded-full animate-bounce"
                    style={{ animationDelay: "0.1s" }}
                  ></div>
                  <div
                    className="w-2 h-2 bg-purple-400 rounded-full animate-bounce"
                    style={{ animationDelay: "0.2s" }}
                  ></div>
                </div>
              </div>
            </motion.div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-4 border-t border-purple-100 bg-white">
          <div className="flex items-center space-x-2">
            <div className="flex-1 relative">
              <Input
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                placeholder="Ask me anything about nutrition, diet, or food recommendations..."
                className="pr-12 border-purple-200 focus:border-purple-400"
              />
            </div>
            <Button
              onClick={handleSendMessage}
              disabled={!inputValue.trim() || isTyping}
              className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </motion.div>
    </>
  )
}
