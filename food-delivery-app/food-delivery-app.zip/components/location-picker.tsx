"use client"

import { useState } from "react"
import { MapPin, Navigation, Search, Target } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { useLocation } from "@/hooks/use-location"

interface LocationPickerProps {
  onLocationSelect: (location: { latitude: number; longitude: number; address: string }) => void
  isOpen: boolean
  onClose: () => void
}

export function LocationPicker({ onLocationSelect, isOpen, onClose }: LocationPickerProps) {
  const { location, loading, error, getCurrentLocation, setTestLocation } = useLocation()
  const [searchQuery, setSearchQuery] = useState("")

  if (!isOpen) return null

  const handleUseCurrentLocation = () => {
    getCurrentLocation()
    if (location) {
      onLocationSelect(location)
      onClose()
    }
  }

  const handleSearchLocation = () => {
    // Mock search with realistic coordinates
    const searchResults = {
      koramangala: { lat: 12.9352, lng: 77.6245, name: "Koramangala, Bangalore" },
      indiranagar: { lat: 12.9719, lng: 77.6412, name: "Indiranagar, Bangalore" },
      whitefield: { lat: 12.9698, lng: 77.75, name: "Whitefield, Bangalore" },
      "electronic city": { lat: 12.8456, lng: 77.6603, name: "Electronic City, Bangalore" },
    }

    const query = searchQuery.toLowerCase()
    const result = Object.entries(searchResults).find(([key]) => query.includes(key))

    let mockLocation
    if (result) {
      const [, coords] = result
      mockLocation = {
        latitude: coords.lat,
        longitude: coords.lng,
        address: coords.name,
      }
    } else {
      // Random location around Bangalore
      mockLocation = {
        latitude: 12.9716 + (Math.random() - 0.5) * 0.1,
        longitude: 77.5946 + (Math.random() - 0.5) * 0.1,
        address: searchQuery || "Searched location",
      }
    }

    onLocationSelect(mockLocation)
    onClose()
  }

  const handleTestLocation = (testType: string) => {
    setTestLocation(testType)
    if (location) {
      onLocationSelect(location)
      onClose()
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-white/95 backdrop-blur-sm shadow-2xl border-blue-200">
        <CardHeader className="bg-gradient-to-r from-blue-500 to-indigo-500 text-white rounded-t-lg">
          <CardTitle className="flex items-center">
            <MapPin className="mr-2 h-5 w-5" />
            Select Delivery Location
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 p-6">
          <div className="space-y-2">
            <div className="flex space-x-2">
              <Input
                placeholder="Try: Koramangala, Indiranagar, Whitefield..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="flex-1 border-blue-200 focus:border-blue-400 focus:ring-blue-200"
              />
              <Button
                onClick={handleSearchLocation}
                size="sm"
                className="bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600 text-white border-none"
              >
                <Search className="h-4 w-4" />
              </Button>
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <div className="flex-1 border-t border-gray-200"></div>
            <span className="text-sm text-gray-500 bg-gray-50 px-2 py-1 rounded">OR</span>
            <div className="flex-1 border-t border-gray-200"></div>
          </div>

          <Button
            onClick={handleUseCurrentLocation}
            disabled={loading}
            className="w-full bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white border-none"
            variant="outline"
          >
            <Navigation className="mr-2 h-4 w-4" />
            {loading ? "Getting location..." : "Use Current Location"}
          </Button>

          {/* Test Distance Buttons */}
          <div className="space-y-2">
            <p className="text-sm text-gray-600 font-medium">🧪 Test Different Distances:</p>
            <div className="grid grid-cols-2 gap-2">
              <Button onClick={() => handleTestLocation("nearby")} variant="outline" size="sm" className="text-xs">
                <Target className="mr-1 h-3 w-3" />
                Nearby (0.5km)
              </Button>
              <Button onClick={() => handleTestLocation("medium")} variant="outline" size="sm" className="text-xs">
                <Target className="mr-1 h-3 w-3" />
                Medium (2km)
              </Button>
              <Button onClick={() => handleTestLocation("far")} variant="outline" size="sm" className="text-xs">
                <Target className="mr-1 h-3 w-3" />
                Far (5km)
              </Button>
              <Button onClick={() => handleTestLocation("very_far")} variant="outline" size="sm" className="text-xs">
                <Target className="mr-1 h-3 w-3" />
                Very Far (15km)
              </Button>
            </div>
          </div>

          {error && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3">
              <p className="text-sm text-red-600">{error}</p>
            </div>
          )}

          {location && (
            <div className="bg-gradient-to-r from-green-50 to-emerald-50 p-3 rounded-lg border border-green-200">
              <p className="text-sm font-medium text-green-800">Current Location:</p>
              <p className="text-sm text-green-600">{location.address}</p>
              <p className="text-xs text-green-500 mt-1">
                📍 {location.latitude.toFixed(4)}, {location.longitude.toFixed(4)}
              </p>
            </div>
          )}

          <div className="flex space-x-2">
            <Button
              onClick={onClose}
              variant="outline"
              className="flex-1 border-gray-300 text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </Button>
            <Button
              onClick={() => location && onLocationSelect(location)}
              disabled={!location}
              className="flex-1 bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600 text-white border-none"
            >
              Confirm Location
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
