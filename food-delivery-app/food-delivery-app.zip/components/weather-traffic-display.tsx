"use client"

import { Cloud, Sun, CloudRain, Wind, Eye, Thermometer, Droplets, Car, Clock, AlertTriangle } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

interface WeatherTrafficDisplayProps {
  weatherDetails?: {
    condition: string
    temperature: number
    humidity: number
    windSpeed: number
    visibility: number
  }
  trafficDetails?: {
    density: string
    delayFactor: number
    estimatedDelay: number
  }
  dataSource?: "real_api" | "enhanced_simulation"
}

export function WeatherTrafficDisplay({ weatherDetails, trafficDetails, dataSource }: WeatherTrafficDisplayProps) {
  if (!weatherDetails && !trafficDetails) return null

  const getWeatherIcon = (condition: string) => {
    switch (condition.toLowerCase()) {
      case "sunny":
        return <Sun className="h-5 w-5 text-yellow-500" />
      case "cloudy":
        return <Cloud className="h-5 w-5 text-gray-500" />
      case "stormy":
        return <CloudRain className="h-5 w-5 text-blue-600" />
      case "windy":
        return <Wind className="h-5 w-5 text-blue-400" />
      case "fog":
        return <Cloud className="h-5 w-5 text-gray-400" />
      default:
        return <Cloud className="h-5 w-5 text-gray-500" />
    }
  }

  const getTrafficColor = (density: string) => {
    switch (density.toLowerCase()) {
      case "low":
        return "text-green-600 bg-green-50 border-green-200"
      case "medium":
        return "text-yellow-600 bg-yellow-50 border-yellow-200"
      case "high":
        return "text-orange-600 bg-orange-50 border-orange-200"
      case "jam":
        return "text-red-600 bg-red-50 border-red-200"
      default:
        return "text-gray-600 bg-gray-50 border-gray-200"
    }
  }

  return (
    <div className="space-y-4">
      {/* Data Source Indicator */}
      <div className="flex justify-center">
        <Badge
          variant="outline"
          className={`${dataSource === "real_api" ? "bg-green-50 border-green-200 text-green-700" : "bg-blue-50 border-blue-200 text-blue-700"}`}
        >
          {dataSource === "real_api" ? "🌐 Real-time Data" : "🤖 Enhanced Simulation"}
        </Badge>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Weather Card */}
        {weatherDetails && (
          <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center text-lg text-blue-800">
                {getWeatherIcon(weatherDetails.condition)}
                <span className="ml-2">Weather Conditions</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-blue-700 font-medium">{weatherDetails.condition}</span>
                <div className="flex items-center text-blue-600">
                  <Thermometer className="h-4 w-4 mr-1" />
                  <span className="font-semibold">{weatherDetails.temperature}°C</span>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3 text-sm">
                <div className="flex items-center text-blue-600">
                  <Droplets className="h-3 w-3 mr-1" />
                  <span>{weatherDetails.humidity}% humidity</span>
                </div>
                <div className="flex items-center text-blue-600">
                  <Wind className="h-3 w-3 mr-1" />
                  <span>{weatherDetails.windSpeed} km/h</span>
                </div>
                <div className="flex items-center text-blue-600 col-span-2">
                  <Eye className="h-3 w-3 mr-1" />
                  <span>{weatherDetails.visibility} km visibility</span>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Traffic Card */}
        {trafficDetails && (
          <Card className="bg-gradient-to-br from-orange-50 to-red-50 border-orange-200">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center text-lg text-orange-800">
                <Car className="h-5 w-5 text-orange-600" />
                <span className="ml-2">Traffic Conditions</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <Badge className={`${getTrafficColor(trafficDetails.density)} border`}>
                  {trafficDetails.density} Traffic
                </Badge>
                <div className="flex items-center text-orange-600">
                  <Clock className="h-4 w-4 mr-1" />
                  <span className="font-semibold">+{Math.round(trafficDetails.estimatedDelay)} min</span>
                </div>
              </div>

              <div className="space-y-2 text-sm">
                <div className="flex items-center justify-between text-orange-700">
                  <span>Delay Factor:</span>
                  <span className="font-medium">{trafficDetails.delayFactor.toFixed(1)}%</span>
                </div>

                {trafficDetails.delayFactor > 30 && (
                  <div className="flex items-center text-red-600 bg-red-50 p-2 rounded-md">
                    <AlertTriangle className="h-4 w-4 mr-2" />
                    <span className="text-xs">Heavy traffic detected</span>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
