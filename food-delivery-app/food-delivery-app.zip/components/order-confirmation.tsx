"use client"

import { CheckCircle, Clock, MapPin, Phone, Navigation } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { WeatherTrafficDisplay } from "@/components/weather-traffic-display"

interface OrderConfirmationProps {
  deliveryTime: number | null
  orderTotal: number
  orderId: string | null
  onNewOrder: () => void
  onTrackOrder?: () => void
  weatherDetails?: any
  trafficDetails?: any
  dataSource?: "real_api" | "enhanced_simulation"
}

export function OrderConfirmation({
  deliveryTime,
  orderTotal,
  orderId,
  onNewOrder,
  onTrackOrder,
  weatherDetails,
  trafficDetails,
  dataSource,
}: OrderConfirmationProps) {
  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 flex items-center justify-center p-4">
      <div className="w-full max-w-2xl space-y-6">
        <Card className="bg-white/90 backdrop-blur-sm shadow-2xl border-green-200">
          <CardHeader className="text-center bg-gradient-to-br from-green-500 to-emerald-500 text-white rounded-t-lg">
            <div className="mx-auto mb-4 bg-white/20 rounded-full p-4">
              <CheckCircle className="h-16 w-16 text-white" />
            </div>
            <CardTitle className="text-2xl">Order Confirmed!</CardTitle>
            <p className="text-green-100">Your delicious food is on its way</p>
          </CardHeader>

          <CardContent className="space-y-6 p-6">
            <div className="text-center">
              <Badge variant="outline" className="text-lg px-4 py-2 bg-green-50 border-green-200 text-green-700">
                Order ID: {orderId || "Loading..."}
              </Badge>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 p-4 rounded-lg border border-blue-200">
              <div className="flex items-center justify-center space-x-2 text-blue-700">
                <Clock className="h-5 w-5" />
                <span className="font-semibold">Estimated Delivery Time</span>
              </div>
              <div className="text-center mt-2">
                <span className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-indigo-600 bg-clip-text text-transparent">
                  {deliveryTime} minutes
                </span>
              </div>
              <p className="text-center text-sm text-blue-600 mt-1">
                Based on real-time traffic and weather conditions
              </p>
            </div>

            <div className="space-y-3 bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Order Total</span>
                <span className="font-semibold text-green-600">₹{orderTotal + 29 + Math.round(orderTotal * 0.05)}</span>
              </div>

              <div className="flex items-center space-x-2 text-gray-600">
                <MapPin className="h-4 w-4 text-orange-500" />
                <span className="text-sm">Delivering to: Home</span>
              </div>

              <div className="flex items-center space-x-2 text-gray-600">
                <Phone className="h-4 w-4 text-blue-500" />
                <span className="text-sm">Contact: +91 98765 43210</span>
              </div>
            </div>

            <div className="bg-gradient-to-r from-yellow-50 to-orange-50 p-3 rounded-lg border border-yellow-200">
              <p className="text-sm text-yellow-800">
                <strong>Track your order:</strong> You'll receive SMS updates about your order status. Our delivery
                partner will call you before arriving.
              </p>
            </div>

            <div className="space-y-2">
              <Button
                variant="outline"
                className="w-full border-blue-200 text-blue-700 hover:bg-blue-50"
                onClick={onTrackOrder}
              >
                <Navigation className="mr-2 h-4 w-4" />
                Track Order
              </Button>
              <Button
                onClick={onNewOrder}
                className="w-full bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white border-none shadow-lg"
              >
                Order Again
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Weather and Traffic Details */}
        <WeatherTrafficDisplay
          weatherDetails={weatherDetails}
          trafficDetails={trafficDetails}
          dataSource={dataSource}
        />
      </div>
    </div>
  )
}
