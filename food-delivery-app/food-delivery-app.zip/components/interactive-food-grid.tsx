"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { motion, AnimatePresence } from "framer-motion"
import { Star, Plus, Clock, MapPin, Heart, Flame, Leaf, Award } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

const getItemImage = (itemName: string): string => {
  const name = itemName.toLowerCase()

  if (name.includes("pizza")) {
    return "/placeholder.svg?height=200&width=300&text=🍕+Pizza"
  } else if (name.includes("biryani")) {
    return "/placeholder.svg?height=200&width=300&text=🍛+Biryani"
  } else if (name.includes("burger")) {
    return "/placeholder.svg?height=200&width=300&text=🍔+Burger"
  } else if (name.includes("pad thai") || name.includes("thai")) {
    return "/placeholder.svg?height=200&width=300&text=🍜+Pad+Thai"
  } else if (name.includes("shawarma")) {
    return "/placeholder.svg?height=200&width=300&text=🌯+Shawarma"
  } else if (name.includes("brownie") || name.includes("chocolate")) {
    return "/placeholder.svg?height=200&width=300&text=🍫+Brownie"
  } else {
    return "/placeholder.svg?height=200&width=300&text=🍽️+Food"
  }
}

interface InteractiveFoodGridProps {
  onAddToCart: (item: any) => void
  foodItems: any[]
  loading: boolean
}

export function InteractiveFoodGrid({ onAddToCart, foodItems, loading }: InteractiveFoodGridProps) {
  const categories = ["All", ...Array.from(new Set(foodItems.map((item) => item.category)))]
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [filteredItems, setFilteredItems] = useState(foodItems)
  const [favorites, setFavorites] = useState<Set<string>>(new Set())
  const [hoveredItem, setHoveredItem] = useState<string | null>(null)

  useEffect(() => {
    setFilteredItems(foodItems)
  }, [foodItems])

  const handleCategoryChange = (category: string) => {
    setSelectedCategory(category)
    if (category === "All") {
      setFilteredItems(foodItems)
    } else {
      setFilteredItems(foodItems.filter((item) => item.category === category))
    }
  }

  const toggleFavorite = (itemId: string) => {
    setFavorites((prev) => {
      const newFavorites = new Set(prev)
      if (newFavorites.has(itemId)) {
        newFavorites.delete(itemId)
      } else {
        newFavorites.add(itemId)
      }
      return newFavorites
    })
  }

  const getPopularityBadge = (rating: number) => {
    if (rating >= 4.5) return { icon: Flame, text: "Hot", color: "bg-red-500" }
    if (rating >= 4.0) return { icon: Award, text: "Popular", color: "bg-orange-500" }
    return null
  }

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
          >
            <Card className="overflow-hidden bg-white/80 backdrop-blur-sm shadow-lg">
              <motion.div
                className="h-48 bg-gradient-to-br from-orange-200 to-red-200"
                animate={{ opacity: [0.5, 1, 0.5] }}
                transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY }}
              />
              <CardContent className="p-4">
                <motion.div
                  className="h-4 bg-gradient-to-r from-orange-200 to-red-200 rounded mb-2"
                  animate={{ opacity: [0.5, 1, 0.5] }}
                  transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY, delay: 0.2 }}
                />
                <motion.div
                  className="h-3 bg-gradient-to-r from-orange-100 to-red-100 rounded mb-3"
                  animate={{ opacity: [0.5, 1, 0.5] }}
                  transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY, delay: 0.4 }}
                />
                <motion.div
                  className="h-3 bg-gradient-to-r from-orange-100 to-red-100 rounded"
                  animate={{ opacity: [0.5, 1, 0.5] }}
                  transition={{ duration: 1.5, repeat: Number.POSITIVE_INFINITY, delay: 0.6 }}
                />
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>
    )
  }

  return (
    <div>
      {/* Enhanced Category Filter */}
      <motion.div
        className="mb-8"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
      >
        <div className="flex flex-wrap gap-3 justify-center">
          {categories.map((category, index) => (
            <motion.div
              key={category}
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: index * 0.1 }}
            >
              <Button
                variant={selectedCategory === category ? "default" : "outline"}
                size="sm"
                onClick={() => handleCategoryChange(category)}
                className={
                  selectedCategory === category
                    ? "bg-gradient-to-r from-orange-500 to-red-500 text-white border-none shadow-lg transform hover:scale-105 transition-all duration-200"
                    : "bg-white/80 backdrop-blur-sm border-orange-200 text-orange-700 hover:bg-orange-50 hover:border-orange-300 hover:scale-105 transition-all duration-200"
                }
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
              >
                {category}
              </Button>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {/* Enhanced Food Items Grid */}
      <motion.div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" layout>
        <AnimatePresence>
          {filteredItems.map((item, index) => {
            const popularityBadge = getPopularityBadge(item.rating)
            const PopularityIcon = popularityBadge?.icon

            return (
              <motion.div
                key={item.id}
                layout
                initial={{ opacity: 0, y: 20, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                exit={{ opacity: 0, y: -20, scale: 0.9 }}
                transition={{ duration: 0.3, delay: index * 0.05 }}
                whileHover={{ y: -5, scale: 1.02 }}
                onHoverStart={() => setHoveredItem(item.id)}
                onHoverEnd={() => setHoveredItem(null)}
              >
                <Card className="overflow-hidden hover:shadow-2xl transition-all duration-300 bg-white/90 backdrop-blur-sm border-orange-100 group cursor-pointer">
                  <div className="relative overflow-hidden">
                    <motion.div whileHover={{ scale: 1.1 }} transition={{ duration: 0.3 }}>
                      <Image
                        src={
                          item.id === "1"
                            ? "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=300&h=200&fit=crop"
                            : item.id === "2"
                              ? "https://images.unsplash.com/photo-1589302168068-964664d93dc0?w=300&h=200&fit=crop"
                              : item.id === "3"
                                ? "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=300&h=200&fit=crop"
                                : item.id === "4"
                                  ? "https://images.unsplash.com/photo-1626804475297-41608ea09aeb?w=300&h=200&fit=crop"
                                  : item.id === "5"
                                    ? "https://images.unsplash.com/photo-1529006557810-274b9b2fc783?w=300&h=200&fit=crop"
                                    : item.id === "6"
                                      ? "https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=300&h=200&fit=crop"
                                      : getItemImage(item.name) || "/placeholder.svg"
                        }
                        alt={item.name}
                        width={300}
                        height={200}
                        className="w-full h-48 object-cover"
                      />
                    </motion.div>

                    {/* Overlay with animations */}
                    <motion.div
                      className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: hoveredItem === item.id ? 1 : 0 }}
                      transition={{ duration: 0.3 }}
                    />

                    {/* Top badges */}
                    <div className="absolute top-2 left-2 flex flex-col gap-2">
                      <motion.div
                        initial={{ x: -20, opacity: 0 }}
                        animate={{ x: 0, opacity: 1 }}
                        transition={{ delay: 0.1 }}
                      >
                        <Badge
                          variant={item.isVeg ? "default" : "destructive"}
                          className={`text-xs font-bold ${item.isVeg ? "bg-green-500 text-white" : "bg-red-500 text-white"} shadow-lg`}
                        >
                          {item.isVeg ? <Leaf className="w-3 h-3 mr-1" /> : "🍖"} {item.isVeg ? "VEG" : "NON-VEG"}
                        </Badge>
                      </motion.div>

                      {popularityBadge && PopularityIcon && (
                        <motion.div
                          initial={{ x: -20, opacity: 0 }}
                          animate={{ x: 0, opacity: 1 }}
                          transition={{ delay: 0.2 }}
                        >
                          <Badge className={`${popularityBadge.color} text-white text-xs font-bold shadow-lg`}>
                            <PopularityIcon className="w-3 h-3 mr-1" />
                            {popularityBadge.text}
                          </Badge>
                        </motion.div>
                      )}
                    </div>

                    {/* Favorite button */}
                    <motion.button
                      className="absolute top-2 right-2 p-2 rounded-full bg-white/80 backdrop-blur-sm shadow-lg"
                      whileHover={{ scale: 1.1 }}
                      whileTap={{ scale: 0.9 }}
                      onClick={(e) => {
                        e.stopPropagation()
                        toggleFavorite(item.id)
                      }}
                      initial={{ x: 20, opacity: 0 }}
                      animate={{ x: 0, opacity: 1 }}
                      transition={{ delay: 0.1 }}
                    >
                      <Heart
                        className={`h-4 w-4 ${favorites.has(item.id) ? "fill-red-500 text-red-500" : "text-gray-400"} transition-colors duration-200`}
                      />
                    </motion.button>

                    {/* Quick add button on hover */}
                    <AnimatePresence>
                      {hoveredItem === item.id && (
                        <motion.div
                          className="absolute bottom-2 right-2"
                          initial={{ scale: 0, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          exit={{ scale: 0, opacity: 0 }}
                          transition={{ duration: 0.2 }}
                        >
                          <Button
                            size="sm"
                            onClick={(e) => {
                              e.stopPropagation()
                              onAddToCart(item)
                            }}
                            className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white border-none shadow-lg"
                            whileHover={{ scale: 1.05 }}
                            whileTap={{ scale: 0.95 }}
                          >
                            <Plus className="h-3 w-3 mr-1" />
                            Quick Add
                          </Button>
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>

                  <CardContent className="p-4 bg-gradient-to-br from-white to-orange-50/30">
                    <motion.div
                      className="flex justify-between items-start mb-2"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.2 }}
                    >
                      <h3 className="font-semibold text-lg text-gray-800 line-clamp-1">{item.name}</h3>
                      <motion.span
                        className="font-bold text-green-600 bg-green-50 px-3 py-1 rounded-full text-sm shadow-sm"
                        whileHover={{ scale: 1.05 }}
                      >
                        ₹{item.price}
                      </motion.span>
                    </motion.div>

                    <motion.p
                      className="text-gray-600 text-sm mb-3 line-clamp-2"
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.3 }}
                    >
                      {item.description}
                    </motion.p>

                    <motion.div
                      className="flex items-center justify-between text-sm text-gray-500 mb-3"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.4 }}
                    >
                      <motion.div
                        className="flex items-center space-x-1 bg-orange-50 rounded-full px-3 py-1 border border-orange-100"
                        whileHover={{ scale: 1.02, backgroundColor: "rgb(255 237 213)" }}
                      >
                        <MapPin className="h-3 w-3 text-orange-500" />
                        <span className="text-orange-700 font-medium">{item.restaurant}</span>
                      </motion.div>
                      <motion.div
                        className="flex items-center space-x-1 bg-yellow-50 rounded-full px-3 py-1 border border-yellow-100"
                        whileHover={{ scale: 1.02, backgroundColor: "rgb(254 249 195)" }}
                      >
                        <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                        <span className="text-yellow-700 font-medium">{item.rating}</span>
                      </motion.div>
                    </motion.div>

                    <motion.div
                      className="flex items-center justify-between"
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: 0.5 }}
                    >
                      <motion.div
                        className="flex items-center space-x-1 text-sm text-gray-500 bg-blue-50 rounded-full px-3 py-1 border border-blue-100"
                        whileHover={{ scale: 1.02, backgroundColor: "rgb(219 234 254)" }}
                      >
                        <Clock className="h-3 w-3 text-blue-500" />
                        <span className="text-blue-700 font-medium">{item.deliveryTime}</span>
                      </motion.div>

                      <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                        <Button
                          size="sm"
                          onClick={() => onAddToCart(item)}
                          className="flex items-center space-x-1 bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white border-none shadow-lg hover:shadow-xl transition-all duration-200"
                        >
                          <Plus className="h-3 w-3" />
                          <span>Add</span>
                        </Button>
                      </motion.div>
                    </motion.div>
                  </CardContent>
                </Card>
              </motion.div>
            )
          })}
        </AnimatePresence>
      </motion.div>
    </div>
  )
}
