"use client"

import { useState, useEffect } from "react"
import { MapPin, Clock, CheckCircle, Truck, ChefHat } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { api } from "@/lib/api"

interface OrderTrackingProps {
  orderId: string
  onClose: () => void
}

interface OrderStatus {
  order_id: string
  status: "confirmed" | "preparing" | "picked_up" | "on_the_way" | "delivered"
  estimated_delivery_time: number
  current_location?: {
    latitude: number
    longitude: number
  }
  delivery_person?: {
    name: string
    phone: string
    rating: number
  }
}

const statusSteps = [
  { key: "confirmed", label: "Order Confirmed", icon: CheckCircle },
  { key: "preparing", label: "Preparing Food", icon: ChefHat },
  { key: "picked_up", label: "Picked Up", icon: Truck },
  { key: "on_the_way", label: "On the Way", icon: MapPin },
  { key: "delivered", label: "Delivered", icon: CheckCircle },
]

export function OrderTracking({ orderId, onClose }: OrderTrackingProps) {
  const [orderStatus, setOrderStatus] = useState<OrderStatus | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchOrderStatus = async () => {
      try {
        const status = await api.getOrderStatus(orderId)
        setOrderStatus(status)
      } catch (error) {
        console.error("Failed to fetch order status:", error)
        // Mock data for demo
        setOrderStatus({
          order_id: orderId,
          status: "preparing",
          estimated_delivery_time: 25,
          delivery_person: {
            name: "Raj Kumar",
            phone: "+91 98765 43210",
            rating: 4.8,
          },
        })
      } finally {
        setLoading(false)
      }
    }

    fetchOrderStatus()

    // Poll for updates every 30 seconds
    const interval = setInterval(fetchOrderStatus, 30000)
    return () => clearInterval(interval)
  }, [orderId])

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardContent className="p-8 text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-4">Loading order status...</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (!orderStatus) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
        <Card className="w-full max-w-md">
          <CardContent className="p-8 text-center">
            <p>Failed to load order status</p>
            <Button onClick={onClose} className="mt-4">
              Close
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  const currentStepIndex = statusSteps.findIndex((step) => step.key === orderStatus.status)

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
      <Card className="w-full max-w-md max-h-[90vh] overflow-y-auto">
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Track Order</span>
            <Button variant="ghost" size="sm" onClick={onClose}>
              ×
            </Button>
          </CardTitle>
          <Badge variant="outline" className="w-fit">
            Order ID: {orderStatus.order_id}
          </Badge>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Estimated Time */}
          <div className="bg-blue-50 p-4 rounded-lg text-center">
            <div className="flex items-center justify-center space-x-2 text-blue-700">
              <Clock className="h-5 w-5" />
              <span className="font-semibold">Estimated Delivery</span>
            </div>
            <div className="text-2xl font-bold text-blue-600 mt-1">{orderStatus.estimated_delivery_time} minutes</div>
          </div>

          {/* Order Status Steps */}
          <div className="space-y-4">
            {statusSteps.map((step, index) => {
              const Icon = step.icon
              const isCompleted = index <= currentStepIndex
              const isCurrent = index === currentStepIndex

              return (
                <div key={step.key} className="flex items-center space-x-3">
                  <div
                    className={`
                    flex items-center justify-center w-8 h-8 rounded-full
                    ${isCompleted ? "bg-green-500 text-white" : "bg-gray-200 text-gray-400"}
                    ${isCurrent ? "ring-2 ring-blue-500" : ""}
                  `}
                  >
                    <Icon className="h-4 w-4" />
                  </div>
                  <div className="flex-1">
                    <p className={`font-medium ${isCompleted ? "text-green-600" : "text-gray-400"}`}>{step.label}</p>
                    {isCurrent && <p className="text-sm text-blue-600">In progress...</p>}
                  </div>
                </div>
              )
            })}
          </div>

          {/* Delivery Person Info */}
          {orderStatus.delivery_person && orderStatus.status !== "confirmed" && (
            <div className="border-t pt-4">
              <h4 className="font-semibold mb-2">Delivery Partner</h4>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">{orderStatus.delivery_person.name}</p>
                  <p className="text-sm text-gray-500">⭐ {orderStatus.delivery_person.rating} rating</p>
                </div>
                <Button variant="outline" size="sm">
                  Call
                </Button>
              </div>
            </div>
          )}

          {/* Action Buttons */}
          <div className="space-y-2">
            <Button variant="outline" className="w-full">
              Need Help?
            </Button>
            <Button onClick={onClose} className="w-full">
              Close
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
