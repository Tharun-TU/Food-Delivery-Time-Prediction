"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Brain, Zap, Target, TrendingUp, Clock, Wifi, Satellite, Activity } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

interface QuantumDeliveryPredictorProps {
  orderData: any
  onPredictionUpdate: (prediction: any) => void
}

export function QuantumDeliveryPredictor({ orderData, onPredictionUpdate }: QuantumDeliveryPredictorProps) {
  const [quantumFactors, setQuantumFactors] = useState<any[]>([])
  const [realTimeUpdates, setRealTimeUpdates] = useState<any[]>([])
  const [predictionConfidence, setPredictionConfidence] = useState(0)
  const [isAnalyzing, setIsAnalyzing] = useState(true)
  const [multiModelPredictions, setMultiModelPredictions] = useState<any[]>([])

  useEffect(() => {
    simulateQuantumAnalysis()
    startRealTimeUpdates()
  }, [orderData])

  const simulateQuantumAnalysis = async () => {
    setIsAnalyzing(true)

    // Simulate advanced quantum-inspired analysis
    const factors = [
      {
        name: "Kitchen Quantum State",
        description: "Real-time kitchen efficiency using IoT sensors",
        impact: 8.5,
        confidence: 94,
        realTimeValue: "High efficiency (3.2x normal speed)",
        icon: Activity,
        color: "text-green-600",
        trend: "improving",
      },
      {
        name: "Delivery Partner Neural Pattern",
        description: "AI analysis of delivery partner's behavioral patterns",
        impact: 7.2,
        confidence: 89,
        realTimeValue: "Optimal route selection probability: 87%",
        icon: Brain,
        color: "text-blue-600",
        trend: "stable",
      },
      {
        name: "Micro-Weather Prediction",
        description: "Hyperlocal weather using satellite + IoT data",
        impact: 6.8,
        confidence: 92,
        realTimeValue: "0.2mm rain expected in 15min (route impact: minimal)",
        icon: Satellite,
        color: "text-purple-600",
        trend: "worsening",
      },
      {
        name: "Traffic Quantum Tunneling",
        description: "AI-predicted traffic gaps and optimal timing",
        impact: 9.1,
        confidence: 96,
        realTimeValue: "Traffic gap window: 12:34-12:41 PM",
        icon: Zap,
        color: "text-yellow-600",
        trend: "improving",
      },
      {
        name: "Customer Availability Prediction",
        description: "ML model predicting customer presence",
        impact: 5.4,
        confidence: 78,
        realTimeValue: "95% probability customer is home",
        icon: Target,
        color: "text-orange-600",
        trend: "stable",
      },
      {
        name: "Restaurant Crowd Dynamics",
        description: "Real-time crowd analysis using computer vision",
        impact: 7.9,
        confidence: 91,
        realTimeValue: "Low crowd density, fast service expected",
        icon: TrendingUp,
        color: "text-indigo-600",
        trend: "improving",
      },
    ]

    // Simulate processing delay
    for (let i = 0; i < factors.length; i++) {
      await new Promise((resolve) => setTimeout(resolve, 500))
      setQuantumFactors((prev) => [...prev, factors[i]])
    }

    // Generate multi-model predictions
    const models = [
      { name: "Quantum Neural Network", prediction: 23, confidence: 96 },
      { name: "Ensemble Random Forest", prediction: 25, confidence: 89 },
      { name: "Deep Learning LSTM", prediction: 22, confidence: 93 },
      { name: "Gradient Boosting", prediction: 24, confidence: 87 },
      { name: "Transformer Model", prediction: 23, confidence: 94 },
    ]

    setMultiModelPredictions(models)
    setPredictionConfidence(94)
    setIsAnalyzing(false)

    // Calculate final prediction
    const finalPrediction = {
      time: 23,
      confidence: 94,
      factors: factors,
      models: models,
    }

    onPredictionUpdate(finalPrediction)
  }

  const startRealTimeUpdates = () => {
    const updates = [
      { time: "12:30:15", event: "Order confirmed by restaurant", impact: 0, type: "positive" },
      { time: "12:30:45", event: "Kitchen efficiency increased by 15%", impact: -2, type: "positive" },
      { time: "12:31:20", event: "Optimal delivery partner assigned", impact: -1, type: "positive" },
      { time: "12:32:10", event: "Traffic gap window detected", impact: -3, type: "positive" },
      { time: "12:32:55", event: "Micro-weather update: clear skies", impact: -1, type: "positive" },
    ]

    updates.forEach((update, index) => {
      setTimeout(
        () => {
          setRealTimeUpdates((prev) => [...prev, update])
        },
        (index + 1) * 2000,
      )
    })
  }

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "improving":
        return "📈"
      case "worsening":
        return "📉"
      default:
        return "➡️"
    }
  }

  return (
    <div className="space-y-6">
      {/* Quantum Analysis Header */}
      <Card className="bg-gradient-to-br from-indigo-900 via-purple-900 to-pink-900 text-white border-none overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-r from-blue-600/20 to-purple-600/20 animate-pulse"></div>
        <CardHeader className="relative z-10">
          <CardTitle className="flex items-center text-xl">
            <motion.div
              animate={{ rotate: [0, 360] }}
              transition={{ duration: 3, repeat: Number.POSITIVE_INFINITY, ease: "linear" }}
              className="mr-3"
            >
              <Brain className="h-6 w-6" />
            </motion.div>
            Quantum Delivery Intelligence
            <Badge className="ml-auto bg-white/20 text-white border-white/30">
              {isAnalyzing ? "Analyzing..." : `${predictionConfidence}% Confidence`}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="relative z-10">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold text-cyan-300">5</div>
              <div className="text-sm text-gray-300">AI Models</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-green-300">23min</div>
              <div className="text-sm text-gray-300">Predicted Time</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-yellow-300">6</div>
              <div className="text-sm text-gray-300">Quantum Factors</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Multi-Model Consensus */}
      <Card className="bg-gradient-to-br from-blue-50 to-indigo-50 border-blue-200">
        <CardHeader>
          <CardTitle className="flex items-center text-blue-800">
            <Zap className="mr-2 h-5 w-5" />
            Multi-Model AI Consensus
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {multiModelPredictions.map((model, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
              className="flex items-center justify-between p-3 bg-white/60 rounded-lg border border-blue-100"
            >
              <div>
                <span className="font-medium text-blue-800">{model.name}</span>
                <div className="text-sm text-blue-600">Confidence: {model.confidence}%</div>
              </div>
              <div className="text-right">
                <div className="text-lg font-bold text-blue-700">{model.prediction}min</div>
                <Progress value={model.confidence} className="w-20 h-2" />
              </div>
            </motion.div>
          ))}

          <div className="mt-4 p-3 bg-gradient-to-r from-blue-500 to-indigo-500 text-white rounded-lg">
            <div className="flex items-center justify-between">
              <span className="font-semibold">Consensus Prediction</span>
              <span className="text-xl font-bold">23 minutes</span>
            </div>
            <div className="text-sm opacity-90">All models agree within 3-minute range</div>
          </div>
        </CardContent>
      </Card>

      {/* Quantum Factors Analysis */}
      <Card className="bg-gradient-to-br from-purple-50 to-pink-50 border-purple-200">
        <CardHeader>
          <CardTitle className="flex items-center text-purple-800">
            <Activity className="mr-2 h-5 w-5" />
            Quantum Factor Analysis
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <AnimatePresence>
            {quantumFactors.map((factor, index) => {
              const Icon = factor.icon
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20, scale: 0.9 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  transition={{ delay: index * 0.2 }}
                  className="p-4 bg-white/80 rounded-lg border border-purple-100 hover:shadow-lg transition-all duration-200"
                >
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex items-center space-x-3">
                      <div className="p-2 bg-purple-100 rounded-lg">
                        <Icon className={`h-4 w-4 ${factor.color}`} />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-800">{factor.name}</h4>
                        <p className="text-sm text-gray-600">{factor.description}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <Badge className="bg-purple-100 text-purple-700">
                        {factor.impact > 0 ? "+" : ""}
                        {factor.impact}min
                      </Badge>
                      <div className="text-xs text-gray-500 mt-1">
                        {getTrendIcon(factor.trend)} {factor.confidence}%
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-50 rounded-lg p-2 mt-2">
                    <div className="text-sm font-medium text-gray-700">Real-time Status:</div>
                    <div className="text-sm text-gray-600">{factor.realTimeValue}</div>
                  </div>

                  <div className="mt-2">
                    <div className="flex justify-between text-xs text-gray-500 mb-1">
                      <span>Impact Level</span>
                      <span>{factor.impact}/10</span>
                    </div>
                    <Progress value={Math.abs(factor.impact) * 10} className="h-2" />
                  </div>
                </motion.div>
              )
            })}
          </AnimatePresence>
        </CardContent>
      </Card>

      {/* Real-Time Updates Stream */}
      <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
        <CardHeader>
          <CardTitle className="flex items-center text-green-800">
            <Wifi className="mr-2 h-5 w-5" />
            Live Prediction Updates
            <motion.div
              className="ml-2 w-2 h-2 bg-green-500 rounded-full"
              animate={{ scale: [1, 1.5, 1], opacity: [1, 0.5, 1] }}
              transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY }}
            />
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <AnimatePresence>
            {realTimeUpdates.map((update, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                className={`flex items-center justify-between p-3 rounded-lg border ${
                  update.type === "positive" ? "bg-green-100 border-green-200" : "bg-red-100 border-red-200"
                }`}
              >
                <div className="flex items-center space-x-3">
                  <div
                    className={`w-2 h-2 rounded-full ${update.type === "positive" ? "bg-green-500" : "bg-red-500"}`}
                  />
                  <div>
                    <div className="text-sm font-medium text-gray-800">{update.event}</div>
                    <div className="text-xs text-gray-500">{update.time}</div>
                  </div>
                </div>
                <Badge
                  className={`${update.type === "positive" ? "bg-green-500 text-white" : "bg-red-500 text-white"}`}
                >
                  {update.impact > 0 ? "+" : ""}
                  {update.impact}min
                </Badge>
              </motion.div>
            ))}
          </AnimatePresence>

          {realTimeUpdates.length === 0 && (
            <div className="text-center text-gray-500 py-4">
              <Clock className="h-8 w-8 mx-auto mb-2 opacity-50" />
              <p className="text-sm">Waiting for real-time updates...</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Prediction Accuracy History */}
      <Card className="bg-gradient-to-br from-yellow-50 to-orange-50 border-yellow-200">
        <CardHeader>
          <CardTitle className="flex items-center text-yellow-800">
            <Target className="mr-2 h-5 w-5" />
            Prediction Accuracy Track Record
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4 text-center">
            <div className="p-3 bg-white/60 rounded-lg">
              <div className="text-2xl font-bold text-green-600">94.7%</div>
              <div className="text-sm text-gray-600">Last 30 days</div>
            </div>
            <div className="p-3 bg-white/60 rounded-lg">
              <div className="text-2xl font-bold text-blue-600">±2.1min</div>
              <div className="text-sm text-gray-600">Avg deviation</div>
            </div>
            <div className="p-3 bg-white/60 rounded-lg">
              <div className="text-2xl font-bold text-purple-600">1,247</div>
              <div className="text-sm text-gray-600">Predictions made</div>
            </div>
          </div>

          <div className="mt-4 p-3 bg-gradient-to-r from-yellow-400 to-orange-400 text-white rounded-lg">
            <div className="flex items-center justify-between">
              <span className="font-semibold">Your Personal Accuracy</span>
              <span className="text-xl font-bold">97.2%</span>
            </div>
            <div className="text-sm opacity-90">Based on your 23 previous orders</div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
