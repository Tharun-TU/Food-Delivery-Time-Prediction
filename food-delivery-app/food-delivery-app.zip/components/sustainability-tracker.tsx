"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Leaf, Truck, Recycle, Award, TreePine, Droplets } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"

interface SustainabilityTrackerProps {
  orderItems: any[]
  deliveryDistance: number
}

export function SustainabilityTracker({ orderItems, deliveryDistance }: SustainabilityTrackerProps) {
  const [carbonFootprint, setCarbonFootprint] = useState(0)
  const [waterSaved, setWaterSaved] = useState(0)
  const [localSourcing, setLocalSourcing] = useState(0)
  const [packagingScore, setPackagingScore] = useState(0)

  useEffect(() => {
    calculateSustainabilityMetrics()
  }, [orderItems, deliveryDistance])

  const calculateSustainabilityMetrics = () => {
    // Carbon footprint calculation (kg CO2)
    const baseCarbon = deliveryDistance * 0.12 // 0.12 kg CO2 per km
    const foodCarbon = orderItems.reduce((total, item) => {
      const vegMultiplier = item.isVeg ? 0.5 : 1.5 // Veg food has lower carbon footprint
      return total + item.quantity * vegMultiplier
    }, 0)
    setCarbonFootprint(baseCarbon + foodCarbon)

    // Water saved calculation (liters)
    const vegItems = orderItems.filter((item) => item.isVeg).length
    setWaterSaved(vegItems * 150) // 150L saved per veg item vs meat

    // Local sourcing percentage
    const localItems = orderItems.filter((item) => item.restaurant.includes("Local") || Math.random() > 0.3).length
    setLocalSourcing((localItems / orderItems.length) * 100)

    // Packaging score (0-100)
    const ecoPackaging = Math.random() * 40 + 60 // 60-100 range
    setPackagingScore(ecoPackaging)
  }

  const getSustainabilityGrade = () => {
    const score =
      (100 - Math.min(carbonFootprint * 10, 100)) * 0.3 +
      Math.min(waterSaved / 10, 100) * 0.2 +
      localSourcing * 0.3 +
      packagingScore * 0.2

    if (score >= 80) return { grade: "A+", color: "text-green-600", bg: "bg-green-50" }
    if (score >= 70) return { grade: "A", color: "text-green-500", bg: "bg-green-50" }
    if (score >= 60) return { grade: "B+", color: "text-yellow-600", bg: "bg-yellow-50" }
    if (score >= 50) return { grade: "B", color: "text-yellow-500", bg: "bg-yellow-50" }
    return { grade: "C", color: "text-orange-500", bg: "bg-orange-50" }
  }

  const sustainabilityGrade = getSustainabilityGrade()

  return (
    <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
      <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
        <CardHeader>
          <CardTitle className="flex items-center text-green-800">
            <Leaf className="mr-2 h-5 w-5" />
            Sustainability Impact
            <Badge className={`ml-auto ${sustainabilityGrade.bg} ${sustainabilityGrade.color} border-none`}>
              Grade: {sustainabilityGrade.grade}
            </Badge>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Carbon Footprint */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Truck className="h-4 w-4 text-gray-600" />
              <span className="text-sm">Carbon Footprint</span>
            </div>
            <div className="text-right">
              <span className="font-semibold text-green-600">{carbonFootprint.toFixed(2)} kg CO₂</span>
              <p className="text-xs text-gray-500">
                {carbonFootprint < 2
                  ? "🌱 Low impact!"
                  : carbonFootprint < 4
                    ? "🌿 Moderate"
                    : "🌳 Consider offsetting"}
              </p>
            </div>
          </div>

          {/* Water Conservation */}
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Droplets className="h-4 w-4 text-blue-500" />
              <span className="text-sm">Water Saved</span>
            </div>
            <div className="text-right">
              <span className="font-semibold text-blue-600">{waterSaved}L</span>
              <p className="text-xs text-gray-500">vs meat alternatives</p>
            </div>
          </div>

          {/* Local Sourcing */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <TreePine className="h-4 w-4 text-green-600" />
                <span className="text-sm">Local Sourcing</span>
              </div>
              <span className="font-semibold text-green-600">{localSourcing.toFixed(0)}%</span>
            </div>
            <Progress value={localSourcing} className="h-2" />
          </div>

          {/* Eco Packaging */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                <Recycle className="h-4 w-4 text-green-600" />
                <span className="text-sm">Eco Packaging</span>
              </div>
              <span className="font-semibold text-green-600">{packagingScore.toFixed(0)}%</span>
            </div>
            <Progress value={packagingScore} className="h-2" />
          </div>

          {/* Sustainability Tips */}
          <div className="bg-white/60 rounded-lg p-3 border border-green-200">
            <div className="flex items-center space-x-2 mb-2">
              <Award className="h-4 w-4 text-green-600" />
              <span className="text-sm font-medium text-green-800">Eco Tips</span>
            </div>
            <ul className="text-xs text-green-700 space-y-1">
              <li>• Choose more vegetarian options to reduce carbon footprint</li>
              <li>• Order from local restaurants to support community</li>
              <li>• Combine orders with friends to reduce delivery trips</li>
            </ul>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
