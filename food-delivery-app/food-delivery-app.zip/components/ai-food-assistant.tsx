"use client"

import { useState, useRef, useEffect } from "react"
import { motion } from "framer-motion"
import {
  MessageCircle,
  Send,
  Mic,
  MicOff,
  Bot,
  User,
  Sparkles,
  TrendingUp,
  Heart,
  Zap,
  Sun,
  Moon,
  Coffee,
  Utensils,
  Brain,
  BarChart3,
  X,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Avatar } from "@/components/ui/avatar"
import { MLAnalyticsDashboard } from "./ml-analytics-dashboard"

interface Message {
  id: string
  type: "user" | "assistant"
  content: string
  timestamp: Date
  suggestions?: FoodSuggestion[]
  analytics?: any
}

interface FoodSuggestion {
  name: string
  restaurant: string
  price: number
  rating: number
  healthScore: number
  calories: number
  deliveryTime: string
  nutritionHighlights: string[]
  healthTags: string[]
  description: string
  image: string
}

export function AIFoodAssistant() {
  const [isOpen, setIsOpen] = useState(false)
  const [messages, setMessages] = useState<Message[]>([])
  const [inputValue, setInputValue] = useState("")
  const [isListening, setIsListening] = useState(false)
  const [isTyping, setIsTyping] = useState(false)
  const [showAnalytics, setShowAnalytics] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  // Enhanced AI responses with more intelligence
  const getAIResponse = (userMessage: string): { content: string; suggestions?: FoodSuggestion[]; analytics?: any } => {
    const message = userMessage.toLowerCase()
    const currentHour = new Date().getHours()
    const isLateNight = currentHour >= 22 || currentHour <= 6
    const isLunchTime = currentHour >= 11 && currentHour <= 14
    const isDinnerTime = currentHour >= 17 && currentHour <= 21

    // Advanced contextual responses
    if (message.includes("stressed") || message.includes("anxiety") || message.includes("calm")) {
      return {
        content: `I understand you're feeling stressed. Research shows that foods rich in magnesium, omega-3 fatty acids, and complex carbohydrates can help reduce cortisol levels and promote relaxation. Let me suggest some scientifically-backed stress-relief foods that taste amazing too! 🧠✨`,
        suggestions: [
          {
            name: "Salmon Teriyaki Bowl",
            restaurant: "Zen Garden",
            price: 18.99,
            rating: 4.8,
            healthScore: 92,
            calories: 420,
            deliveryTime: "25-30 min",
            nutritionHighlights: ["High Omega-3", "Magnesium Rich", "B-Vitamins"],
            healthTags: ["Stress Relief", "Brain Health", "Anti-inflammatory"],
            description: "Wild-caught salmon with quinoa, avocado, and stress-busting dark leafy greens",
            image: "/placeholder.svg?height=120&width=120",
          },
          {
            name: "Dark Chocolate Acai Bowl",
            restaurant: "Superfood Cafe",
            price: 12.5,
            rating: 4.7,
            healthScore: 88,
            calories: 340,
            deliveryTime: "15-20 min",
            nutritionHighlights: ["Antioxidants", "Natural Serotonin", "Magnesium"],
            healthTags: ["Mood Booster", "Stress Relief", "Energy"],
            description: "Organic acai with 70% dark chocolate, blueberries, and adaptogenic herbs",
            image: "/placeholder.svg?height=120&width=120",
          },
        ],
        analytics: {
          confidence: 94,
          factors: ["mood_analysis", "nutritional_science", "time_context"],
          accuracy: 91,
        },
      }
    }

    if (message.includes("energy") || message.includes("tired") || message.includes("boost")) {
      return {
        content: `Feeling low on energy? I've got the perfect solution! These foods are scientifically proven to boost energy levels through sustained glucose release, B-vitamins, and natural caffeine. No crash, just sustained vitality! ⚡🚀`,
        suggestions: [
          {
            name: "Power Protein Smoothie",
            restaurant: "Energy Hub",
            price: 9.99,
            rating: 4.9,
            healthScore: 95,
            calories: 380,
            deliveryTime: "10-15 min",
            nutritionHighlights: ["Plant Protein", "B-Complex", "Natural Caffeine"],
            healthTags: ["Energy Boost", "Metabolism", "Pre-Workout"],
            description: "Spirulina, matcha, banana, and plant protein for sustained energy",
            image: "/placeholder.svg?height=120&width=120",
          },
          {
            name: "Quinoa Power Bowl",
            restaurant: "Fuel Station",
            price: 15.75,
            rating: 4.6,
            healthScore: 89,
            calories: 450,
            deliveryTime: "20-25 min",
            nutritionHighlights: ["Complex Carbs", "Iron", "Complete Protein"],
            healthTags: ["Sustained Energy", "Muscle Recovery", "Brain Fuel"],
            description: "Quinoa with roasted vegetables, chickpeas, and energy-boosting tahini",
            image: "/placeholder.svg?height=120&width=120",
          },
        ],
        analytics: {
          confidence: 96,
          factors: ["energy_analysis", "metabolic_science", "nutrient_timing"],
          accuracy: 93,
        },
      }
    }

    if (message.includes("weight loss") || message.includes("diet") || message.includes("healthy")) {
      return {
        content: `Perfect timing for your health goals! These meals are designed with optimal macronutrient ratios, high fiber content, and metabolism-boosting ingredients. Each suggestion is under 400 calories but packed with nutrients to keep you satisfied! 🎯💪`,
        suggestions: [
          {
            name: "Mediterranean Zucchini Noodles",
            restaurant: "Clean Eats",
            price: 13.25,
            rating: 4.8,
            healthScore: 96,
            calories: 320,
            deliveryTime: "18-23 min",
            nutritionHighlights: ["High Fiber", "Lean Protein", "Healthy Fats"],
            healthTags: ["Weight Loss", "Low Carb", "Heart Healthy"],
            description: "Spiralized zucchini with grilled chicken, cherry tomatoes, and olive tapenade",
            image: "/placeholder.svg?height=120&width=120",
          },
          {
            name: "Metabolism Boost Salad",
            restaurant: "Vitality Kitchen",
            price: 11.99,
            rating: 4.7,
            healthScore: 94,
            calories: 280,
            deliveryTime: "15-20 min",
            nutritionHighlights: ["Thermogenic Spices", "Lean Protein", "Fiber"],
            healthTags: ["Fat Burning", "Detox", "Metabolism"],
            description: "Mixed greens with cayenne-spiced tofu, grapefruit, and metabolism-boosting seeds",
            image: "/placeholder.svg?height=120&width=120",
          },
        ],
        analytics: {
          confidence: 92,
          factors: ["nutrition_science", "caloric_analysis", "metabolic_boost"],
          accuracy: 89,
        },
      }
    }

    if (isLateNight) {
      return {
        content: `It's late night! Your circadian rhythm affects digestion, so I'm recommending foods that won't disrupt your sleep cycle. These contain tryptophan and magnesium to actually help you sleep better while satisfying those late cravings! 🌙😴`,
        suggestions: [
          {
            name: "Chamomile Honey Toast",
            restaurant: "Night Owl Cafe",
            price: 8.5,
            rating: 4.5,
            healthScore: 78,
            calories: 220,
            deliveryTime: "12-18 min",
            nutritionHighlights: ["Tryptophan", "Natural Melatonin", "Complex Carbs"],
            healthTags: ["Sleep Aid", "Light Meal", "Comfort Food"],
            description: "Whole grain toast with chamomile-infused honey and sliced banana",
            image: "/placeholder.svg?height=120&width=120",
          },
        ],
        analytics: {
          confidence: 87,
          factors: ["circadian_science", "sleep_nutrition", "time_analysis"],
          accuracy: 85,
        },
      }
    }

    // Default intelligent response
    return {
      content: `Great question! Based on current nutritional science and your timing, I've curated some fantastic options. Each suggestion is backed by research and optimized for taste, nutrition, and your specific needs! 🍽️✨`,
      suggestions: [
        {
          name: "Balanced Buddha Bowl",
          restaurant: "Harmony Kitchen",
          price: 14.99,
          rating: 4.8,
          healthScore: 91,
          calories: 420,
          deliveryTime: "22-28 min",
          nutritionHighlights: ["Complete Nutrition", "Plant-Based", "Antioxidants"],
          healthTags: ["Balanced Meal", "Superfood", "Energy"],
          description: "Perfectly balanced bowl with quinoa, roasted vegetables, and tahini dressing",
          image: "/placeholder.svg?height=120&width=120",
        },
      ],
      analytics: {
        confidence: 88,
        factors: ["general_nutrition", "balanced_approach", "user_preference"],
        accuracy: 86,
      },
    }
  }

  const handleSendMessage = async () => {
    if (!inputValue.trim()) return

    const userMessage: Message = {
      id: Date.now().toString(),
      type: "user",
      content: inputValue,
      timestamp: new Date(),
    }

    setMessages((prev) => [...prev, userMessage])
    setInputValue("")
    setIsTyping(true)

    // Simulate AI thinking time
    setTimeout(() => {
      const aiResponse = getAIResponse(inputValue)
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: "assistant",
        content: aiResponse.content,
        timestamp: new Date(),
        suggestions: aiResponse.suggestions,
        analytics: aiResponse.analytics,
      }

      setMessages((prev) => [...prev, assistantMessage])
      setIsTyping(false)
    }, 1500)
  }

  const quickActions = [
    { icon: Heart, label: "I'm stressed", color: "bg-red-100 text-red-600" },
    { icon: Zap, label: "Need energy", color: "bg-yellow-100 text-yellow-600" },
    { icon: TrendingUp, label: "Weight loss", color: "bg-green-100 text-green-600" },
    { icon: Sun, label: "Hot weather", color: "bg-orange-100 text-orange-600" },
    { icon: Moon, label: "Late night", color: "bg-purple-100 text-purple-600" },
    { icon: Coffee, label: "Morning boost", color: "bg-brown-100 text-brown-600" },
    { icon: Utensils, label: "Comfort food", color: "bg-blue-100 text-blue-600" },
    { icon: Brain, label: "Brain food", color: "bg-indigo-100 text-indigo-600" },
  ]

  const handleVoiceInput = () => {
    setIsListening(!isListening)
    // Simulate voice recognition
    if (!isListening) {
      setTimeout(() => {
        setInputValue("I'm feeling stressed and need something healthy")
        setIsListening(false)
      }, 2000)
    }
  }

  if (!isOpen) {
    return (
      <motion.div
        className="fixed bottom-6 right-6 z-50"
        initial={{ scale: 0 }}
        animate={{ scale: 1 }}
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <Button
          onClick={() => setIsOpen(true)}
          className="h-16 w-16 rounded-full bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 shadow-2xl"
        >
          <MessageCircle className="h-8 w-8 text-white" />
        </Button>
      </motion.div>
    )
  }

  return (
    <>
      <motion.div
        className="fixed bottom-6 right-6 w-96 h-[600px] bg-white rounded-2xl shadow-2xl z-50 flex flex-col overflow-hidden border border-purple-200"
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0, opacity: 0 }}
      >
        {/* Header */}
        <div className="bg-gradient-to-r from-purple-500 to-pink-500 text-white p-4 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="relative">
              <Avatar className="h-10 w-10 bg-white/20">
                <Bot className="h-6 w-6 text-white" />
              </Avatar>
              <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-400 rounded-full border-2 border-white"></div>
            </div>
            <div>
              <h3 className="font-semibold">AI Nutrition Expert</h3>
              <p className="text-xs text-purple-100">Powered by ML Analytics</p>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            <Button
              onClick={() => setShowAnalytics(true)}
              variant="ghost"
              size="sm"
              className="text-white hover:bg-white/10 p-2"
            >
              <BarChart3 className="h-4 w-4" />
            </Button>
            <Button
              onClick={() => setIsOpen(false)}
              variant="ghost"
              size="sm"
              className="text-white hover:bg-white/20 rounded-full h-8 w-8 p-0 transition-all hover:scale-110"
              title="Close AI Assistant"
            >
              <X className="h-5 w-5" />
            </Button>
          </div>
        </div>

        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gradient-to-b from-purple-50/30 to-pink-50/30">
          {messages.length === 0 && (
            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center py-8">
              <Sparkles className="h-12 w-12 text-purple-400 mx-auto mb-4" />
              <h4 className="font-semibold text-gray-800 mb-2">Welcome to AI Nutrition Expert!</h4>
              <p className="text-sm text-gray-600 mb-6">
                I'm your personal food scientist, powered by advanced ML models. Ask me anything about nutrition,
                dietary needs, or get personalized recommendations!
              </p>

              {/* Quick Actions */}
              <div className="grid grid-cols-2 gap-2">
                {quickActions.map((action, index) => {
                  const Icon = action.icon
                  return (
                    <motion.button
                      key={index}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ delay: index * 0.1 }}
                      onClick={() => {
                        setInputValue(action.label)
                        handleSendMessage()
                      }}
                      className={`p-3 rounded-lg ${action.color} hover:scale-105 transition-all text-xs font-medium flex items-center space-x-2`}
                    >
                      <Icon className="h-4 w-4" />
                      <span>{action.label}</span>
                    </motion.button>
                  )
                })}
              </div>
            </motion.div>
          )}

          {messages.map((message) => (
            <motion.div
              key={message.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${message.type === "user" ? "justify-end" : "justify-start"}`}
            >
              <div className={`flex items-start space-x-2 max-w-[80%]`}>
                {message.type === "assistant" && (
                  <Avatar className="h-8 w-8 bg-gradient-to-r from-purple-400 to-pink-400">
                    <Bot className="h-4 w-4 text-white" />
                  </Avatar>
                )}

                <div>
                  <div
                    className={`p-3 rounded-2xl ${
                      message.type === "user"
                        ? "bg-gradient-to-r from-purple-500 to-pink-500 text-white"
                        : "bg-white shadow-md border border-purple-100"
                    }`}
                  >
                    <p className="text-sm">{message.content}</p>
                    {message.analytics && (
                      <div className="mt-2 flex items-center space-x-2 text-xs opacity-75">
                        <Badge className="bg-purple-100 text-purple-700 text-xs">
                          {message.analytics.confidence}% confident
                        </Badge>
                        <Badge className="bg-blue-100 text-blue-700 text-xs">
                          {message.analytics.accuracy}% accurate
                        </Badge>
                      </div>
                    )}
                  </div>

                  {/* Food Suggestions */}
                  {message.suggestions && (
                    <div className="mt-3 space-y-3">
                      {message.suggestions.map((suggestion, index) => (
                        <motion.div
                          key={index}
                          initial={{ opacity: 0, scale: 0.9 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: index * 0.1 }}
                          className="bg-white rounded-xl p-4 shadow-lg border border-purple-100 hover:shadow-xl transition-all cursor-pointer"
                        >
                          <div className="flex items-start space-x-3">
                            <img
                              src={suggestion.image || "/placeholder.svg"}
                              alt={suggestion.name}
                              className="w-16 h-16 rounded-lg object-cover"
                            />
                            <div className="flex-1">
                              <div className="flex items-start justify-between">
                                <div>
                                  <h4 className="font-semibold text-gray-800 text-sm">{suggestion.name}</h4>
                                  <p className="text-xs text-gray-600">{suggestion.restaurant}</p>
                                </div>
                                <div className="text-right">
                                  <div className="font-bold text-purple-600">${suggestion.price}</div>
                                  <div className="text-xs text-gray-500">⭐ {suggestion.rating}</div>
                                </div>
                              </div>

                              <p className="text-xs text-gray-600 mt-1 mb-2">{suggestion.description}</p>

                              <div className="flex items-center justify-between text-xs mb-2">
                                <span className="text-gray-600">{suggestion.calories} cal</span>
                                <Badge className="bg-green-100 text-green-700">
                                  Health Score: {suggestion.healthScore}
                                </Badge>
                                <span className="text-purple-600">{suggestion.deliveryTime}</span>
                              </div>

                              <div className="flex flex-wrap gap-1 mb-2">
                                {suggestion.healthTags.slice(0, 2).map((tag, tagIndex) => (
                                  <Badge key={tagIndex} className="bg-purple-100 text-purple-700 text-xs px-2 py-1">
                                    {tag}
                                  </Badge>
                                ))}
                              </div>

                              <div className="text-xs text-gray-500">
                                <strong>Nutrition:</strong> {suggestion.nutritionHighlights.join(", ")}
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  )}

                  <div className="text-xs text-gray-400 mt-1">
                    {message.timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                  </div>
                </div>

                {message.type === "user" && (
                  <Avatar className="h-8 w-8 bg-gradient-to-r from-blue-400 to-cyan-400">
                    <User className="h-4 w-4 text-white" />
                  </Avatar>
                )}
              </div>
            </motion.div>
          ))}

          {isTyping && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex items-start space-x-2">
              <Avatar className="h-8 w-8 bg-gradient-to-r from-purple-400 to-pink-400">
                <Bot className="h-4 w-4 text-white" />
              </Avatar>
              <div className="bg-white p-3 rounded-2xl shadow-md border border-purple-100">
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce"></div>
                  <div
                    className="w-2 h-2 bg-purple-400 rounded-full animate-bounce"
                    style={{ animationDelay: "0.1s" }}
                  ></div>
                  <div
                    className="w-2 h-2 bg-purple-400 rounded-full animate-bounce"
                    style={{ animationDelay: "0.2s" }}
                  ></div>
                </div>
              </div>
            </motion.div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div className="p-4 border-t border-purple-100 bg-white">
          <div className="flex items-center space-x-2">
            <div className="flex-1 relative">
              <Input
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
                placeholder="Ask about nutrition, diet, or get food recommendations..."
                className="pr-12 border-purple-200 focus:border-purple-400"
              />
              <Button
                onClick={handleVoiceInput}
                variant="ghost"
                size="sm"
                className={`absolute right-2 top-1/2 transform -translate-y-1/2 p-1 ${
                  isListening ? "text-red-500" : "text-gray-400"
                }`}
              >
                {isListening ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
              </Button>
            </div>
            <Button
              onClick={handleSendMessage}
              disabled={!inputValue.trim()}
              className="bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </motion.div>

      {/* Analytics Dashboard */}
      <MLAnalyticsDashboard isVisible={showAnalytics} onClose={() => setShowAnalytics(false)} />
    </>
  )
}
