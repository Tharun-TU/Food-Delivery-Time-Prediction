"use client"

import { useState, useEffect } from "react"
import { motion } from "framer-motion"
import { Brain, Clock, TrendingUp, Calendar, Zap } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"

interface PredictiveOrderingProps {
  onQuickOrder: (items: any[]) => void
}

export function PredictiveOrdering({ onQuickOrder }: PredictiveOrderingProps) {
  const [predictions, setPredictions] = useState<any[]>([])
  const [userPatterns, setUserPatterns] = useState({
    favoriteTime: "12:30 PM",
    preferredCuisine: "Indian",
    averageOrderValue: 350,
    weeklyOrders: 3,
  })

  useEffect(() => {
    generatePredictions()
  }, [])

  const generatePredictions = () => {
    const currentHour = new Date().getHours()
    const dayOfWeek = new Date().getDay()

    const predictions = [
      {
        type: "time_based",
        title: "Your Usual Lunch",
        description: "Based on your 12:30 PM ordering pattern",
        items: [{ name: "Chicken Biryani", restaurant: "Biryani House", price: 349, confidence: 92 }],
        confidence: 92,
        reason: "You order this 80% of weekdays at lunch",
        icon: Clock,
        color: "from-blue-500 to-indigo-500",
      },
      {
        type: "weather_based",
        title: "Rainy Day Comfort",
        description: "Perfect for today's weather",
        items: [
          { name: "Hot Chocolate", restaurant: "Sweet Treats", price: 99, confidence: 78 },
          { name: "Chicken Soup", restaurant: "Comfort Kitchen", price: 149, confidence: 78 },
        ],
        confidence: 78,
        reason: "You prefer hot items when it's raining",
        icon: TrendingUp,
        color: "from-orange-500 to-red-500",
      },
      {
        type: "social_based",
        title: "Trending in Your Circle",
        description: "Your friends are loving this",
        items: [{ name: "Pad Thai", restaurant: "Thai Garden", price: 279, confidence: 85 }],
        confidence: 85,
        reason: "3 friends ordered this week",
        icon: TrendingUp,
        color: "from-green-500 to-emerald-500",
      },
      {
        type: "health_based",
        title: "Healthy Choice",
        description: "Matches your fitness goals",
        items: [{ name: "Quinoa Salad", restaurant: "Health Hub", price: 249, confidence: 71 }],
        confidence: 71,
        reason: "Low calorie, high protein",
        icon: Zap,
        color: "from-purple-500 to-pink-500",
      },
    ]

    setPredictions(predictions)
  }

  const getConfidenceColor = (confidence: number) => {
    if (confidence >= 90) return "text-green-600 bg-green-50"
    if (confidence >= 80) return "text-blue-600 bg-blue-50"
    if (confidence >= 70) return "text-yellow-600 bg-yellow-50"
    return "text-gray-600 bg-gray-50"
  }

  return (
    <div className="space-y-6">
      {/* User Patterns Summary */}
      <Card className="bg-gradient-to-br from-indigo-50 to-purple-50 border-indigo-200">
        <CardHeader>
          <CardTitle className="flex items-center text-indigo-800">
            <Brain className="mr-2 h-5 w-5" />
            Your Food Patterns
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="text-center p-3 bg-white/60 rounded-lg">
              <Clock className="h-4 w-4 mx-auto mb-1 text-indigo-600" />
              <p className="font-medium">{userPatterns.favoriteTime}</p>
              <p className="text-xs text-gray-600">Favorite time</p>
            </div>
            <div className="text-center p-3 bg-white/60 rounded-lg">
              <TrendingUp className="h-4 w-4 mx-auto mb-1 text-indigo-600" />
              <p className="font-medium">₹{userPatterns.averageOrderValue}</p>
              <p className="text-xs text-gray-600">Avg order value</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* AI Predictions */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold text-gray-800 flex items-center">
          <Zap className="mr-2 h-5 w-5 text-yellow-500" />
          AI Predictions for You
        </h3>

        {predictions.map((prediction, index) => {
          const Icon = prediction.icon
          return (
            <motion.div
              key={index}
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="bg-white/90 backdrop-blur-sm border-gray-200 hover:shadow-lg transition-all duration-200">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <div className={`p-2 rounded-lg bg-gradient-to-r ${prediction.color}`}>
                        <Icon className="h-4 w-4 text-white" />
                      </div>
                      <div>
                        <h4 className="font-semibold text-gray-800">{prediction.title}</h4>
                        <p className="text-sm text-gray-600">{prediction.description}</p>
                      </div>
                    </div>
                    <Badge className={getConfidenceColor(prediction.confidence)}>{prediction.confidence}% sure</Badge>
                  </div>

                  {/* Predicted Items */}
                  <div className="space-y-2 mb-3">
                    {prediction.items.map((item: any, idx: number) => (
                      <div key={idx} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
                        <div>
                          <p className="font-medium text-sm">{item.name}</p>
                          <p className="text-xs text-gray-600">{item.restaurant}</p>
                        </div>
                        <span className="font-semibold text-green-600">₹{item.price}</span>
                      </div>
                    ))}
                  </div>

                  <div className="flex items-center justify-between">
                    <p className="text-xs text-gray-500 italic">{prediction.reason}</p>
                    <Button
                      size="sm"
                      onClick={() => onQuickOrder(prediction.items)}
                      className={`bg-gradient-to-r ${prediction.color} hover:opacity-90 text-white`}
                    >
                      Quick Order
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )
        })}
      </div>

      {/* Quick Reorder */}
      <Card className="bg-gradient-to-br from-green-50 to-emerald-50 border-green-200">
        <CardHeader>
          <CardTitle className="flex items-center text-green-800">
            <Calendar className="mr-2 h-5 w-5" />
            Quick Reorder
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-600 mb-3">Your last 3 orders, ready to reorder:</p>
          <div className="space-y-2">
            {["Chicken Biryani + Lassi", "Margherita Pizza", "Pad Thai + Spring Rolls"].map((order, index) => (
              <Button
                key={index}
                variant="outline"
                size="sm"
                className="w-full justify-start border-green-200 text-green-700 hover:bg-green-50"
                onClick={() => console.log(`Reordering: ${order}`)}
              >
                {order}
              </Button>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
