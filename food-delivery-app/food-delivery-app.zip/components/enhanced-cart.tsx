"use client"

import { X, Plus, Minus, ShoppingBag, Trash2, Gift } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { Badge } from "@/components/ui/badge"
import Image from "next/image"

interface CartItem {
  id: string
  name: string
  price: number
  quantity: number
  image: string
  restaurant: string
}

interface EnhancedCartProps {
  isOpen: boolean
  onClose: () => void
  items: CartItem[]
  onUpdateQuantity: (itemId: string, quantity: number) => void
  onRemoveItem: (itemId: string) => void
  total: number
  onPlaceOrder: () => void
}

export function EnhancedCart({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  total,
  onPlaceOrder,
}: EnhancedCartProps) {
  if (!isOpen) return null

  const deliveryFee = 29
  const taxes = Math.round(total * 0.05)
  const finalTotal = total + deliveryFee + taxes

  // Calculate savings and offers
  const savings = total > 500 ? 50 : 0
  const freeDelivery = total > 300

  return (
    <motion.div
      className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex justify-end"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <motion.div
        className="bg-gradient-to-br from-white via-orange-50/30 to-red-50/30 w-full max-w-md h-full overflow-y-auto shadow-2xl"
        initial={{ x: "100%" }}
        animate={{ x: 0 }}
        exit={{ x: "100%" }}
        transition={{ type: "spring", damping: 25, stiffness: 200 }}
      >
        <motion.div
          className="p-4 border-b border-orange-100 flex items-center justify-between bg-gradient-to-r from-orange-500 to-red-500 text-white"
          initial={{ y: -20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <h2 className="text-xl font-semibold flex items-center">
            <motion.div animate={{ rotate: [0, 10, -10, 0] }} transition={{ duration: 0.5, delay: 0.3 }}>
              <ShoppingBag className="mr-2 h-5 w-5" />
            </motion.div>
            Your Cart ({items.length})
          </h2>
          <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
            <Button variant="ghost" size="sm" onClick={onClose} className="text-white hover:bg-white/20">
              <X className="h-4 w-4" />
            </Button>
          </motion.div>
        </motion.div>

        {items.length === 0 ? (
          <motion.div
            className="p-8 text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
          >
            <motion.div
              className="bg-gradient-to-br from-orange-100 to-red-100 rounded-full w-24 h-24 flex items-center justify-center mx-auto mb-4"
              animate={{ scale: [1, 1.05, 1] }}
              transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
            >
              <ShoppingBag className="h-12 w-12 text-orange-400" />
            </motion.div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">Your cart is empty</h3>
            <p className="text-gray-500">Add some delicious items to get started!</p>
            <motion.div className="mt-4" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                onClick={onClose}
                className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white"
              >
                Start Shopping
              </Button>
            </motion.div>
          </motion.div>
        ) : (
          <>
            {/* Offers Banner */}
            <AnimatePresence>
              {(freeDelivery || savings > 0) && (
                <motion.div
                  className="p-3 bg-gradient-to-r from-green-500 to-emerald-500 text-white text-center"
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  exit={{ height: 0, opacity: 0 }}
                >
                  <div className="flex items-center justify-center space-x-2">
                    <Gift className="h-4 w-4" />
                    <span className="text-sm font-medium">
                      {freeDelivery && "🎉 Free Delivery Unlocked! "}
                      {savings > 0 && `💰 You saved ₹${savings}!`}
                    </span>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="p-4 space-y-4">
              <AnimatePresence>
                {items.map((item, index) => (
                  <motion.div
                    key={item.id}
                    layout
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: 20, scale: 0.8 }}
                    transition={{ delay: index * 0.1 }}
                  >
                    <Card className="bg-white/80 backdrop-blur-sm border-orange-100 shadow-lg hover:shadow-xl transition-all duration-200">
                      <CardContent className="p-4">
                        <div className="flex items-center space-x-3">
                          <motion.div whileHover={{ scale: 1.05 }} className="relative overflow-hidden rounded-md">
                            <Image
                              src={item.image || "/placeholder.svg"}
                              alt={item.name}
                              width={60}
                              height={60}
                              className="rounded-md object-cover shadow-md"
                            />
                          </motion.div>
                          <div className="flex-1">
                            <h4 className="font-medium text-gray-800">{item.name}</h4>
                            <p className="text-sm text-gray-500">{item.restaurant}</p>
                            <motion.p
                              className="font-semibold text-green-600 bg-green-50 inline-block px-2 py-1 rounded-full text-sm"
                              whileHover={{ scale: 1.05 }}
                            >
                              ₹{item.price}
                            </motion.p>
                          </div>
                          <div className="flex items-center space-x-2">
                            <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                                className="border-orange-200 text-orange-600 hover:bg-orange-50 h-8 w-8 p-0"
                              >
                                <Minus className="h-3 w-3" />
                              </Button>
                            </motion.div>
                            <motion.span
                              className="w-8 text-center font-semibold bg-orange-50 rounded px-2 py-1"
                              key={item.quantity}
                              initial={{ scale: 1.2 }}
                              animate={{ scale: 1 }}
                              transition={{ duration: 0.2 }}
                            >
                              {item.quantity}
                            </motion.span>
                            <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                                className="border-orange-200 text-orange-600 hover:bg-orange-50 h-8 w-8 p-0"
                              >
                                <Plus className="h-3 w-3" />
                              </Button>
                            </motion.div>
                            <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => onRemoveItem(item.id)}
                                className="text-red-500 hover:bg-red-50 h-8 w-8 p-0"
                              >
                                <Trash2 className="h-3 w-3" />
                              </Button>
                            </motion.div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </AnimatePresence>
            </div>

            <motion.div
              className="p-4 border-t border-orange-100 bg-gradient-to-br from-orange-50 to-red-50"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ delay: 0.4 }}
            >
              <Card className="bg-white/90 backdrop-blur-sm border-orange-200 shadow-lg">
                <CardHeader className="bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-t-lg">
                  <CardTitle className="text-lg">Order Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 p-4">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span className="font-semibold">₹{total}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Delivery Fee</span>
                    <span className={`font-semibold ${freeDelivery ? "line-through text-gray-400" : ""}`}>
                      ₹{deliveryFee}
                    </span>
                    {freeDelivery && <Badge className="bg-green-500 text-white text-xs">FREE</Badge>}
                  </div>
                  <div className="flex justify-between">
                    <span>Taxes & Fees</span>
                    <span className="font-semibold">₹{taxes}</span>
                  </div>
                  {savings > 0 && (
                    <div className="flex justify-between text-green-600">
                      <span>Savings</span>
                      <span className="font-semibold">-₹{savings}</span>
                    </div>
                  )}
                  <Separator className="bg-orange-200" />
                  <motion.div
                    className="flex justify-between font-semibold text-lg text-green-600"
                    animate={{ scale: [1, 1.02, 1] }}
                    transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY }}
                  >
                    <span>Total</span>
                    <span>₹{finalTotal - savings - (freeDelivery ? deliveryFee : 0)}</span>
                  </motion.div>
                  <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                    <Button
                      className="w-full mt-4 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white border-none shadow-lg hover:shadow-xl transition-all duration-200"
                      size="lg"
                      onClick={onPlaceOrder}
                    >
                      <motion.span
                        animate={{ x: [0, 2, 0] }}
                        transition={{ duration: 1, repeat: Number.POSITIVE_INFINITY }}
                      >
                        Place Order - ₹{finalTotal - savings - (freeDelivery ? deliveryFee : 0)}
                      </motion.span>
                    </Button>
                  </motion.div>
                </CardContent>
              </Card>
            </motion.div>
          </>
        )}
      </motion.div>
    </motion.div>
  )
}
