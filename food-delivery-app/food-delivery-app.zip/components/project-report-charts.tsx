"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import {
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  ComposedChart,
  Bar,
} from "recharts"
import { FileText, TrendingUp, Users, Star, Truck, Download } from "lucide-react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ChartContainer } from "@/components/ui/chart"

interface ProjectReportChartsProps {
  isVisible: boolean
  onClose: () => void
}

export function ProjectReportCharts({ isVisible, onClose }: ProjectReportChartsProps) {
  const [activeChart, setActiveChart] = useState("distance-time")

  // Sample data for Distance vs Delivery Time scatter plot
  const distanceTimeData = [
    { distance: 1.2, deliveryTime: 18, orders: 45, efficiency: 92 },
    { distance: 2.1, deliveryTime: 22, orders: 38, efficiency: 88 },
    { distance: 3.5, deliveryTime: 28, orders: 52, efficiency: 85 },
    { distance: 4.8, deliveryTime: 35, orders: 29, efficiency: 82 },
    { distance: 2.8, deliveryTime: 25, orders: 41, efficiency: 87 },
    { distance: 1.8, deliveryTime: 20, orders: 48, efficiency: 90 },
    { distance: 5.2, deliveryTime: 38, orders: 25, efficiency: 79 },
    { distance: 3.1, deliveryTime: 26, orders: 44, efficiency: 86 },
    { distance: 4.2, deliveryTime: 32, orders: 33, efficiency: 83 },
    { distance: 2.5, deliveryTime: 24, orders: 39, efficiency: 88 },
    { distance: 6.1, deliveryTime: 42, orders: 22, efficiency: 76 },
    { distance: 1.5, deliveryTime: 19, orders: 46, efficiency: 91 },
    { distance: 3.8, deliveryTime: 30, orders: 36, efficiency: 84 },
    { distance: 4.5, deliveryTime: 34, orders: 31, efficiency: 81 },
    { distance: 2.3, deliveryTime: 23, orders: 42, efficiency: 89 },
    { distance: 5.8, deliveryTime: 40, orders: 24, efficiency: 77 },
    { distance: 1.9, deliveryTime: 21, orders: 47, efficiency: 90 },
    { distance: 3.2, deliveryTime: 27, orders: 40, efficiency: 86 },
    { distance: 4.9, deliveryTime: 36, orders: 28, efficiency: 80 },
    { distance: 2.7, deliveryTime: 25, orders: 43, efficiency: 87 },
  ]

  // Sample data for Age vs Delivery Time
  const ageDeliveryData = [
    { age: 22, deliveryTime: 28, experience: 1.2, rating: 4.2 },
    { age: 25, deliveryTime: 24, experience: 2.5, rating: 4.5 },
    { age: 28, deliveryTime: 22, experience: 3.8, rating: 4.7 },
    { age: 31, deliveryTime: 20, experience: 5.2, rating: 4.8 },
    { age: 24, deliveryTime: 26, experience: 1.8, rating: 4.3 },
    { age: 27, deliveryTime: 23, experience: 3.1, rating: 4.6 },
    { age: 30, deliveryTime: 21, experience: 4.5, rating: 4.8 },
    { age: 33, deliveryTime: 19, experience: 6.2, rating: 4.9 },
    { age: 26, deliveryTime: 25, experience: 2.3, rating: 4.4 },
    { age: 29, deliveryTime: 22, experience: 4.1, rating: 4.7 },
    { age: 32, deliveryTime: 20, experience: 5.8, rating: 4.8 },
    { age: 23, deliveryTime: 27, experience: 1.5, rating: 4.2 },
    { age: 35, deliveryTime: 18, experience: 7.1, rating: 4.9 },
    { age: 28, deliveryTime: 23, experience: 3.5, rating: 4.6 },
    { age: 31, deliveryTime: 21, experience: 5.0, rating: 4.8 },
    { age: 25, deliveryTime: 25, experience: 2.1, rating: 4.4 },
    { age: 34, deliveryTime: 19, experience: 6.5, rating: 4.9 },
    { age: 27, deliveryTime: 24, experience: 2.8, rating: 4.5 },
    { age: 30, deliveryTime: 21, experience: 4.8, rating: 4.7 },
    { age: 26, deliveryTime: 24, experience: 2.6, rating: 4.5 },
  ]

  // Sample data for Rating vs Delivery Time
  const ratingDeliveryData = [
    { rating: 4.1, deliveryTime: 32, orders: 156, satisfaction: 78 },
    { rating: 4.3, deliveryTime: 28, orders: 189, satisfaction: 82 },
    { rating: 4.5, deliveryTime: 25, orders: 234, satisfaction: 86 },
    { rating: 4.7, deliveryTime: 22, orders: 278, satisfaction: 90 },
    { rating: 4.9, deliveryTime: 19, orders: 312, satisfaction: 94 },
    { rating: 4.2, deliveryTime: 30, orders: 167, satisfaction: 80 },
    { rating: 4.4, deliveryTime: 26, orders: 201, satisfaction: 84 },
    { rating: 4.6, deliveryTime: 23, orders: 256, satisfaction: 88 },
    { rating: 4.8, deliveryTime: 20, orders: 289, satisfaction: 92 },
    { rating: 5.0, deliveryTime: 17, orders: 345, satisfaction: 96 },
    { rating: 4.0, deliveryTime: 34, orders: 134, satisfaction: 76 },
    { rating: 4.3, deliveryTime: 29, orders: 178, satisfaction: 82 },
    { rating: 4.5, deliveryTime: 24, orders: 223, satisfaction: 86 },
    { rating: 4.7, deliveryTime: 21, orders: 267, satisfaction: 90 },
    { rating: 4.9, deliveryTime: 18, orders: 298, satisfaction: 94 },
    { rating: 4.2, deliveryTime: 31, orders: 145, satisfaction: 80 },
    { rating: 4.4, deliveryTime: 27, orders: 212, satisfaction: 84 },
    { rating: 4.6, deliveryTime: 24, orders: 245, satisfaction: 88 },
    { rating: 4.8, deliveryTime: 21, orders: 276, satisfaction: 92 },
    { rating: 4.9, deliveryTime: 19, orders: 301, satisfaction: 94 },
  ]

  // Box plot data for Vehicle & Order Type
  const vehicleOrderData = [
    // Motorcycle - Regular
    { vehicle: "Motorcycle", orderType: "Regular", deliveryTime: 18, category: "Motorcycle-Regular" },
    { vehicle: "Motorcycle", orderType: "Regular", deliveryTime: 22, category: "Motorcycle-Regular" },
    { vehicle: "Motorcycle", orderType: "Regular", deliveryTime: 20, category: "Motorcycle-Regular" },
    { vehicle: "Motorcycle", orderType: "Regular", deliveryTime: 19, category: "Motorcycle-Regular" },
    { vehicle: "Motorcycle", orderType: "Regular", deliveryTime: 21, category: "Motorcycle-Regular" },

    // Motorcycle - Express
    { vehicle: "Motorcycle", orderType: "Express", deliveryTime: 15, category: "Motorcycle-Express" },
    { vehicle: "Motorcycle", orderType: "Express", deliveryTime: 17, category: "Motorcycle-Express" },
    { vehicle: "Motorcycle", orderType: "Express", deliveryTime: 16, category: "Motorcycle-Express" },
    { vehicle: "Motorcycle", orderType: "Express", deliveryTime: 14, category: "Motorcycle-Express" },
    { vehicle: "Motorcycle", orderType: "Express", deliveryTime: 18, category: "Motorcycle-Express" },

    // Scooter - Regular
    { vehicle: "Scooter", orderType: "Regular", deliveryTime: 24, category: "Scooter-Regular" },
    { vehicle: "Scooter", orderType: "Regular", deliveryTime: 26, category: "Scooter-Regular" },
    { vehicle: "Scooter", orderType: "Regular", deliveryTime: 25, category: "Scooter-Regular" },
    { vehicle: "Scooter", orderType: "Regular", deliveryTime: 23, category: "Scooter-Regular" },
    { vehicle: "Scooter", orderType: "Regular", deliveryTime: 27, category: "Scooter-Regular" },

    // Scooter - Express
    { vehicle: "Scooter", orderType: "Express", deliveryTime: 20, category: "Scooter-Express" },
    { vehicle: "Scooter", orderType: "Express", deliveryTime: 22, category: "Scooter-Express" },
    { vehicle: "Scooter", orderType: "Express", deliveryTime: 21, category: "Scooter-Express" },
    { vehicle: "Scooter", orderType: "Express", deliveryTime: 19, category: "Scooter-Express" },
    { vehicle: "Scooter", orderType: "Express", deliveryTime: 23, category: "Scooter-Express" },

    // Bicycle - Regular
    { vehicle: "Bicycle", orderType: "Regular", deliveryTime: 32, category: "Bicycle-Regular" },
    { vehicle: "Bicycle", orderType: "Regular", deliveryTime: 35, category: "Bicycle-Regular" },
    { vehicle: "Bicycle", orderType: "Regular", deliveryTime: 33, category: "Bicycle-Regular" },
    { vehicle: "Bicycle", orderType: "Regular", deliveryTime: 31, category: "Bicycle-Regular" },
    { vehicle: "Bicycle", orderType: "Regular", deliveryTime: 34, category: "Bicycle-Regular" },

    // Bicycle - Express
    { vehicle: "Bicycle", orderType: "Express", deliveryTime: 28, category: "Bicycle-Express" },
    { vehicle: "Bicycle", orderType: "Express", deliveryTime: 30, category: "Bicycle-Express" },
    { vehicle: "Bicycle", orderType: "Express", deliveryTime: 29, category: "Bicycle-Express" },
    { vehicle: "Bicycle", orderType: "Express", deliveryTime: 27, category: "Bicycle-Express" },
    { vehicle: "Bicycle", orderType: "Express", deliveryTime: 31, category: "Bicycle-Express" },
  ]

  // Calculate box plot statistics
  const calculateBoxPlotStats = (data: number[]) => {
    const sorted = data.sort((a, b) => a - b)
    const q1 = sorted[Math.floor(sorted.length * 0.25)]
    const median = sorted[Math.floor(sorted.length * 0.5)]
    const q3 = sorted[Math.floor(sorted.length * 0.75)]
    const min = Math.min(...sorted)
    const max = Math.max(...sorted)
    return { min, q1, median, q3, max }
  }

  const boxPlotData = [
    {
      category: "Motorcycle-Regular",
      ...calculateBoxPlotStats(
        vehicleOrderData.filter((d) => d.category === "Motorcycle-Regular").map((d) => d.deliveryTime),
      ),
      vehicle: "Motorcycle",
      orderType: "Regular",
    },
    {
      category: "Motorcycle-Express",
      ...calculateBoxPlotStats(
        vehicleOrderData.filter((d) => d.category === "Motorcycle-Express").map((d) => d.deliveryTime),
      ),
      vehicle: "Motorcycle",
      orderType: "Express",
    },
    {
      category: "Scooter-Regular",
      ...calculateBoxPlotStats(
        vehicleOrderData.filter((d) => d.category === "Scooter-Regular").map((d) => d.deliveryTime),
      ),
      vehicle: "Scooter",
      orderType: "Regular",
    },
    {
      category: "Scooter-Express",
      ...calculateBoxPlotStats(
        vehicleOrderData.filter((d) => d.category === "Scooter-Express").map((d) => d.deliveryTime),
      ),
      vehicle: "Scooter",
      orderType: "Express",
    },
    {
      category: "Bicycle-Regular",
      ...calculateBoxPlotStats(
        vehicleOrderData.filter((d) => d.category === "Bicycle-Regular").map((d) => d.deliveryTime),
      ),
      vehicle: "Bicycle",
      orderType: "Regular",
    },
    {
      category: "Bicycle-Express",
      ...calculateBoxPlotStats(
        vehicleOrderData.filter((d) => d.category === "Bicycle-Express").map((d) => d.deliveryTime),
      ),
      vehicle: "Bicycle",
      orderType: "Express",
    },
  ]

  // Custom Box Plot Component
  const CustomBoxPlot = ({ data }: { data: any[] }) => (
    <ResponsiveContainer width="100%" height={400}>
      <ComposedChart data={data} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
        <CartesianGrid strokeDasharray="3 3" />
        <XAxis dataKey="category" angle={-45} textAnchor="end" height={100} />
        <YAxis label={{ value: "Delivery Time (min)", angle: -90, position: "insideLeft" }} />
        <Tooltip
          content={({ active, payload, label }) => {
            if (active && payload && payload.length) {
              const data = payload[0].payload
              return (
                <div className="bg-white p-3 border rounded shadow-lg">
                  <p className="font-semibold">{label}</p>
                  <p>Min: {data.min} min</p>
                  <p>Q1: {data.q1} min</p>
                  <p>Median: {data.median} min</p>
                  <p>Q3: {data.q3} min</p>
                  <p>Max: {data.max} min</p>
                </div>
              )
            }
            return null
          }}
        />
        {/* Box plot visualization using bars */}
        <Bar dataKey="min" fill="transparent" stroke="#8884d8" strokeWidth={2} />
        <Bar dataKey="q1" fill="#8884d8" fillOpacity={0.3} />
        <Bar dataKey="median" fill="#82ca9d" />
        <Bar dataKey="q3" fill="#8884d8" fillOpacity={0.3} />
        <Bar dataKey="max" fill="transparent" stroke="#8884d8" strokeWidth={2} />
      </ComposedChart>
    </ResponsiveContainer>
  )

  if (!isVisible) return null

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.9 }}
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4"
    >
      <div className="bg-white rounded-xl shadow-2xl w-full max-w-7xl h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <FileText className="h-8 w-8" />
              <div>
                <h2 className="text-2xl font-bold">Project Report - Data Visualizations</h2>
                <p className="text-blue-100">Comprehensive analysis of delivery performance metrics</p>
              </div>
            </div>
            <div className="flex space-x-2">
              <Button variant="outline" className="text-white border-white hover:bg-white/10">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
              <Button onClick={onClose} variant="outline" className="text-white border-white hover:bg-white/10">
                Close
              </Button>
            </div>
          </div>

          {/* Chart Navigation */}
          <div className="flex flex-wrap gap-2 mt-6">
            {[
              { id: "distance-time", label: "Distance vs Time", icon: TrendingUp },
              { id: "age-delivery", label: "Age vs Delivery", icon: Users },
              { id: "rating-time", label: "Rating vs Time", icon: Star },
              { id: "vehicle-box", label: "Vehicle Box Plot", icon: Truck },
            ].map((chart) => {
              const Icon = chart.icon
              return (
                <button
                  key={chart.id}
                  onClick={() => setActiveChart(chart.id)}
                  className={`flex items-center space-x-2 px-4 py-2 rounded-lg transition-all ${
                    activeChart === chart.id ? "bg-white text-blue-600 shadow-lg" : "text-blue-100 hover:bg-white/10"
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  <span>{chart.label}</span>
                </button>
              )
            })}
          </div>
        </div>

        {/* Content */}
        <div className="p-6 h-full overflow-y-auto">
          {activeChart === "distance-time" && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center">
                      <TrendingUp className="mr-2 h-5 w-5" />
                      Distance vs Delivery Time Scatter Plot
                    </div>
                    <Badge className="bg-blue-500 text-white">Correlation: -0.89</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ChartContainer
                    config={{
                      deliveryTime: { label: "Delivery Time (min)", color: "hsl(var(--chart-1))" },
                      distance: { label: "Distance (km)", color: "hsl(var(--chart-2))" },
                    }}
                    className="h-[500px]"
                  >
                    <ScatterChart data={distanceTimeData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis
                        type="number"
                        dataKey="distance"
                        name="Distance"
                        unit="km"
                        label={{ value: "Distance (km)", position: "insideBottom", offset: -10 }}
                      />
                      <YAxis
                        type="number"
                        dataKey="deliveryTime"
                        name="Delivery Time"
                        unit="min"
                        label={{ value: "Delivery Time (min)", angle: -90, position: "insideLeft" }}
                      />
                      <Tooltip
                        cursor={{ strokeDasharray: "3 3" }}
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            const data = payload[0].payload
                            return (
                              <div className="bg-white p-3 border rounded shadow-lg">
                                <p className="font-semibold">Delivery Data</p>
                                <p>Distance: {data.distance} km</p>
                                <p>Time: {data.deliveryTime} min</p>
                                <p>Orders: {data.orders}</p>
                                <p>Efficiency: {data.efficiency}%</p>
                              </div>
                            )
                          }
                          return null
                        }}
                      />
                      <Scatter dataKey="deliveryTime" fill="var(--color-deliveryTime)" />
                    </ScatterChart>
                  </ChartContainer>

                  <div className="mt-4 p-4 bg-blue-50 rounded-lg">
                    <h4 className="font-semibold text-blue-800 mb-2">Key Insights:</h4>
                    <ul className="text-sm text-blue-700 space-y-1">
                      <li>• Strong negative correlation (-0.89) between distance and delivery time</li>
                      <li>• Average delivery time increases by ~6 minutes per km</li>
                      <li>• Most efficient deliveries occur within 2-3 km range</li>
                      <li>• Delivery efficiency drops significantly beyond 5 km</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeChart === "age-delivery" && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Users className="mr-2 h-5 w-5" />
                      Delivery Person Age vs Delivery Time
                    </div>
                    <Badge className="bg-green-500 text-white">Correlation: -0.76</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ChartContainer
                    config={{
                      deliveryTime: { label: "Delivery Time (min)", color: "hsl(var(--chart-1))" },
                      age: { label: "Age (years)", color: "hsl(var(--chart-2))" },
                    }}
                    className="h-[500px]"
                  >
                    <ScatterChart data={ageDeliveryData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis
                        type="number"
                        dataKey="age"
                        name="Age"
                        unit="years"
                        label={{ value: "Age (years)", position: "insideBottom", offset: -10 }}
                      />
                      <YAxis
                        type="number"
                        dataKey="deliveryTime"
                        name="Delivery Time"
                        unit="min"
                        label={{ value: "Delivery Time (min)", angle: -90, position: "insideLeft" }}
                      />
                      <Tooltip
                        cursor={{ strokeDasharray: "3 3" }}
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            const data = payload[0].payload
                            return (
                              <div className="bg-white p-3 border rounded shadow-lg">
                                <p className="font-semibold">Delivery Person</p>
                                <p>Age: {data.age} years</p>
                                <p>Delivery Time: {data.deliveryTime} min</p>
                                <p>Experience: {data.experience} years</p>
                                <p>Rating: {data.rating}/5.0</p>
                              </div>
                            )
                          }
                          return null
                        }}
                      />
                      <Scatter dataKey="deliveryTime" fill="var(--color-deliveryTime)" />
                    </ScatterChart>
                  </ChartContainer>

                  <div className="mt-4 p-4 bg-green-50 rounded-lg">
                    <h4 className="font-semibold text-green-800 mb-2">Key Insights:</h4>
                    <ul className="text-sm text-green-700 space-y-1">
                      <li>• Experienced delivery persons (age 28-35) show fastest delivery times</li>
                      <li>• Strong correlation between age, experience, and efficiency</li>
                      <li>• Younger delivery persons (22-25) take 15-20% longer on average</li>
                      <li>• Peak performance occurs around 30-32 years of age</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeChart === "rating-time" && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Star className="mr-2 h-5 w-5" />
                      Delivery Rating vs Delivery Time
                    </div>
                    <Badge className="bg-yellow-500 text-white">Correlation: -0.92</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <ChartContainer
                    config={{
                      deliveryTime: { label: "Delivery Time (min)", color: "hsl(var(--chart-1))" },
                      rating: { label: "Rating", color: "hsl(var(--chart-2))" },
                    }}
                    className="h-[500px]"
                  >
                    <ScatterChart data={ratingDeliveryData}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis
                        type="number"
                        dataKey="rating"
                        name="Rating"
                        domain={[3.9, 5.1]}
                        label={{ value: "Delivery Rating (1-5)", position: "insideBottom", offset: -10 }}
                      />
                      <YAxis
                        type="number"
                        dataKey="deliveryTime"
                        name="Delivery Time"
                        unit="min"
                        label={{ value: "Delivery Time (min)", angle: -90, position: "insideLeft" }}
                      />
                      <Tooltip
                        cursor={{ strokeDasharray: "3 3" }}
                        content={({ active, payload }) => {
                          if (active && payload && payload.length) {
                            const data = payload[0].payload
                            return (
                              <div className="bg-white p-3 border rounded shadow-lg">
                                <p className="font-semibold">Performance Metrics</p>
                                <p>Rating: {data.rating}/5.0</p>
                                <p>Delivery Time: {data.deliveryTime} min</p>
                                <p>Total Orders: {data.orders}</p>
                                <p>Satisfaction: {data.satisfaction}%</p>
                              </div>
                            )
                          }
                          return null
                        }}
                      />
                      <Scatter dataKey="deliveryTime" fill="var(--color-deliveryTime)" />
                    </ScatterChart>
                  </ChartContainer>

                  <div className="mt-4 p-4 bg-yellow-50 rounded-lg">
                    <h4 className="font-semibold text-yellow-800 mb-2">Key Insights:</h4>
                    <ul className="text-sm text-yellow-700 space-y-1">
                      <li>• Very strong negative correlation (-0.92) between rating and delivery time</li>
                      <li>• 5-star rated delivery persons average 17-19 minutes</li>
                      <li>• Each 0.1 rating increase correlates with ~2 minutes faster delivery</li>
                      <li>• High-rated delivery persons handle 40% more orders</li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          {activeChart === "vehicle-box" && (
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center justify-between">
                    <div className="flex items-center">
                      <Truck className="mr-2 h-5 w-5" />
                      Delivery Time by Vehicle Type & Order Type (Box Plot)
                    </div>
                    <Badge className="bg-purple-500 text-white">Statistical Analysis</Badge>
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-[500px]">
                    <ResponsiveContainer width="100%" height="100%">
                      <ComposedChart data={boxPlotData} margin={{ top: 20, right: 30, left: 20, bottom: 100 }}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="category" angle={-45} textAnchor="end" height={100} interval={0} />
                        <YAxis label={{ value: "Delivery Time (min)", angle: -90, position: "insideLeft" }} />
                        <Tooltip
                          content={({ active, payload, label }) => {
                            if (active && payload && payload.length) {
                              const data = payload[0].payload
                              return (
                                <div className="bg-white p-3 border rounded shadow-lg">
                                  <p className="font-semibold">
                                    {data.vehicle} - {data.orderType}
                                  </p>
                                  <p>Min: {data.min} min</p>
                                  <p>Q1: {data.q1} min</p>
                                  <p>Median: {data.median} min</p>
                                  <p>Q3: {data.q3} min</p>
                                  <p>Max: {data.max} min</p>
                                </div>
                              )
                            }
                            return null
                          }}
                        />
                        {/* Whiskers */}
                        <Bar dataKey="min" fill="transparent" stroke="#8884d8" strokeWidth={1} />
                        <Bar dataKey="max" fill="transparent" stroke="#8884d8" strokeWidth={1} />
                        {/* Box */}
                        <Bar dataKey="q1" stackId="box" fill="#8884d8" fillOpacity={0.6} />
                        <Bar dataKey="median" stackId="box" fill="#82ca9d" />
                        <Bar dataKey="q3" stackId="box" fill="#8884d8" fillOpacity={0.6} />
                      </ComposedChart>
                    </ResponsiveContainer>
                  </div>

                  <div className="mt-4 p-4 bg-purple-50 rounded-lg">
                    <h4 className="font-semibold text-purple-800 mb-2">Key Insights:</h4>
                    <ul className="text-sm text-purple-700 space-y-1">
                      <li>• Motorcycles consistently deliver fastest across all order types</li>
                      <li>• Express orders reduce delivery time by 15-20% regardless of vehicle</li>
                      <li>• Bicycles show highest variability in delivery times</li>
                      <li>• Scooters provide good balance between speed and consistency</li>
                    </ul>
                  </div>

                  {/* Summary Statistics Table */}
                  <div className="mt-6">
                    <h4 className="font-semibold mb-3">Summary Statistics</h4>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm border-collapse border border-gray-300">
                        <thead>
                          <tr className="bg-gray-100">
                            <th className="border border-gray-300 p-2 text-left">Vehicle</th>
                            <th className="border border-gray-300 p-2 text-left">Order Type</th>
                            <th className="border border-gray-300 p-2 text-left">Median (min)</th>
                            <th className="border border-gray-300 p-2 text-left">Range (min)</th>
                            <th className="border border-gray-300 p-2 text-left">IQR (min)</th>
                          </tr>
                        </thead>
                        <tbody>
                          {boxPlotData.map((item, index) => (
                            <tr key={index} className={index % 2 === 0 ? "bg-gray-50" : "bg-white"}>
                              <td className="border border-gray-300 p-2">{item.vehicle}</td>
                              <td className="border border-gray-300 p-2">{item.orderType}</td>
                              <td className="border border-gray-300 p-2">{item.median}</td>
                              <td className="border border-gray-300 p-2">
                                {item.min} - {item.max}
                              </td>
                              <td className="border border-gray-300 p-2">{item.q3 - item.q1}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </div>
    </motion.div>
  )
}
