"use client"

import { X, Plus, Minus, ShoppingBag } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import Image from "next/image"

interface CartItem {
  id: string
  name: string
  price: number
  quantity: number
  image: string
  restaurant: string
}

interface CartProps {
  isOpen: boolean
  onClose: () => void
  items: CartItem[]
  onUpdateQuantity: (itemId: string, quantity: number) => void
  onRemoveItem: (itemId: string) => void
  total: number
  onPlaceOrder: () => void
}

export function Cart({ isOpen, onClose, items, onUpdateQuantity, onRemoveItem, total, onPlaceOrder }: CartProps) {
  if (!isOpen) return null

  const deliveryFee = 29
  const taxes = Math.round(total * 0.05)
  const finalTotal = total + deliveryFee + taxes

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex justify-end">
      <div className="bg-gradient-to-br from-white via-orange-50/30 to-red-50/30 w-full max-w-md h-full overflow-y-auto shadow-2xl">
        <div className="p-4 border-b border-orange-100 flex items-center justify-between bg-gradient-to-r from-orange-500 to-red-500 text-white">
          <h2 className="text-xl font-semibold flex items-center">
            <ShoppingBag className="mr-2 h-5 w-5" />
            Your Cart ({items.length})
          </h2>
          <Button variant="ghost" size="sm" onClick={onClose} className="text-white hover:bg-white/20">
            <X className="h-4 w-4" />
          </Button>
        </div>

        {items.length === 0 ? (
          <div className="p-8 text-center">
            <div className="bg-gradient-to-br from-orange-100 to-red-100 rounded-full w-24 h-24 flex items-center justify-center mx-auto mb-4">
              <ShoppingBag className="h-12 w-12 text-orange-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">Your cart is empty</h3>
            <p className="text-gray-500">Add some delicious items to get started!</p>
          </div>
        ) : (
          <>
            <div className="p-4 space-y-4">
              {items.map((item) => (
                <Card key={item.id} className="bg-white/80 backdrop-blur-sm border-orange-100 shadow-lg">
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-3">
                      <Image
                        src={item.image || "/placeholder.svg"}
                        alt={item.name}
                        width={60}
                        height={60}
                        className="rounded-md object-cover shadow-md"
                      />
                      <div className="flex-1">
                        <h4 className="font-medium text-gray-800">{item.name}</h4>
                        <p className="text-sm text-gray-500">{item.restaurant}</p>
                        <p className="font-semibold text-green-600 bg-green-50 inline-block px-2 py-1 rounded-full text-sm">
                          ₹{item.price}
                        </p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onUpdateQuantity(item.id, item.quantity - 1)}
                          className="border-orange-200 text-orange-600 hover:bg-orange-50"
                        >
                          <Minus className="h-3 w-3" />
                        </Button>
                        <span className="w-8 text-center font-semibold bg-orange-50 rounded px-2 py-1">
                          {item.quantity}
                        </span>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => onUpdateQuantity(item.id, item.quantity + 1)}
                          className="border-orange-200 text-orange-600 hover:bg-orange-50"
                        >
                          <Plus className="h-3 w-3" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            <div className="p-4 border-t border-orange-100 bg-gradient-to-br from-orange-50 to-red-50">
              <Card className="bg-white/90 backdrop-blur-sm border-orange-200 shadow-lg">
                <CardHeader className="bg-gradient-to-r from-orange-500 to-red-500 text-white rounded-t-lg">
                  <CardTitle className="text-lg">Order Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 p-4">
                  <div className="flex justify-between">
                    <span>Subtotal</span>
                    <span className="font-semibold">₹{total}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Delivery Fee</span>
                    <span className="font-semibold">₹{deliveryFee}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Taxes & Fees</span>
                    <span className="font-semibold">₹{taxes}</span>
                  </div>
                  <Separator className="bg-orange-200" />
                  <div className="flex justify-between font-semibold text-lg text-green-600">
                    <span>Total</span>
                    <span>₹{finalTotal}</span>
                  </div>
                  <Button
                    className="w-full mt-4 bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white border-none shadow-lg hover:shadow-xl transition-all duration-200"
                    size="lg"
                    onClick={onPlaceOrder}
                  >
                    Place Order - ₹{finalTotal}
                  </Button>
                </CardContent>
              </Card>
            </div>
          </>
        )}
      </div>
    </div>
  )
}
