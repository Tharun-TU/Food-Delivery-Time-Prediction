"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { Sparkles, Zap, Clock, Star } from "lucide-react"

const heroMessages = [
  { text: "Delicious Food Delivered Fast", icon: Zap, color: "from-orange-600 to-red-600" },
  { text: "AI-Powered Delivery Predictions", icon: Sparkles, color: "from-purple-600 to-pink-600" },
  { text: "Fresh Meals in Minutes", icon: Clock, color: "from-green-600 to-blue-600" },
  { text: "5-Star Restaurant Quality", icon: Star, color: "from-yellow-600 to-orange-600" },
]

export function AnimatedHero() {
  const [currentIndex, setCurrentIndex] = useState(0)

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % heroMessages.length)
    }, 3000)
    return () => clearInterval(interval)
  }, [])

  const currentMessage = heroMessages[currentIndex]
  const Icon = currentMessage.icon

  return (
    <div className="mb-8 text-center relative overflow-hidden">
      {/* Animated background particles */}
      <div className="absolute inset-0 overflow-hidden">
        {[...Array(20)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-2 h-2 bg-orange-300 rounded-full opacity-20"
            animate={{
              x: [0, 100, 0],
              y: [0, -100, 0],
              scale: [1, 1.5, 1],
            }}
            transition={{
              duration: 4 + Math.random() * 2,
              repeat: Number.POSITIVE_INFINITY,
              delay: Math.random() * 2,
            }}
            style={{
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
            }}
          />
        ))}
      </div>

      <AnimatePresence mode="wait">
        <motion.div
          key={currentIndex}
          initial={{ opacity: 0, y: 20, scale: 0.9 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -20, scale: 0.9 }}
          transition={{ duration: 0.5 }}
          className="relative z-10"
        >
          <div className={`bg-gradient-to-r ${currentMessage.color} bg-clip-text text-transparent`}>
            <motion.h1
              className="text-4xl md:text-6xl font-bold mb-4"
              animate={{ scale: [1, 1.02, 1] }}
              transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY }}
            >
              <Icon className="inline-block mr-4 h-12 w-12 md:h-16 md:w-16 text-orange-500" />
              {currentMessage.text}
            </motion.h1>
          </div>
        </motion.div>
      </AnimatePresence>

      <motion.p
        className="text-gray-700 text-lg md:text-xl mb-6"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
      >
        Order from your favorite restaurants and get it delivered in minutes
      </motion.p>

      <motion.div
        className="inline-flex items-center bg-white/80 backdrop-blur-sm rounded-full px-6 py-3 shadow-lg border border-orange-200"
        whileHover={{ scale: 1.05, boxShadow: "0 10px 25px rgba(0,0,0,0.1)" }}
        whileTap={{ scale: 0.95 }}
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.8 }}
      >
        <Sparkles className="h-5 w-5 text-orange-600 mr-2 animate-pulse" />
        <span className="text-orange-600 font-semibold">Real-time ML Predictions</span>
      </motion.div>

      {/* Progress indicators */}
      <div className="flex justify-center mt-6 space-x-2">
        {heroMessages.map((_, index) => (
          <motion.div
            key={index}
            className={`w-2 h-2 rounded-full ${index === currentIndex ? "bg-orange-500" : "bg-gray-300"}`}
            whileHover={{ scale: 1.2 }}
            animate={index === currentIndex ? { scale: [1, 1.2, 1] } : {}}
            transition={{ duration: 0.5 }}
          />
        ))}
      </div>
    </div>
  )
}
