"use client"

import { useState, useEffect } from "react"
import { Header } from "@/components/header"
import { AnimatedHero } from "@/components/animated-hero"
import { InteractiveFoodGrid } from "@/components/interactive-food-grid"
import { EnhancedCart } from "@/components/enhanced-cart"
import { LocationPicker } from "@/components/location-picker"
import { EnhancedOrderConfirmation } from "@/components/enhanced-order-confirmation"
import { OrderTracking } from "@/components/order-tracking"
import { LoginPage } from "@/components/login-page"
import { AIFoodAssistantWithAPI } from "@/components/ai-food-assistant-with-api"
import { SustainabilityTracker } from "@/components/sustainability-tracker"
import { PredictiveOrdering } from "@/components/predictive-ordering"
import { MLAnalyticsDashboard } from "@/components/ml-analytics-dashboard"
import { Toaster } from "@/components/ui/toaster"

export default function FoodDeliveryApp() {
  const [currentView, setCurrentView] = useState("login")
  const [user, setUser] = useState(null)
  const [location, setLocation] = useState(null)
  const [cart, setCart] = useState([])
  const [order, setOrder] = useState(null)
  const [showAIAssistant, setShowAIAssistant] = useState(false)
  const [isLoading, setIsLoading] = useState(true)

  // Initialize app with error handling
  useEffect(() => {
    const initializeApp = async () => {
      try {
        // Simulate initialization delay
        await new Promise((resolve) => setTimeout(resolve, 1000))

        // Check for existing session
        const savedUser = localStorage.getItem("user")
        const savedLocation = localStorage.getItem("location")
        const savedCart = localStorage.getItem("cart")

        if (savedUser) {
          setUser(JSON.parse(savedUser))
          setCurrentView("home")
        }
        if (savedLocation) {
          setLocation(JSON.parse(savedLocation))
        }
        if (savedCart) {
          setCart(JSON.parse(savedCart))
        }
      } catch (error) {
        console.error("App initialization error:", error)
        // Continue with default state
      } finally {
        setIsLoading(false)
      }
    }

    initializeApp()
  }, [])

  // Save to localStorage with error handling
  useEffect(() => {
    try {
      if (user) localStorage.setItem("user", JSON.stringify(user))
      if (location) localStorage.setItem("location", JSON.stringify(location))
      if (cart.length > 0) localStorage.setItem("cart", JSON.stringify(cart))
    } catch (error) {
      console.error("Storage error:", error)
    }
  }, [user, location, cart])

  const handleLogin = (userData) => {
    setUser(userData)
    setCurrentView("location")
  }

  const handleLocationSet = (locationData) => {
    setLocation(locationData)
    setCurrentView("home")
  }

  const addToCart = (item) => {
    setCart((prev) => {
      const existing = prev.find((cartItem) => cartItem.id === item.id)
      if (existing) {
        return prev.map((cartItem) =>
          cartItem.id === item.id ? { ...cartItem, quantity: cartItem.quantity + 1 } : cartItem,
        )
      }
      return [...prev, { ...item, quantity: 1 }]
    })
  }

  const removeFromCart = (itemId) => {
    setCart((prev) => prev.filter((item) => item.id !== itemId))
  }

  const updateCartQuantity = (itemId, quantity) => {
    if (quantity === 0) {
      removeFromCart(itemId)
      return
    }
    setCart((prev) => prev.map((item) => (item.id === itemId ? { ...item, quantity } : item)))
  }

  const handleOrderPlace = (orderData) => {
    setOrder(orderData)
    setCart([])
    setCurrentView("tracking")
  }

  const handleLogout = () => {
    setUser(null)
    setLocation(null)
    setCart([])
    setOrder(null)
    setCurrentView("login")
    localStorage.clear()
  }

  // Loading screen
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading Food Delivery App...</p>
        </div>
      </div>
    )
  }

  // Error boundary wrapper
  const renderView = () => {
    try {
      switch (currentView) {
        case "login":
          return <LoginPage onLogin={handleLogin} />

        case "location":
          return (
            <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50">
              <Header
                user={user}
                cartItemCount={cart.reduce((sum, item) => sum + item.quantity, 0)}
                onCartClick={() => setCurrentView("cart")}
                onLogout={handleLogout}
                onShowAI={() => setShowAIAssistant(true)}
              />
              <LocationPicker onLocationSet={handleLocationSet} />
            </div>
          )

        case "home":
          return (
            <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50">
              <Header
                user={user}
                cartItemCount={cart.reduce((sum, item) => sum + item.quantity, 0)}
                onCartClick={() => setCurrentView("cart")}
                onLogout={handleLogout}
                onShowAI={() => setShowAIAssistant(true)}
              />
              <AnimatedHero />
              <PredictiveOrdering userHistory={[]} onQuickOrder={addToCart} />
              <InteractiveFoodGrid onAddToCart={addToCart} />
              <SustainabilityTracker deliveryDistance={location?.distance || 5} vehicleType="bike" />
            </div>
          )

        case "cart":
          return (
            <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50">
              <Header
                user={user}
                cartItemCount={cart.reduce((sum, item) => sum + item.quantity, 0)}
                onCartClick={() => setCurrentView("cart")}
                onLogout={handleLogout}
                onShowAI={() => setShowAIAssistant(true)}
              />
              <EnhancedCart
                items={cart}
                onUpdateQuantity={updateCartQuantity}
                onRemoveItem={removeFromCart}
                onCheckout={() => setCurrentView("checkout")}
                onContinueShopping={() => setCurrentView("home")}
              />
            </div>
          )

        case "checkout":
          return (
            <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50">
              <Header
                user={user}
                cartItemCount={cart.reduce((sum, item) => sum + item.quantity, 0)}
                onCartClick={() => setCurrentView("cart")}
                onLogout={handleLogout}
                onShowAI={() => setShowAIAssistant(true)}
              />
              <EnhancedOrderConfirmation
                cart={cart}
                user={user}
                location={location}
                onOrderPlace={handleOrderPlace}
                onBack={() => setCurrentView("cart")}
              />
            </div>
          )

        case "tracking":
          return (
            <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50">
              <Header
                user={user}
                cartItemCount={0}
                onCartClick={() => setCurrentView("cart")}
                onLogout={handleLogout}
                onShowAI={() => setShowAIAssistant(true)}
              />
              <OrderTracking
                order={order}
                onNewOrder={() => setCurrentView("home")}
                onViewAnalytics={() => setCurrentView("analytics")}
              />
            </div>
          )

        case "analytics":
          return (
            <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50">
              <Header
                user={user}
                cartItemCount={cart.reduce((sum, item) => sum + item.quantity, 0)}
                onCartClick={() => setCurrentView("cart")}
                onLogout={handleLogout}
                onShowAI={() => setShowAIAssistant(true)}
              />
              <MLAnalyticsDashboard onBack={() => setCurrentView("home")} />
            </div>
          )

        default:
          return <LoginPage onLogin={handleLogin} />
      }
    } catch (error) {
      console.error("View rendering error:", error)
      return (
        <div className="min-h-screen bg-gradient-to-br from-orange-50 to-red-50 flex items-center justify-center">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-gray-800 mb-4">Something went wrong</h2>
            <p className="text-gray-600 mb-4">Please try refreshing the page</p>
            <button
              onClick={() => window.location.reload()}
              className="bg-orange-500 text-white px-4 py-2 rounded-lg hover:bg-orange-600"
            >
              Refresh Page
            </button>
          </div>
        </div>
      )
    }
  }

  return (
    <>
      {renderView()}

      {/* AI Assistant Modal */}
      {showAIAssistant && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[80vh] overflow-hidden">
            <div className="p-4 border-b flex justify-between items-center">
              <h3 className="text-lg font-semibold">AI Food Assistant</h3>
              <button onClick={() => setShowAIAssistant(false)} className="text-gray-500 hover:text-gray-700">
                ✕
              </button>
            </div>
            <div className="p-4 max-h-[60vh] overflow-y-auto">
              <AIFoodAssistantWithAPI />
            </div>
          </div>
        </div>
      )}

      <Toaster />
    </>
  )
}
