import { type NextRequest, NextResponse } from "next/server"

// Server-side weather and traffic API calls
interface WeatherData {
  condition: string
  temperature: number
  humidity: number
  windSpeed: number
  visibility: number
}

interface TrafficData {
  density: string
  delayFactor: number
  estimatedDelay: number
}

// Server-side API keys (secure)
const OPENWEATHER_API_KEY = process.env.OPENWEATHER_API_KEY
const GOOGLE_MAPS_API_KEY = process.env.GOOGLE_MAPS_API_KEY

export async function POST(request: NextRequest) {
  try {
    const { type, ...params } = await request.json()

    switch (type) {
      case "weather":
        return NextResponse.json(await getWeatherData(params.lat, params.lng))
      case "traffic":
        return NextResponse.json(
          await getTrafficData(params.originLat, params.originLng, params.destLat, params.destLng),
        )
      case "comprehensive":
        return NextResponse.json(
          await getComprehensiveData(
            params.restaurantLat,
            params.restaurantLng,
            params.customerLat,
            params.customerLng,
          ),
        )
      default:
        return NextResponse.json({ error: "Invalid request type" }, { status: 400 })
    }
  } catch (error) {
    console.error("Weather/Traffic API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

async function getWeatherData(lat: number, lng: number): Promise<WeatherData> {
  if (!OPENWEATHER_API_KEY) {
    console.warn("OpenWeatherMap API key not found, using enhanced simulation")
    return getEnhancedWeatherSimulation(lat, lng)
  }

  try {
    console.log(`🌤️ Fetching real weather data for ${lat}, ${lng}`)

    const response = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lng}&appid=${OPENWEATHER_API_KEY}&units=metric`,
      { signal: AbortSignal.timeout(5000) },
    )

    if (!response.ok) {
      throw new Error(`Weather API error: ${response.status}`)
    }

    const data = await response.json()

    // Map OpenWeatherMap conditions to our system
    const weatherCondition = mapWeatherCondition(data.weather[0].main, data.weather[0].description)

    const weatherData: WeatherData = {
      condition: weatherCondition,
      temperature: data.main.temp,
      humidity: data.main.humidity,
      windSpeed: data.wind?.speed || 0,
      visibility: data.visibility ? data.visibility / 1000 : 10, // Convert to km
    }

    console.log("✅ Real weather data received:", weatherData)
    return weatherData
  } catch (error) {
    console.error("❌ Weather API error:", error)
    return getEnhancedWeatherSimulation(lat, lng)
  }
}

async function getTrafficData(
  originLat: number,
  originLng: number,
  destLat: number,
  destLng: number,
): Promise<TrafficData> {
  if (!GOOGLE_MAPS_API_KEY) {
    console.warn("Google Maps API key not found, using enhanced simulation")
    return getEnhancedTrafficSimulation()
  }

  try {
    console.log(`🚦 Fetching real traffic data from ${originLat},${originLng} to ${destLat},${destLng}`)

    const response = await fetch(
      `https://maps.googleapis.com/maps/api/directions/json?` +
        `origin=${originLat},${originLng}&` +
        `destination=${destLat},${destLng}&` +
        `departure_time=now&` +
        `traffic_model=best_guess&` +
        `key=${GOOGLE_MAPS_API_KEY}`,
      { signal: AbortSignal.timeout(8000) },
    )

    if (!response.ok) {
      throw new Error(`Traffic API error: ${response.status}`)
    }

    const data = await response.json()

    if (data.status !== "OK" || !data.routes || data.routes.length === 0) {
      throw new Error(`Traffic API response error: ${data.status}`)
    }

    const route = data.routes[0].legs[0]
    const normalDuration = route.duration.value // seconds
    const trafficDuration = route.duration_in_traffic?.value || normalDuration // seconds

    // Calculate traffic delay
    const delaySeconds = trafficDuration - normalDuration
    const delayMinutes = Math.max(0, delaySeconds / 60)
    const delayPercentage = ((trafficDuration - normalDuration) / normalDuration) * 100

    // Map delay to traffic density
    let density: string
    if (delayPercentage < 10) density = "Low"
    else if (delayPercentage < 30) density = "Medium"
    else if (delayPercentage < 60) density = "High"
    else density = "Jam"

    const trafficData: TrafficData = {
      density,
      delayFactor: delayPercentage,
      estimatedDelay: delayMinutes,
    }

    console.log("✅ Real traffic data received:", trafficData)
    return trafficData
  } catch (error) {
    console.error("❌ Traffic API error:", error)
    return getEnhancedTrafficSimulation()
  }
}

async function getComprehensiveData(
  restaurantLat: number,
  restaurantLng: number,
  customerLat: number,
  customerLng: number,
): Promise<{
  weather_conditions: string
  road_traffic_density: string
  festival: string
  weather_details: WeatherData
  traffic_details: TrafficData
  data_source: "real_api" | "enhanced_simulation"
}> {
  try {
    console.log("🔄 Fetching comprehensive delivery factors...")

    // Fetch weather and traffic data in parallel
    const [weatherData, trafficData] = await Promise.all([
      getWeatherData(customerLat, customerLng),
      getTrafficData(restaurantLat, restaurantLng, customerLat, customerLng),
    ])

    // Check if we got real data or simulation
    const hasRealWeatherAPI = !!OPENWEATHER_API_KEY
    const hasRealTrafficAPI = !!GOOGLE_MAPS_API_KEY
    const dataSource = hasRealWeatherAPI && hasRealTrafficAPI ? "real_api" : "enhanced_simulation"

    // Festival detection
    const festival = detectFestival()

    const result = {
      weather_conditions: weatherData.condition,
      road_traffic_density: trafficData.density,
      festival,
      weather_details: weatherData,
      traffic_details: trafficData,
      data_source: dataSource as "real_api" | "enhanced_simulation",
    }

    console.log("✅ Comprehensive delivery factors:", result)
    return result
  } catch (error) {
    console.error("❌ Error getting comprehensive delivery factors:", error)

    // Fallback to basic simulation
    return {
      weather_conditions: "Cloudy",
      road_traffic_density: "Medium",
      festival: "No",
      weather_details: {
        condition: "Cloudy",
        temperature: 25,
        humidity: 60,
        windSpeed: 5,
        visibility: 8,
      },
      traffic_details: {
        density: "Medium",
        delayFactor: 20,
        estimatedDelay: 5,
      },
      data_source: "enhanced_simulation",
    }
  }
}

// Helper functions
function mapWeatherCondition(main: string, description: string): string {
  const mainCondition = main.toLowerCase()
  const desc = description.toLowerCase()

  switch (mainCondition) {
    case "clear":
      return "Sunny"
    case "clouds":
      if (desc.includes("few") || desc.includes("scattered")) return "Cloudy"
      if (desc.includes("broken") || desc.includes("overcast")) return "Cloudy"
      return "Cloudy"
    case "rain":
    case "drizzle":
    case "thunderstorm":
      return "Stormy"
    case "snow":
      return "Stormy"
    case "mist":
    case "fog":
    case "haze":
      return "Fog"
    case "dust":
    case "sand":
      return "Sandstorms"
    default:
      if (desc.includes("wind")) return "Windy"
      return "Cloudy"
  }
}

function getEnhancedWeatherSimulation(lat: number, lng: number): WeatherData {
  const month = new Date().getMonth() + 1 // 1-12
  const hour = new Date().getHours()

  let condition = "Sunny"
  let temperature = 25
  let humidity = 60
  let windSpeed = 5
  let visibility = 10

  // Bangalore weather patterns (12.8-13.1 lat, 77.4-77.8 lng)
  if (lat >= 12.8 && lat <= 13.1 && lng >= 77.4 && lng <= 77.8) {
    // Monsoon season (June-September)
    if (month >= 6 && month <= 9) {
      const monsoonConditions = ["Stormy", "Cloudy", "Fog"]
      condition = monsoonConditions[Math.floor(Math.random() * monsoonConditions.length)]
      temperature = 22 + Math.random() * 6 // 22-28°C
      humidity = 80 + Math.random() * 15 // 80-95%
      windSpeed = 8 + Math.random() * 7 // 8-15 km/h
      visibility = condition === "Fog" ? 2 + Math.random() * 3 : 8 + Math.random() * 2
    }
    // Winter (December-February)
    else if (month >= 12 || month <= 2) {
      const winterConditions = ["Sunny", "Cloudy", "Fog"]
      condition = winterConditions[Math.floor(Math.random() * winterConditions.length)]
      temperature = 15 + Math.random() * 10 // 15-25°C
      humidity = 50 + Math.random() * 20 // 50-70%
      windSpeed = 3 + Math.random() * 5 // 3-8 km/h
      visibility = condition === "Fog" ? 1 + Math.random() * 2 : 9 + Math.random() * 1
    }
    // Summer (March-May)
    else if (month >= 3 && month <= 5) {
      const summerConditions = ["Sunny", "Windy", "Cloudy"]
      condition = summerConditions[Math.floor(Math.random() * summerConditions.length)]
      temperature = 25 + Math.random() * 10 // 25-35°C
      humidity = 40 + Math.random() * 20 // 40-60%
      windSpeed = condition === "Windy" ? 12 + Math.random() * 8 : 5 + Math.random() * 5
      visibility = 8 + Math.random() * 2
    }
  }

  // Evening/night adjustments
  if (hour >= 18 || hour <= 6) {
    temperature -= 3 + Math.random() * 4 // Cooler at night
    humidity += 10 + Math.random() * 10 // Higher humidity
    if (hour >= 22 || hour <= 6) {
      // Higher chance of fog at night
      if (Math.random() > 0.7) {
        condition = "Fog"
        visibility = 1 + Math.random() * 3
      }
    }
  }

  return {
    condition,
    temperature: Math.round(temperature * 10) / 10,
    humidity: Math.round(humidity),
    windSpeed: Math.round(windSpeed * 10) / 10,
    visibility: Math.round(visibility * 10) / 10,
  }
}

function getEnhancedTrafficSimulation(): TrafficData {
  const hour = new Date().getHours()
  const dayOfWeek = new Date().getDay() // 0 = Sunday, 6 = Saturday

  let density = "Low"
  let delayFactor = 5
  let estimatedDelay = 2

  // Weekend traffic is generally lighter
  if (dayOfWeek === 0 || dayOfWeek === 6) {
    // Weekend patterns
    if (hour >= 11 && hour <= 14) {
      // Weekend lunch rush
      density = Math.random() > 0.5 ? "Medium" : "Low"
      delayFactor = 15 + Math.random() * 15
      estimatedDelay = 3 + Math.random() * 4
    } else if (hour >= 19 && hour <= 22) {
      // Weekend evening
      density = Math.random() > 0.4 ? "Medium" : "High"
      delayFactor = 20 + Math.random() * 20
      estimatedDelay = 4 + Math.random() * 6
    }
  } else {
    // Weekday patterns
    if (hour >= 7 && hour <= 10) {
      // Morning rush hour
      density = Math.random() > 0.2 ? "High" : "Jam"
      delayFactor = 40 + Math.random() * 30
      estimatedDelay = 8 + Math.random() * 10
    } else if (hour >= 12 && hour <= 14) {
      // Lunch time
      density = Math.random() > 0.3 ? "Medium" : "High"
      delayFactor = 25 + Math.random() * 20
      estimatedDelay = 5 + Math.random() * 6
    } else if (hour >= 17 && hour <= 21) {
      // Evening rush hour
      density = Math.random() > 0.1 ? "High" : "Jam"
      delayFactor = 50 + Math.random() * 40
      estimatedDelay = 10 + Math.random() * 15
    } else if (hour >= 22 || hour <= 6) {
      // Late night/early morning
      density = "Low"
      delayFactor = 0 + Math.random() * 10
      estimatedDelay = 0 + Math.random() * 2
    } else {
      // Normal hours
      density = Math.random() > 0.6 ? "Medium" : "Low"
      delayFactor = 10 + Math.random() * 15
      estimatedDelay = 2 + Math.random() * 4
    }
  }

  return {
    density,
    delayFactor: Math.round(delayFactor * 10) / 10,
    estimatedDelay: Math.round(estimatedDelay * 10) / 10,
  }
}

function detectFestival(): string {
  const today = new Date()
  const month = today.getMonth() + 1
  const date = today.getDate()

  // Major Indian festivals (simplified)
  const festivals = [
    { month: 10, dates: [15, 16, 17, 18, 19], name: "Diwali" },
    { month: 8, dates: [15], name: "Independence Day" },
    { month: 1, dates: [26], name: "Republic Day" },
    { month: 10, dates: [2], name: "Gandhi Jayanti" },
    { month: 3, dates: [8], name: "Holi" }, // Approximate
    { month: 8, dates: [19], name: "Janmashtami" }, // Approximate
  ]

  for (const festival of festivals) {
    if (festival.month === month && festival.dates.includes(date)) {
      console.log(`🎉 Festival detected: ${festival.name}`)
      return "Yes"
    }
  }

  // Random chance for local festivals/events
  return Math.random() > 0.95 ? "Yes" : "No"
}
