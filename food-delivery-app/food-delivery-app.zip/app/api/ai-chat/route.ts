import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const { message, provider, apiKey } = await request.json()

    if (!message) {
      return NextResponse.json({ error: "Message is required" }, { status: 400 })
    }

    let response: string

    switch (provider) {
      case "openai":
        response = await callOpenAI(message, apiKey)
        break
      case "gemini":
        response = await callGemini(message, apiKey)
        break
      case "claude":
        response = await callClaude(message, apiKey)
        break
      default:
        response = getLocalResponse(message)
    }

    return NextResponse.json({ response })
  } catch (error) {
    console.error("AI Chat API Error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

async function callOpenAI(message: string, apiKey: string): Promise<string> {
  const response = await fetch("https://api.openai.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "gpt-4",
      messages: [
        {
          role: "system",
          content: `You are a professional nutritionist and food expert AI assistant for a food delivery app. 
          Your expertise includes:
          - Nutritional science and dietary recommendations
          - Food pairing and meal planning
          - Health-conscious food choices
          - Restaurant and cuisine knowledge
          - Dietary restrictions and allergies
          
          Always provide helpful, accurate, and personalized food recommendations. 
          Include specific nutritional benefits and explain your reasoning.
          Keep responses conversational but informative.
          If suggesting foods, mention calories, health benefits, and why it's good for the user's specific needs.`,
        },
        {
          role: "user",
          content: message,
        },
      ],
      max_tokens: 500,
      temperature: 0.7,
    }),
  })

  const data = await response.json()
  return data.choices[0]?.message?.content || "I apologize, but I cannot process that request right now."
}

async function callGemini(message: string, apiKey: string): Promise<string> {
  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=${apiKey}`,
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        contents: [
          {
            parts: [
              {
                text: `You are a professional nutritionist and food expert AI assistant. 
                User question: ${message}
                
                Please provide helpful food and nutrition advice, including specific recommendations with health benefits.`,
              },
            ],
          },
        ],
        generationConfig: {
          temperature: 0.7,
          maxOutputTokens: 500,
        },
      }),
    },
  )

  const data = await response.json()
  return data.candidates[0]?.content?.parts[0]?.text || "I apologize, but I cannot process that request right now."
}

async function callClaude(message: string, apiKey: string): Promise<string> {
  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model: "claude-3-sonnet-20240229",
      max_tokens: 500,
      messages: [
        {
          role: "user",
          content: `You are a professional nutritionist and food expert AI assistant for a food delivery app. 
          Please help with this food/nutrition question: ${message}
          
          Provide specific, helpful recommendations with nutritional benefits and reasoning.`,
        },
      ],
    }),
  })

  const data = await response.json()
  return data.content[0]?.text || "I apologize, but I cannot process that request right now."
}

function getLocalResponse(message: string): string {
  const msg = message.toLowerCase()

  if (msg.includes("stressed") || msg.includes("anxiety")) {
    return "I understand you're feeling stressed. Foods rich in magnesium like dark chocolate, nuts, and leafy greens can help reduce cortisol levels. Omega-3 fatty acids from salmon also support brain health and stress reduction. Would you like specific meal recommendations?"
  }

  if (msg.includes("energy") || msg.includes("tired")) {
    return "For sustained energy, I recommend complex carbohydrates paired with protein. Try quinoa bowls with lean protein, or oatmeal with nuts and berries. These provide steady glucose release without energy crashes. B-vitamins in whole grains also support energy metabolism!"
  }

  return "I'm here to help with all your nutrition and food questions! I can provide personalized recommendations based on your health goals, dietary preferences, mood, or any specific needs you have. What would you like to know about?"
}
