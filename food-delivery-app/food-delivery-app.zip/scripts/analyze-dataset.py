import pandas as pd
import numpy as np
import json
from collections import defaultdict

# Load and analyze the delivery dataset
def analyze_delivery_dataset():
    print("🔍 Starting Dataset Analysis...")
    
    # For this demo, I'll create a sample dataset structure based on your columns
    # Replace this with: df = pd.read_csv('your_dataset.csv')
    
    # Create sample data that matches your dataset structure
    np.random.seed(42)
    n_samples = 10000
    
    # Generate realistic sample data
    data = {
        'delivery_person_age': np.random.choice([22, 25, 28, 31, 35, 38, 42, 45], n_samples),
        'delivery_person_ratings': np.random.choice([3.8, 4.1, 4.3, 4.5, 4.7, 4.8, 4.9], n_samples),
        'restaurant_latitude': np.random.normal(12.9716, 0.05, n_samples),
        'restaurant_longitude': np.random.normal(77.5946, 0.05, n_samples),
        'delivery_location_latitude': np.random.normal(12.9716, 0.1, n_samples),
        'delivery_location_longitude': np.random.normal(77.5946, 0.1, n_samples),
        'weather_conditions': np.random.choice(['Sunny', 'Cloudy', 'Fog', 'Windy', 'Stormy'], n_samples, p=[0.3, 0.25, 0.15, 0.2, 0.1]),
        'road_traffic_density': np.random.choice(['Low', 'Medium', 'High', 'Jam'], n_samples, p=[0.2, 0.4, 0.3, 0.1]),
        'vehicle_condition': np.random.choice([1, 2, 3], n_samples, p=[0.1, 0.7, 0.2]),
        'type_of_order': np.random.choice(['Snack', 'Meal', 'Drinks', 'Buffet'], n_samples, p=[0.2, 0.5, 0.2, 0.1]),
        'type_of_vehicle': np.random.choice(['bicycle', 'scooter', 'motorcycle'], n_samples, p=[0.1, 0.6, 0.3]),
        'multiple_deliveries': np.random.choice([0, 1, 2], n_samples, p=[0.7, 0.25, 0.05]),
        'festival': np.random.choice(['No', 'Yes'], n_samples, p=[0.9, 0.1]),
        'city': np.random.choice(['Urban', 'Semi-Urban', 'Metropolitan'], n_samples, p=[0.5, 0.3, 0.2])
    }
    
    df = pd.DataFrame(data)
    
    # Calculate realistic delivery times based on factors
    def calculate_realistic_time(row):
        # Base time
        base_time = 15
        
        # Distance factor (calculate distance)
        distance = np.sqrt((row['restaurant_latitude'] - row['delivery_location_latitude'])**2 + 
                          (row['restaurant_longitude'] - row['delivery_location_longitude'])**2) * 111  # Convert to km
        distance_time = distance * 2.5
        
        # Weather factor
        weather_multiplier = {'Sunny': 1.0, 'Cloudy': 1.1, 'Fog': 1.3, 'Windy': 1.15, 'Stormy': 1.4}
        weather_time = base_time * (weather_multiplier[row['weather_conditions']] - 1)
        
        # Traffic factor
        traffic_multiplier = {'Low': 1.0, 'Medium': 1.2, 'High': 1.4, 'Jam': 1.8}
        traffic_time = base_time * (traffic_multiplier[row['road_traffic_density']] - 1)
        
        # Vehicle factor
        vehicle_multiplier = {'bicycle': 1.3, 'scooter': 1.0, 'motorcycle': 0.85}
        vehicle_time = base_time * (vehicle_multiplier[row['type_of_vehicle']] - 1)
        
        # Other factors
        age_factor = 2 if row['delivery_person_age'] > 40 else -1 if row['delivery_person_age'] < 25 else 0
        rating_factor = (4.5 - row['delivery_person_ratings']) * 2
        multiple_factor = row['multiple_deliveries'] * 8
        festival_factor = 10 if row['festival'] == 'Yes' else 0
        
        total_time = (base_time + distance_time + weather_time + traffic_time + vehicle_time + 
                     age_factor + rating_factor + multiple_factor + festival_factor)
        
        # Add some noise
        noise = np.random.normal(0, 3)
        return max(10, total_time + noise)
    
    df['time_taken'] = df.apply(calculate_realistic_time, axis=1)
    
    print(f"📊 Dataset loaded: {len(df)} records")
    print(f"⏱️ Time range: {df['time_taken'].min():.1f} - {df['time_taken'].max():.1f} minutes")
    print(f"📈 Average delivery time: {df['time_taken'].mean():.1f} minutes")
    
    return df

def extract_patterns(df):
    print("\n🔍 Extracting Delivery Patterns...")
    
    patterns = {}
    
    # 1. Weather + Traffic + Vehicle combinations
    print("1. Analyzing Weather + Traffic + Vehicle patterns...")
    weather_traffic_vehicle = df.groupby(['weather_conditions', 'road_traffic_density', 'type_of_vehicle'])['time_taken'].agg(['mean', 'std', 'count']).round(2)
    
    for (weather, traffic, vehicle), stats in weather_traffic_vehicle.iterrows():
        if stats['count'] >= 10:  # Only include patterns with enough data
            key = f"{weather}_{traffic}_{vehicle}"
            patterns[key] = {
                'avg': float(stats['mean']),
                'std': float(stats['std']),
                'count': int(stats['count']),
                'factors': {'weather': weather, 'traffic': traffic, 'vehicle': vehicle}
            }
    
    print(f"   Found {len(patterns)} weather+traffic+vehicle patterns")
    
    # 2. Distance-based patterns
    print("2. Analyzing distance patterns...")
    df['distance_km'] = np.sqrt((df['restaurant_latitude'] - df['delivery_location_latitude'])**2 + 
                               (df['restaurant_longitude'] - df['delivery_location_longitude'])**2) * 111
    
    # Create distance bins
    df['distance_bin'] = pd.cut(df['distance_km'], bins=[0, 1, 3, 5, 10, 20], labels=['very_close', 'close', 'medium', 'far', 'very_far'])
    
    distance_patterns = df.groupby('distance_bin')['time_taken'].agg(['mean', 'std', 'count']).round(2)
    
    for distance_bin, stats in distance_patterns.iterrows():
        key = f"distance_{distance_bin}"
        patterns[key] = {
            'avg': float(stats['mean']),
            'std': float(stats['std']),
            'count': int(stats['count']),
            'factors': {'distance_category': str(distance_bin)}
        }
    
    # 3. Time of day patterns (simulate)
    print("3. Analyzing time-of-day patterns...")
    hours = np.random.choice(range(8, 23), len(df))
    df['order_hour'] = hours
    
    # Create time bins
    df['time_bin'] = pd.cut(df['order_hour'], 
                           bins=[7, 11, 14, 17, 21, 24], 
                           labels=['morning', 'lunch', 'afternoon', 'dinner', 'night'])
    
    time_patterns = df.groupby('time_bin')['time_taken'].agg(['mean', 'std', 'count']).round(2)
    
    for time_bin, stats in time_patterns.iterrows():
        key = f"time_{time_bin}"
        patterns[key] = {
            'avg': float(stats['mean']),
            'std': float(stats['std']),
            'count': int(stats['count']),
            'factors': {'time_period': str(time_bin)}
        }
    
    # 4. Delivery person performance patterns
    print("4. Analyzing delivery person patterns...")
    df['rating_bin'] = pd.cut(df['delivery_person_ratings'], 
                             bins=[0, 4.0, 4.5, 5.0], 
                             labels=['low_rating', 'medium_rating', 'high_rating'])
    
    df['age_bin'] = pd.cut(df['delivery_person_age'], 
                          bins=[0, 25, 35, 50], 
                          labels=['young', 'middle', 'senior'])
    
    person_patterns = df.groupby(['rating_bin', 'age_bin'])['time_taken'].agg(['mean', 'std', 'count']).round(2)
    
    for (rating_bin, age_bin), stats in person_patterns.iterrows():
        if stats['count'] >= 5:
            key = f"person_{rating_bin}_{age_bin}"
            patterns[key] = {
                'avg': float(stats['mean']),
                'std': float(stats['std']),
                'count': int(stats['count']),
                'factors': {'rating_category': str(rating_bin), 'age_category': str(age_bin)}
            }
    
    # 5. Special conditions
    print("5. Analyzing special conditions...")
    
    # Festival impact
    festival_patterns = df.groupby('festival')['time_taken'].agg(['mean', 'std', 'count']).round(2)
    for festival, stats in festival_patterns.iterrows():
        key = f"festival_{festival.lower()}"
        patterns[key] = {
            'avg': float(stats['mean']),
            'std': float(stats['std']),
            'count': int(stats['count']),
            'factors': {'festival': festival}
        }
    
    # Multiple deliveries impact
    multiple_patterns = df.groupby('multiple_deliveries')['time_taken'].agg(['mean', 'std', 'count']).round(2)
    for multiple, stats in multiple_patterns.iterrows():
        key = f"multiple_{multiple}"
        patterns[key] = {
            'avg': float(stats['mean']),
            'std': float(stats['std']),
            'count': int(stats['count']),
            'factors': {'multiple_deliveries': int(multiple)}
        }
    
    print(f"\n✅ Total patterns extracted: {len(patterns)}")
    
    return patterns, df

def generate_insights(df, patterns):
    print("\n📈 Generating Key Insights...")
    
    insights = {}
    
    # 1. Most impactful factors
    print("1. Factor Impact Analysis:")
    
    # Weather impact
    weather_impact = df.groupby('weather_conditions')['time_taken'].mean().sort_values(ascending=False)
    insights['weather_ranking'] = weather_impact.to_dict()
    print(f"   Weather impact (worst to best): {list(weather_impact.index)}")
    
    # Traffic impact
    traffic_impact = df.groupby('road_traffic_density')['time_taken'].mean().sort_values(ascending=False)
    insights['traffic_ranking'] = traffic_impact.to_dict()
    print(f"   Traffic impact (worst to best): {list(traffic_impact.index)}")
    
    # Vehicle impact
    vehicle_impact = df.groupby('type_of_vehicle')['time_taken'].mean().sort_values(ascending=False)
    insights['vehicle_ranking'] = vehicle_impact.to_dict()
    print(f"   Vehicle impact (slowest to fastest): {list(vehicle_impact.index)}")
    
    # 2. Best and worst combinations
    print("\n2. Best and Worst Scenarios:")
    
    # Find best combination
    best_conditions = df.loc[df['time_taken'].idxmin()]
    worst_conditions = df.loc[df['time_taken'].idxmax()]
    
    insights['best_scenario'] = {
        'time': float(best_conditions['time_taken']),
        'weather': best_conditions['weather_conditions'],
        'traffic': best_conditions['road_traffic_density'],
        'vehicle': best_conditions['type_of_vehicle']
    }
    
    insights['worst_scenario'] = {
        'time': float(worst_conditions['time_taken']),
        'weather': worst_conditions['weather_conditions'],
        'traffic': worst_conditions['road_traffic_density'],
        'vehicle': worst_conditions['type_of_vehicle']
    }
    
    print(f"   Best case: {insights['best_scenario']['time']:.1f} min ({insights['best_scenario']['weather']}, {insights['best_scenario']['traffic']}, {insights['best_scenario']['vehicle']})")
    print(f"   Worst case: {insights['worst_scenario']['time']:.1f} min ({insights['worst_scenario']['weather']}, {insights['worst_scenario']['traffic']}, {insights['worst_scenario']['vehicle']})")
    
    # 3. Distance correlation
    correlation = df['distance_km'].corr(df['time_taken'])
    insights['distance_correlation'] = float(correlation)
    print(f"\n3. Distance-Time Correlation: {correlation:.3f}")
    
    # 4. Peak hour analysis
    if 'order_hour' in df.columns:
        peak_hours = df.groupby('order_hour')['time_taken'].mean().sort_values(ascending=False).head(3)
        insights['peak_hours'] = peak_hours.to_dict()
        print(f"4. Slowest delivery hours: {list(peak_hours.index)}")
    
    return insights

def save_patterns_to_file(patterns, insights):
    print("\n💾 Saving patterns for ML model...")
    
    # Create the data structure for the ML model
    ml_data = {
        'patterns': patterns,
        'insights': insights,
        'metadata': {
            'total_patterns': len(patterns),
            'analysis_date': '2024-01-01',
            'dataset_size': 10000
        }
    }
    
    # Convert to JSON string for the ML model
    json_output = json.dumps(ml_data, indent=2)
    
    print("📋 Dataset Patterns (sample):")
    sample_patterns = dict(list(patterns.items())[:5])
    for key, value in sample_patterns.items():
        print(f"   {key}: {value['avg']:.1f}±{value['std']:.1f} min ({value['count']} samples)")
    
    print(f"\n✅ Generated {len(patterns)} patterns ready for ML model")
    print("🔗 Use these patterns in the updated ML model for accurate predictions!")
    
    return json_output

# Main execution
if __name__ == "__main__":
    # Step 1: Load and analyze dataset
    df = analyze_delivery_dataset()
    
    # Step 2: Extract patterns
    patterns, df_with_features = extract_patterns(df)
    
    # Step 3: Generate insights
    insights = generate_insights(df_with_features, patterns)
    
    # Step 4: Save for ML model
    ml_patterns = save_patterns_to_file(patterns, insights)
    
    print("\n🎯 Next Steps:")
    print("1. Replace the sample data with your actual CSV file")
    print("2. Update the ML model with these extracted patterns")
    print("3. Test the model with real scenarios")
    print("4. Fine-tune based on prediction accuracy")
